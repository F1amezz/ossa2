/*
 * @Descripttion: vue的webpack配置文件
 * @version: 
 * @Author: Bruce
 * @Date: 2020-08-06 11:55:35
 * @LastEditors: Bruce
 * @LastEditTime: 2020-08-06 14:24:42
 */
const path = require('path');

module.exports = {
    configureWebpack: {
        resolve: {
            alias: {
                style: path.resolve(__dirname, 'src/style'),//样式
                components: path.resolve(__dirname, 'src/components'),//公共组件
                utils:path.resolve(__dirname, 'src/utils'),//工具函数
                api:path.resolve(__dirname, 'src/api/apiList'),//接口
				css:path.resolve(__dirname, 'src/style'),//样式
            },
        }
    }
}