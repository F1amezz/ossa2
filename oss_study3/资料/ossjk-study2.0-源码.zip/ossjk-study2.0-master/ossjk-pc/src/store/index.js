/*
 * @Descripttion: vuex唯一出口
 * @version: 
 * @Author: Bruce
 * @Date: 2020-08-07 11:26:03
 * @LastEditors: Bruce
 * @LastEditTime: 2020-08-07 11:32:56
 */
import Vue from "vue"
import Vuex from "vuex"
import userModule from "./modules/userModule"
import examModule from "./modules/examModule"
import examDetailsModule from "./modules/examDetailsModule"

Vue.use(Vuex)

export default new Vuex.Store({
    modules:{
        userModule,//用户模块
		examModule,//考试页模块
		examDetailsModule//考试详情页模块
    }
})