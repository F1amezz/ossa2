/**
  * @title: 考试页数据模块
  * @description: 
  * @author JUN
  */

export default {
	namespaced:true,
	state:{
		ossjk_exam_date:""//考试日期
	},
	mutations:{
		["GET_DATE"](state,payload){//获取选中的日期
			state.ossjk_exam_date = payload
		}
	}
}