/*
 * @Descripttion: 用户模块
 * @version: 
 * @Author: Bruce
 * @Date: 2020-08-07 11:27:54
 * @LastEditors: Bruce
 * @LastEditTime: 2020-08-10 11:39:11
 */
import * as utils from "utils/localStorageUtils.js" 
export default {
    namespaced:true,
    state:{
        userInfo:utils.$getItem("userInfo") || null,//用户信息
        token:utils.$getItem("token") || null//密钥
    },
    mutations:{
        ["GET_USER_INFO"](state,userInfo){//获取用户信息
            state.userInfo = userInfo
            utils.$setItem("userInfo",state.userInfo)
        },
        ["REMOVE_USER_INFO"](state){//删除用户信息
            state.userInfo = null
            utils.$removeItem("userInfo")
        },
        ["GET_TOKEN"](state,token){//获取用户token
            state.token = token
            utils.$setItem("token",state.token)
        },
        ["REMOVE_TOKEN"](state){//删除用户token
            state.token = null
            utils.$removeItem("token")
        },
        ["REMOVE_ALL"](state){//删除用户模块所有数据
            Object.keys(state).map(item=>{
                state[item] = null
            })
            utils.$removeAll()
        }
    },
    actions:{
        ["ASYNC_GET_USER_INFO"]({commit},userInfo){//异步获取用户信息
            return new Promise((resolve)=>{
                commit("GET_USER_INFO",userInfo)
                resolve()
            })
        },
        ["ASYNC_GET_TOKEN"]({commit},token){//异步获取用户token
            return new Promise((resolve)=>{
                commit("GET_TOKEN",token)
                resolve()
            })
        }
    }
}