/**
  * @title: 考试详情页数据模块
  * @description: 获取学生的答案
  * @author JUN
  */
import * as utils from "utils/localStorageUtils.js" 
export default {
	namespaced:true,
	state:{
		minutes:utils.$getItem("minutes") || null,//分
		seconds:utils.$getItem("seconds") || null,//秒
		examOver:false//考试是否结束
	},
	mutations:{
		["GET_MINUTES"](state,minutes){//获取分
			state.minutes = minutes
			utils.$setItem("minutes",state.minutes)
		},
		["GET_SECONDS"](state,seconds){//获取秒
			state.seconds = seconds
			utils.$setItem("seconds",state.seconds)
		},
		["SET_examOver"](state){//更改考试为结束状态
			state.examOver = true
		},
	}
}