import Vue from 'vue'
import App from './App.vue'
import router from "@/router/index.js"//路由
import store from "@/store/index.js"//vuex
import "@/plugins/element.js"//element-ui
import "utils/autoRegisterCom.js"//自动注册全局组件
import HtmlUtil from "utils/htmlUtil.js"//转译试卷题目的特殊字符串


import "style/reset.css"//重置样式
import "style/common.css"//公共样式

Vue.prototype.HtmlUtil = HtmlUtil//转译试卷题目的特殊字符串
Vue.prototype.$eventBus = new Vue()//事件订阅模式

Vue.config.productionTip = false

new Vue({
  router,
  store,
  render: h => h(App),
}).$mount('#app')
