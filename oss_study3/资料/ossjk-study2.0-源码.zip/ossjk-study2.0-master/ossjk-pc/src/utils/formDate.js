/**
  * @name 格式化日期方法
  * @description: 
  * @param {date:Date} 日期对象
  * @return {newDate:String} 格式化日期字符串 yyyy-mm-dd
  */
export const formDate = (date)=>{
	let year = date.getFullYear()//获取年
	let month = date.getMonth() + 1//获取月
	let dates = date.getDate()//获取日
	function utils(str){//序列化月和日
		return str.length > 1 ? str : "0"+str
	}
	let newDate = year + "-" + utils(String(month)) + "-" + utils(String(dates))
	return newDate
}