/**
  * @Description:本地离线存储封装
  * @author JUN
  */

/**
 * @name: 本地离线-存值
 * @msg: 
 * @param {key:String} 键 
 * @param {value:Any} 值 
 * @return {void} 
 */
export const $setItem = (key,value)=>{
    localStorage.setItem(key,JSON.stringify(value))
}


/**
 * @name: 本地离线-取值
 * @msg: 
 * @param {key:String} 键 
 * @return {Any} 
 * @return {Null}
 */
export const $getItem = (key)=>{
	let item = JSON.parse(localStorage.getItem(key))
    if(item){
        return item
    }else{
        return null
    }
}

/**
 * @name: 本地离线-删除单个
 * @msg: 
 * @param {key:String} 键 
 * @return {void} 
 */
export const $removeItem = (key)=>{
    localStorage.removeItem(key)
}


/**
 * @name: 本地离线-删除所有
 * @msg: 
 * @return {void} 
 */
export const $removeAll = ()=>{
    localStorage.clear()
}
