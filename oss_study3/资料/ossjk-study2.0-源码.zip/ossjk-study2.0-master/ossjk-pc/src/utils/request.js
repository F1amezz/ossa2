/*
 * @Descripttion: 请求类型
 * @version: 
 * @Author: Bruce
 * @Date: 2020-08-06 14:16:54
 * @LastEditors: Bruce
 * @LastEditTime: 2020-08-06 14:39:40
 */
import httpRequest from "@/api/apiConfig.js"
import Qs from "qs"

// get封装
export const ajaxGet = (url, config) => {
    return httpRequest.get(url, config)
}

// post封装
export const ajaxPost = (url, data, config) => {
    return httpRequest.post(url, Qs.stringify(data), config)
}