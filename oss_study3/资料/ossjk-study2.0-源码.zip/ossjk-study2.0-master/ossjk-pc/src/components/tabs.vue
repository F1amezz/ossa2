/**
* @name 选项卡组件
* @description:
* @param
* @return
*/
<template>
	<el-tabs v-model="activeName" class="tabs">
		<el-tab-pane v-for="(items,idxs) of types" :key="idxs">

			<!-- 试卷题目类型 -->
			<span slot="label">
				<paper-type 
					:examType="items"
					:qnums="paperVo.qnums[idxs]"
					:scores="paperVo.scores[idxs]"
				></paper-type>
			</span>

			<!-- 试卷内容 -->
			<!-- 单选题 -->
			<template v-if="items === '1'">
				<single-choice-questions
					:qcontent="contents[idxs].qcontent"
					:answer="contents[idxs].answer"
					:qid="contents[idxs].qid"
					:qscore="contents[idxs].qscore"
					:sanswer="contents[idxs].sanswer"
					:sscore="contents[idxs].sscore"
					ref="single-choice-questions"
					class="tabsContent"
				></single-choice-questions>
			</template>

			<!-- 多选题 -->
			<template v-else-if="items === '2'">
				<multiple-choice-questions
					:qcontent="contents[idxs].qcontent"
					:answer="contents[idxs].answer"
					:qid="contents[idxs].qid"
					:qscore="contents[idxs].qscore"
					:sanswer="contents[idxs].sanswer"
					:sscore="contents[idxs].sscore"
					ref="multiple-choice-questions"
					class="tabsContent"
				></multiple-choice-questions>
			</template>

			<!-- 判断题 -->
			<template v-else-if="items === '3'">
				<judgment-questions
					:qcontent="contents[idxs].qcontent"
					:answer="contents[idxs].answer"
					:qid="contents[idxs].qid"
					:qscore="contents[idxs].qscore"
					:sanswer="contents[idxs].sanswer"
					:sscore="contents[idxs].sscore"
					ref="judgment-questions"
					class="tabsContent"
				></judgment-questions>
			</template>

			<!-- 填空题 -->
			<template v-else-if="items === '4'">
				<fill-questions 
					:qcontent="contents[idxs].qcontent"
					:answer="contents[idxs].answer"
					:qid="contents[idxs].qid"
					:qscore="contents[idxs].qscore"
					:sanswer="contents[idxs].sanswer"
					:sscore="contents[idxs].sscore"
					ref="fill-questions"
					class="tabsContent"
				></fill-questions>
			</template>

			<!-- 简答题 -->
			<template v-else-if="items === '5'">
				<answers-questions
					:qcontent="contents[idxs].qcontent"
					:answer="contents[idxs].answer"
					:qid="contents[idxs].qid"
					:qscore="contents[idxs].qscore"
					:sanswer="contents[idxs].sanswer"
					:sscore="contents[idxs].sscore"
					ref="answers-questions"
					class="tabsContent"
				></answers-questions>
			</template>

			<!-- 编程题 -->
			<template v-else-if="items === '6'">
				<programming-questions
					:qcontent="contents[idxs].qcontent"
					:answer="contents[idxs].answer"
					:qid="contents[idxs].qid"
					:qscore="contents[idxs].qscore"
					:sanswer="contents[idxs].sanswer"
					:sscore="contents[idxs].sscore"
					ref="programming-questions"
					class="tabsContent"
				></programming-questions>
			</template>

			<!-- 罗辑题 -->
			<template v-else-if="items === '7'">
				<logical-questions
					:qcontent="contents[idxs].qcontent"
					:answer="contents[idxs].answer"
					:qid="contents[idxs].qid"
					:qscore="contents[idxs].qscore"
					:sanswer="contents[idxs].sanswer"
					:sscore="contents[idxs].sscore"
					ref="logical-questions"
					class="tabsContent"
				></logical-questions>
			</template>
			
		</el-tab-pane>
	</el-tabs>
</template>

<script>
	import paperType from "components/paper/paperComs/paperType"
	import singleChoiceQuestions from "components/paper/paperTypes/singleChoiceQuestions.vue"
	import multipleChoiceQuestions from "components/paper/paperTypes/multipleChoiceQuestions.vue"
	import judgmentQuestions from "components/paper/paperTypes/judgmentQuestions.vue"
	import fillQuestions from "components/paper/paperTypes/fillQuestions.vue" 
	import answersQuestions from "components/paper/paperTypes/answersQuestions.vue"
	import programmingQuestions from "components/paper/paperTypes/programmingQuestions.vue"
	import logicalQuestions from "components/paper/paperTypes/logicalQuestions.vue"

	export default {
		components: {
			paperType, //试卷题目类型
			singleChoiceQuestions, //单选题
			multipleChoiceQuestions, //多选题
			judgmentQuestions, //判断题
			fillQuestions, //填空题
			answersQuestions, //简答题
			programmingQuestions, //编程题
			logicalQuestions, //罗辑题
		},
		props: {
			paperVo: { //试卷数据
				required: true,
				type: Object
			}
		},
		data() {
			return {
				contents: this.paperVo.contents, //不同类型题目内容
				qnums: this.paperVo.qnums, //不同类型题目数量
				scores: this.paperVo.scores, //不同类型题目分数
				types: this.paperVo.types, //不同类型题目
				activeName:"0",//选项卡索引
			};
		}
	}
</script>

<style lang="scss">
.tabs{
	height: 100%;
	display: flex;
	flex-direction: column;
	.el-tabs__content{
		flex: 1;
		.el-tab-pane{
			height: 100%;
			.tabsContent{
				height: 100%;
				display: flex;
				flex-direction: column;
			}
		}
	}
}
</style>
