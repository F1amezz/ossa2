<!--
 * @Descripttion: 尾部
 * @version: 
 * @Author: Bruce
 * @Date: 2020-08-06 11:02:50
 * @LastEditors: Bruce
 * @LastEditTime: 2020-08-06 11:13:25
-->
<template>
  <div class="footer">Copyright by OSSJK © 2019—2029</div>
</template>

<script>
export default {

}
</script>

<style lang="scss" scoped>
.footer{
    height: 65px;
	background: #003f78;
	text-align: center;
	line-height: 65px;
	color: #fff;
}
</style>