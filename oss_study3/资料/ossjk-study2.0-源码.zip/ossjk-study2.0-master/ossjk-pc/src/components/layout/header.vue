<!--
 * @Descripttion: 头部模版
 * @version: 
 * @Author: Bruce
 * @Date: 2020-08-06 10:45:42
 * @LastEditors: Bruce
 * @LastEditTime: 2020-08-07 16:57:06
-->
<template>
	<div class="header">
		<el-container>
			<!-- logo -->
			<my-image src='assets/img/logo.png' />

			<!-- 菜单 -->
			<el-menu class="menu" mode="horizontal" :router="true">

				<!-- 首页 -->
				<el-menu-item index="/home">
					<i class="el-icon-s-home"></i>
					<span>首页</span>
				</el-menu-item>

				<!-- 考试列表 -->
				<el-submenu index="/exam">
					<template slot="title">
						<i class="el-icon-tickets"></i>
						<span>开始考试</span>
					</template>
					<el-menu-item index="/exam">
						<i class="el-icon-tickets"></i>
						<span>考试</span>
					</el-menu-item>
					<el-menu-item disabled>
						<i class="el-icon-document"></i>
						<span>练习</span>
					</el-menu-item>
				</el-submenu>

				<!-- 考试历史 -->
				<el-menu-item index="/history">
					<i class="el-icon-document-copy"></i>
					<span>历史记录</span>
				</el-menu-item>

				<!-- 我的 -->
				<el-submenu index="/user">
					<template slot="title">
						<i class="el-icon-user"></i>
						<span>我的</span>
					</template>
					<el-menu-item @click="dialogVisible = true">
						<i class="el-icon-circle-close"></i>
						<span>退出</span>
					</el-menu-item>
				</el-submenu>
			</el-menu>
		</el-container>

		<!-- 弹出窗 -->
		<el-dialog title="退出" :visible.sync="dialogVisible" width="30%">
			<span>确定要退出吗?</span>
			<span slot="footer" class="dialog-footer">
				<el-button @click="dialogVisible = false">取 消</el-button>
				<el-button type="primary" @click="logout">确 定</el-button>
			</span>
		</el-dialog>
	</div>
</template>

<script>
	import { createNamespacedHelpers } from 'vuex'
	const { mapMutations } = createNamespacedHelpers('userModule')
	
	export default {
		data() {
			return {
				dialogVisible: false
			}
		},
		methods: {
			...mapMutations(["REMOVE_ALL"]),
			logout() {
				this.REMOVE_ALL()//删除所有用户信息和token
				this.$router.replace("/")//重定向到登录页
			}
		}
	};
</script>

<style lang="scss" scoped>
	.header {
		height: 65px;
		border-bottom: solid 1px #e6e6e6;

		.el-container {
			height: 100%;
			.menu{
				border-bottom: none;
			}
		}
	}
</style>
