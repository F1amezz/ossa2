<!--
 * @Descripttion: 内容
 * @version: 
 * @Author: Bruce
 * @Date: 2020-08-06 11:06:12
 * @LastEditors: Bruce
 * @LastEditTime: 2020-08-06 11:13:57
-->
<template>
  <div class="content">
      <router-view></router-view>
  </div>
</template>

<script>
export default {

}
</script>

<style lang="scss" scoped>
.content{
    flex: 1;
}
</style>