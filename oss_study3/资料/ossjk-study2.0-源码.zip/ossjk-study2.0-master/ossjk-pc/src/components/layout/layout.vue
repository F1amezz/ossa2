<!--
 * @Descripttion: 模板
 * @version: 
 * @Author: Bruce
 * @Date: 2020-08-06 11:04:05
 * @LastEditors: Bruce
 * @LastEditTime: 2020-08-06 11:14:23
-->
<template>
  <div class="layout">
    <!-- 头部 -->
    <my-header></my-header>

    <!-- 中部 -->
    <my-content></my-content>

    <!-- 尾部 -->
    <my-footer></my-footer>
  </div>
</template>

<script>
import myHeader from "./header";
import myContent from "./content";
import myFooter from "./footer";
export default {
  components: {
    myHeader,
    myContent,
    myFooter,
  },
};
</script>

<style lang="scss" scoped>
.layout{
    height: 100%;
    display: flex;
    flex-direction: column;
}
</style>