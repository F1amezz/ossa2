/**
  * @name 试卷正确答案组件
  * @description: 
  * @param 
  * @return 
  */
<template>
	<div class="paperRightAnswer">
		<div class="title">正确答案:</div>
		<!-- 如果是简答题、编程题、罗辑题 -->
		<template v-if="answer">
<pre class="pre">
{{rightAnswer}}
</pre>			
		</template>
		
		<!-- 如果不是 -->
		<template v-else>
			
			<!-- 如果是填空题 -->
			<template v-if="isFillQ">
				<span v-for="(item,idx) of JSON.parse(rightAnswer)" :key="idx">{{item}}、</span>
			</template>
			
			<!-- 如果不是 -->
			<template v-else>
				{{rightAnswer}}
			</template>
		</template>
	</div>
</template>

<script>
	export default{
		props:{
			rightAnswer:{
				type:String
			},
			answer:{
				type:Boolean,
				default:false
			},
			isFillQ:{
				type:Boolean,
				default:false
			}
		}
	}
</script>

<style lang="scss" scoped>
	.paperRightAnswer{
		margin: 10px 0;
		display: flex;
		.title{
			width: 80px;
			color: red;
		}
		.content{
			flex: 1;
			color: red;
		}
		.pre{
			font-size: 16px;
		}
	}
</style>
