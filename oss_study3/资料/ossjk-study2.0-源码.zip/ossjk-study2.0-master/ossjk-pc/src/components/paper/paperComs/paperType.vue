/**
  * @name 试卷类型组件
  * @description: 
  * @param {examType:String} 试卷类型
  * @return 
  */
<template>
	<div v-if="examType === '1'">单选题 ({{qnums}}题共{{scores}}分)</div>
	<div v-else-if="examType === '2'">多选题 ({{qnums}}题共{{scores}}分)</div>
	<div v-else-if="examType === '3'">判断题 ({{qnums}}题共{{scores}}分)</div>
	<div v-else-if="examType === '4'">填空题 ({{qnums}}题共{{scores}}分)</div>
	<div v-else-if="examType === '5'">简答题 ({{qnums}}题共{{scores}}分)</div>
	<div v-else-if="examType === '6'">编程题 ({{qnums}}题共{{scores}}分)</div>
	<div v-else-if="examType === '7'">罗辑题 ({{qnums}}题共{{scores}}分)</div>
</template>

<script>
	export default{
		props:{
			examType:{//试卷类型
				type:String,
				required:true
			},
			qnums:{//不同类型题目数量
				type:String
			},
			scores:{//不同类型题目分数
				type:String
			}
		}
	}
</script>

<style>
</style>
