/**
  * @name 试卷解析组件
  * @description: 
  * @param 
  * @return 
  */
<template>
	<div class="analysis">
		<div class="title">答案解析:</div>
		<div class="content">{{analysis ? analysis : '无'}}</div>
	</div>
</template>

<script>
	export default{
		props:{
			analysis:{
				type:String
			}
		}
	}
</script>

<style lang="scss" scoped>
	.analysis{
		display: flex;
		.title{
			width: 80px;
		}
		.content{
			flex: 1;
		}
	}
</style>
