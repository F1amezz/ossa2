/**
  * @title: 试卷类型混合
  * @description: 把不同类型的试卷相同的部分进行混合
  * @author JUN
  */
import paperTitles from "components/paper/paperComs/paperTitles"
import paperRightAnswer from "components/paper/paperComs/paperRightAnswer"
import paperAnalysis from "components/paper/paperComs/paperAnalysis"
import myPagination from "components/myPagination"

export default{
	props:{
		qcontent:{//题目内容
			type:Array,
			required:true
		},
		answer:{//答案
			type:Array,
		},
		qid:{//题目id
			type:Array,
		},
		qscore:{//题目分数
			type:Array,
		},
		sanswer:{//学生答案
			type:Array,
		},
		sscore:{//学生分数
			type:Array,
		}
	},
	inject:["isDisabled"],//是否可以控制
	components: {
		paperTitles,//试卷标题
		paperRightAnswer,//正确答案
		paperAnalysis,//答案解析
		myPagination,//分页
	}
}