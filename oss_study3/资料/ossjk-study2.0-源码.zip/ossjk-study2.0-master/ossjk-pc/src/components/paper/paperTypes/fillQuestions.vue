/**
* @name 填空题组件
* @description:
* @param 
* @return
*/
<template>
	<div class="answersQuestions">
		<!-- 容器 -->
		<div v-for="(items,idxs) of qcontent" :key="idxs" :class="['paper',idxs === currentPage ? 'active' : null]">
			<!-- 试卷题目 -->
			<paper-titles :titles="items.title" :idx="idxs"></paper-titles>
			
			<!-- 试卷答题区域 -->
			<!-- 历史详情页 -->
			<template v-if="isDisabled">
				<el-input
					class="fillInput"
					v-for="(item,idx) of createInput(items.title)"
					:key="idx"
					v-model="newArr[idxs][idx]"
					style="width: 200px;"
					:disabled="isDisabled"
				>
					<span slot="prepend">{{idx+1}}</span>
				</el-input>
			</template>
			
			<!-- 考试详情页 -->
			<template v-else>
				<el-input
					class="fillInput"
					v-for="(item,idx) of createInput(items.title)"
					:key="idx"
					v-model="sanswerList[idxs][idx]"
					style="width: 200px;"
					placeholder="请输入内容"
					:disabled="isDisabled"
				>
					<span slot="prepend">{{idx+1}}</span>
				</el-input>
			</template>
			
			<!-- 正确答案 -->
			
			<paper-right-answer v-if="isDisabled" :rightAnswer="answer[idxs]" :isFillQ="true"></paper-right-answer>
			
			<!-- 答案解析 -->
			<paper-analysis v-if="isDisabled" :analysis="items.analysis"></paper-analysis>
		</div>
		
		<!-- 分页 -->
		<my-pagination :total="qcontent.length" :size="1" @currentChange="currentChange($event)"></my-pagination>
	</div>
</template>

<script>
	import paperMixin from "components/paper/paperMixin.js"

	export default {
		mixins: [paperMixin], //试卷混合
		data() {
			return {
				currentPage: 0, //当前页
				type:4,//填空题
				sanswerList:Array.apply(null, { length: this.qcontent.length }).map(()=>{
					return []
				}), //学生答案
				newArr:[]
			}
		},
		methods: {
			currentChange(idx) { //切换分页
				this.currentPage = idx
			},
			createInput(str){//生成输入框
				let arr = str.match(/(__)/igm)
				return arr.length
			},
			mySplit(arr){
				let newArr = arr.map((item)=>{
					let newItem = JSON.parse(item)
					return newItem
				})
				// console.log(newArr)
				this.newArr = newArr
			}
		},
		created(){
			// console.log(this.qcontent)
			if(this.sanswer && this.sanswer.length){
				this.mySplit(this.sanswer)
			}
		}
	}
</script>

<style lang="scss" scoped>
	@import "css/papers.scss"
</style>
