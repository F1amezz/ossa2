/**
* @name 试卷标题组件
* @description:
* @param
* @return
*/
<template>
	<div class="paperTitles">
		<pre>
{{idx+1}}、{{titles}}
<!-- {{idx+1}}、{{HtmlUtil.htmlEncode(titles)}} -->
</pre>
	</div>
</template>

<script>
	export default {
		props: {
			titles: { //试卷标题
				type: String,
				required: true
			},
			idx: {
				type: Number,
				required: true
			}
		}
	}
</script>

<style lang="scss" scoped>
	.paperTitles {
		background: #c4e8f7;
		padding: 10px;
		word-spacing: 6px;
		line-height: 28px;
		border-radius: 6px;
		margin-bottom: 10px;
		pre {
			width: 100%;
			font-size: 16px;
			white-space: pre-wrap;
			/* css3.0 */
			white-space: -moz-pre-wrap;
			/* Firefox */
			white-space: -pre-wrap;
			/* Opera 4-6 */
			white-space: -o-pre-wrap;
			/* Opera 7 */
			word-wrap: break-word;
			/* Internet Explorer 5.5+ */
		}
	}
</style>
