/**
  * @Description: 全局图片组件
  * @author Administrator
  */
<template>
  <div>
      <el-image class="image" :src="require(`@/${src}`)" :fit="fit" style="imgStyle"></el-image>
  </div>
</template>

<script>
export default {
    props:{
        src:{//图片地址
            type:String,
            required:true
        },
        fit:{//图片模式
            type:String,
            default:"contain"
        },
        imgStyle:{//图片样式
            type:Object
        }
    }
}
</script>

<style lang="scss" scoped>
.image{
    height: 100%;
}
</style>