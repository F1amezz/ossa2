/**
* @name 分页组件
* @description:
* @param
* @return
*/
<template>
	<div class="block" v-if="total">
		<el-pagination class="pagination" background layout="total,prev, pager, next ,jumper" :total="total" :page-size="size" @current-change="currentChange"></el-pagination>
	</div>
</template>

<script>
	export default {
		props: {
			total: { //总数
				type: Number,
			},
			size: { //每页显示条数
				type: Number,
				default: 10
			},
		},
		methods: {
			currentChange(idx) {
				this.$emit("currentChange", idx-1)
			}
		}
	}
</script>

<style lang="scss" scoped>
	.block {
		//容器
		display: flex;
		justify-content: center;
		padding: 20px 0;

		.pagination {
			//分页
			display: inline-block;
		}
	}
</style>
