/**
* @Description: 历史记录列表页
* @author Administrator
*/
<template>
	<div class="history main_container">
		<div class="main_title">历史记录</div>

		<!-- 表格 -->
		<el-table class="table" :data="filterData(tableData)" style="width: 100%;" v-loading="isLoading">
			
			<!-- 考试时间 -->
			<el-table-column label="考试时间" prop="createTime" width="200">
				<template slot-scope="scope">
					<i class="el-icon-time"></i>
					<span style="margin-left: 10px">{{ scope.row.createTime }}</span>
				</template>
			</el-table-column>
			
			<!-- 考试名称 -->
			<el-table-column label="考试名称" prop="expname"></el-table-column>
			
			<!-- 考试类型 -->
			<el-table-column label="测试类型" prop="exptype">
				<template slot-scope="scope">
					<span style="margin-left: 10px">{{ scope.row.exptype === '1' ? '考试' : '练习' }}</span>
				</template>
			</el-table-column>
			
			<!-- 考试时长 -->
			<el-table-column label="考试时长" prop="expduration"></el-table-column>
			
			<!-- 考试合格分数 -->
			<el-table-column label="考试合格分数" prop="exppassscore"></el-table-column>
			
			<!-- 得分 -->
			<el-table-column label="得分/总分" prop="studentScore"></el-table-column>
			
			<!-- 操作 -->
			<el-table-column label="操作">
				<template slot-scope="scope">
					<el-button size="mini" type="primary" @click="lookUp(scope.row)">查看</el-button>
				</template>
			</el-table-column>
		</el-table>
		
		<!-- 分页 -->
		<my-pagination @currentChange="currentChange($event)" :total="total" :size="size"></my-pagination>
	</div>
</template>

<script>
	import * as api from "api/history.js"
	export default {
		data() {
			return {
				tableData: [],//表格数据
				total:0,//总数
				size:5,//每页显示数
				current:1,//当前页数
				isLoading:false//loading
			}
		},
		methods:{
			async API_list(pageNum,pageSize){//获取成绩单列表
				let result={
					params:{
						pageNum,//第几页
						pageSize
					}
				}
				return await api.list(result)
			},
			lookUp(row){//查看更多
				this.$router.push({path:'/historyDetails',query:{id:row.id}})
			},
			currentChange(idx){
				console.log(idx)
				this.current = idx+1
			},
			filterData(arr){
				let obj = {}
				return arr.map((item)=>{
					item.studentScore = item.score + '/' + item.expscore
					obj = item
					return obj
				})
			}
		},
		watch:{
			current:{
				async handler(num){
					this.isLoading = true
					let res = await this.API_list(num,this.size)//获取成绩单列表
					this.tableData = res.data.content.records
					
					let {total,size,current} = res.data.content
					this.total = total
					this.size = size
					this.current = current
					this.isLoading = false
					console.log(res)
				},
				immediate:true
			}
		},
		created(){
			localStorage.removeItem("minutes")
			localStorage.removeItem("seconds")
		}
	}
</script>

<style lang="scss" scoped>
.history{
	display: flex;
	flex-direction: column;
	.table{
		flex: 1;
	}
}
</style>
