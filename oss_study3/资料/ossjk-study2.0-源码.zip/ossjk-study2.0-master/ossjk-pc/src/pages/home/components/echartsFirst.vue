<template>
	<div class="echartsFirst">
		<div class="userInfo" v-if="userInfo">
			<el-avatar class="avatar" shape="square" size="large" :src="url" fit="contain"></el-avatar>
			<div class="info">
				<div class="name">{{userInfo.name}}</div>
				<div class="cname">{{userInfo.cname}}</div>
			</div>
		</div>
	</div>
</template>

<script>
	import * as api from "api/userInfo.js"
	export default {
		data(){
			return{
				userInfo:"",//用户信息
				url:"https://fuss10.elemecdn.com/e/5d/4a731a90594a4af544c0c25941171jpeg.jpeg"
			}
		},
		methods:{
			async API_getInfo(){//获取用户信息
				return await api.getInfo()
			}
		},
		async created(){
			let res = await this.API_getInfo()
			console.log(res)
			this.userInfo = res.data.content
		}
	}
</script>

<style lang="scss" scoped>
	.echartsFirst{
		padding: 50px;
		box-sizing: border-box;
		.userInfo{
			background: #c4e8f7;
			border-radius: 10px;
			padding: 20px;
			box-sizing: border-box;
			display: flex;
			align-items: center;
			&:hover{
				box-shadow: 3px 3px 3px 3px;
			}
			.avatar{
				width: 60px;
				height: 60px;
				margin-right: 20px;
			}
			.info{
				.name{
					font-size: 26px;
				}
			}
		}
	}
</style>
