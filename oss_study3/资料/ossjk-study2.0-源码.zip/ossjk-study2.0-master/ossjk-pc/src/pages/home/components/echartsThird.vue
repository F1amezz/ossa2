<template>
	<div id="echartsThird"></div>
</template>

<script>
	import echarts from "echarts"
	export default {
		mounted() {
			let echartsThird = echarts.init(document.getElementById('echartsThird'));
			let option = {
				tooltip: {
					trigger: 'axis',
					axisPointer: {
						type: 'cross',
						crossStyle: {
							color: '#999'
						}
					}
				},
				legend: {
					data: ['预期分数', '实际分数', '班级平均分']
				},
				xAxis: [{
					type: 'category',
					data: ['1周', '2周', '3周', '4周', '5周', '6周', '7周', '8周', '9周', '10周', '11周', '12周'],
					axisPointer: {
						type: 'shadow'
					}
				}],
				yAxis: [{
						type: 'value',
						name: '分数',
						min: 0,
						max: 100,
						interval: 60,
						axisLabel: {
							formatter: '{value}'
						}
					},
					{
						type: 'value',
						name: '天',
						min: 0,
						max: 30,
						interval: 5,
						axisLabel: {
							formatter: '{value}'
						}
					}
				],
				series: [{
						name: '预期分数',
						type: 'bar',
						data: [2.0, 4.9, 7.0, 23.2, 25.6, 76.7, 80.6, 90.2, 32.6, 20.0, 6.4, 3.3]
					},
					{
						name: '实际分数',
						type: 'bar',
						data: [2.6, 5.9, 9.0, 26.4, 28.7, 70.7, 60.6, 30.2, 48.7, 18.8, 6.0, 2.3]
					},
					{
						name: '班级平均分',
						type: 'line',
						yAxisIndex: 1,
						data: [2.0, 2.2, 3.3, 4.5, 6.3, 10.2, 20.3, 23.4, 23.0, 16.5, 12.0, 6.2]
					}
				]
			};
			echartsThird.setOption(option)
		}
	}
</script>

<style lang="scss" scoped>
	#echartsThird{
		border-radius: 10px;
		padding: 10px;
		box-sizing: border-box;
		overflow: hidden;
	}
</style>
