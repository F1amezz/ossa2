/**
  * @title: 首页
  * @description: 
  * @author JUN
  */
<template>
	<div class="home">
		<div class="echarts">
			<echarts-first class="echarts-items first"></echarts-first>
			<echarts-seconds class="echarts-items seconds"></echarts-seconds>
			<echarts-third class="echarts-items third"></echarts-third>
			<echarts-fourth class="echarts-items fourth"></echarts-fourth>
		</div>
	</div>
</template>

<script>
	// import { createNamespacedHelpers } from 'vuex'
	// const { mapGetters,mapMutations } = createNamespacedHelpers('userModule')
	import echartsFirst from "./components/echartsFirst.vue"
	import echartsSeconds from "./components/echartsSeconds.vue"
	import echartsThird from "./components/echartsThird.vue"
	import echartsFourth from "./components/echartsFourth.vue"

	export default {
		components: {
			echartsFirst,
			echartsSeconds,
			echartsThird,
			echartsFourth
		},
		created(){
			localStorage.removeItem("minutes")
			localStorage.removeItem("seconds")
		}
	}
</script>

<style lang="scss" scoped>
	.home{
		max-width: 1000px;
		margin: 0 auto;
		.echarts{
			display: grid;
			grid-template-columns: repeat(2, 1fr);
			grid-template-rows: repeat(2, 1fr);
			grid-row-gap: 20px;
			grid-column-gap: 20px;
			padding: 15px 0;
			box-sizing: border-box;
			.echarts-items{
				height: 320px;
			}
			.third:hover{
				box-shadow: 3px 3px 3px 3px;
			}
		}
	}
</style>
