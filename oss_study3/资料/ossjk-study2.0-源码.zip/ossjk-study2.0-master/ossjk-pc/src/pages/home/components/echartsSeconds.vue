<template>
	<div id="echartsSeconds"></div>
</template>

<script>
	import echarts from "echarts"
	export default {
		mounted() {
			let echartsSeconds = echarts.init(document.getElementById('echartsSeconds'));
			let option = {
				tooltip: {},
				radar: {
					// shape: 'circle',
					name: {
						textStyle: {
							color: '#fff',
							backgroundColor: '#999',
							borderRadius: 3,
							padding: [3, 5]
						}
					},
					indicator: [{
							name: 'html',
							max: 6500
						},
						{
							name: 'css',
							max: 16000
						},
						{
							name: 'vue',
							max: 30000
						},
						{
							name: 'webpack',
							max: 38000
						},
						{
							name: 'js',
							max: 52000
						},
						{
							name: 'node.js',
							max: 25000
						}
					]
				},
				series: [{
					type: 'radar',
					// areaStyle: {normal: {}},
					data: [{
							value: [4300, 10000, 28000, 35000, 50000, 19000],
							name: '预期分数（Expected Score）'
						},
						{
							value: [5000, 14000, 28000, 31000, 42000, 21000],
							name: '实际分数（Actual Score）'
						}
					]
				}]
			};
			echartsSeconds.setOption(option)
		}
	}
</script>

<style>
</style>