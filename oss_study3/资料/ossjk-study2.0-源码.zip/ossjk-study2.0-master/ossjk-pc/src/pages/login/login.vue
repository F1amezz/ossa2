<!--
 * @Descripttion: 登录页
 * @version: 
 * @Author: Bruce
 * @Date: 2020-08-06 09:53:40
 * @LastEditors: Bruce
 * @LastEditTime: 2020-08-07 10:16:11
-->
<template>
	<el-container class="login">
		<!-- 头部 -->
		<el-header class="hidden-md-and-down">
			<el-image class="logo" :src="url" fit="contain"></el-image>
		</el-header>

		<!-- 主要内容区 -->
		<el-main class="content">
			<div class="container-box">
				<el-row :gutter="10">
					<el-col :xs="24" :sm="24" :lg="12" class="left">
						<div class="grid-content bg-purple-dark title">
							<h1>
								<p>靖凯开源</p>
								<p>考试系统</p>
							</h1>
							<h2>
								<p>www.ossjk.com</p>
							</h2>
						</div>
					</el-col>

					<el-col :xs="24" :sm="24" :lg="12" class="right">
						<div class="grid-content bg-purple-dark login-module">
							<!-- 登录模块 -->
							<login-module></login-module>
						</div>
					</el-col>
				</el-row>
			</div>
		</el-main>

	</el-container>
</template>

<script>
	import loginModule from "./components/loginModule"
	export default {
		components: {
			loginModule
		},
		data() {
			return {
				url: require("@/assets/img/logo.png"),
				bgUrl: require("@/assets/img/loginbg.jpg"),
			};
		}
	};
</script>

<style lang="scss" scoped>
	.login {
		width: 100%;
		height: 100%;

		.logo {
			//logo
			height: 100%;
		}

		.content {
			//主要内容
			padding: 0;
			height: 100%;
			background: url("../../assets/img/loginbg.jpg") no-repeat;
			background-size: 100% 100%;
			padding: 11% 0;

			.left {

				//左侧
				.title {
					//标题
					color: #007dc9;
					font-weight: 800;
					letter-spacing: 2px;
					height: 270px;
					font-size: 40px;
					width: 320px;
					text-align: center;
					margin: 0 auto;

					h2 {
						font-size: 34px;
					}
					&:hover p{
						text-shadow: 3px 3px 3px #000;
					}
				}
			}

			.right {

				//右侧
				.login-module {
					//登录模块
					background: hsla(0, 0%, 100%, 0.3);
					width: 320px;
					border-radius: 10px;
					padding: 20px 20px;
					margin: 0 auto;

					&:hover {
						box-shadow: 3px 3px 3px 3px;
					}
				}
			}
		}
	}
</style>
