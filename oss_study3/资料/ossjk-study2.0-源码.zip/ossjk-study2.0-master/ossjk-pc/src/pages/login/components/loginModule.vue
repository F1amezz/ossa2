<!--
 * @Descripttion: 登录窗口
 * @version: 
 * @Author: Bruce
 * @Date: 2020-08-07 10:15:21
 * @LastEditors: Bruce
 * @LastEditTime: 2020-08-07 15:33:52
-->
<template>
	<div class="loginModule">
		<h2>登录</h2>

		<!-- 表单 -->
		<el-form ref="loginForm" :model="loginForm" :rules="rules" label-width="60px">
			<!-- 帐号 -->
			<el-form-item label="帐号" prop="lname">
				<el-input v-model="loginForm.lname"></el-input>
			</el-form-item>

			<!-- 密码 -->
			<el-form-item label="密码" prop="pwd">
				<el-input v-model="loginForm.pwd"></el-input>
			</el-form-item>

			<!-- 提交 -->
			<el-form-item class="submit">
				<el-button type="primary" @click="onSubmit('loginForm')" :loading="isLoading">登录</el-button>
			</el-form-item>
		</el-form>

		<!-- 其他方式登录 -->
		<el-divider class="divider">其他方式登录</el-divider>
		<div class="otherLogin">
			<wechat></wechat>
		</div>
	</div>
</template>

<script>
	import * as api from "api/login.js";
	import wechat from "./wechat.vue"

	import {
		createNamespacedHelpers
	} from 'vuex'
	const {
		mapActions
	} = createNamespacedHelpers('userModule')

	export default {
		components:{
			wechat
		},
		data() {
			return {
				loginForm: {
					//表单数据对象
					lname: "", //帐号
					pwd: "", //密码
				},
				rules: {
					//校验规则
					lname: [{
						required: true,
						message: "请输入帐号",
						trigger: "blur"
					}],
					pwd: [{
						required: true,
						message: "请输入密码",
						trigger: "blur"
					}],
				},
				isLoading: false, //按钮loading效果
			};
		},
		methods: {
			...mapActions(["ASYNC_GET_USER_INFO", "ASYNC_GET_TOKEN"]),
			async API_login({
				lname,
				pwd
			}) {
				//登录接口
				let result = {
					lname,
					pwd,
				};
				return await api.login(result);
			},
			async onSubmit(formName) {
				//提交表单
				this.isLoading = true
				this.$refs[formName].validate(async (valid) => {
					if (valid) {
						//如果验证通过
						let res = await this.API_login(this.loginForm);

						if (res.data.statusCode === "200") {
							await this.ASYNC_GET_USER_INFO(res.data.content) //获取用户信息
							await this.ASYNC_GET_TOKEN(res.data.content.token) //获取用户token

							//登录成功
							this.$message({
								message: res.data.message,
								type: "success",
							});

							this.$router.push("/home") //跳转到首页
						} else {
							//登录失败
							this.$message.error(res.data.message);
						}
						this.isLoading = false
					}
				});
			},
		},
	};
</script>

<style lang="scss" scoped>
	.loginModule {
		h2 {
			text-align: center;
			padding: 6px 0;
			font-size: 26px;
		}

		/deep/.el-form-item__label {
			//表单左侧文字
			color: #000;
			font-size: 16px;
		}

		.divider {

			//分割线
			/deep/.el-divider__text {
				border: 1px solid #DCDFE6;
				border-radius: 10px;
			}
		}

		.otherLogin {
			//其他登录
			display: flex;
			justify-content: center;
		}
	}
</style>
