<template>
	<el-popover placement="top-start" title="登录" width="50" trigger="hover" content="微信登录">
		<el-image slot="reference" class="wechat" style="width: 40px; height: 40px" :src="loginTypeUrl" fit="contain" @click="wxlogin"></el-image>
	</el-popover>
</template>

<script>
	export default {
		data() {
			return {
				loginTypeUrl: require("@/assets/img/wechat.png")
			}
		},
		methods: {
			wxlogin() {
				this.wxLogin("wxfde52b5024260a5c", "https://s2.ossjk.com/pc/user/pcWxlogin");
			},
			wxLogin(appid, url) {
				let redirect_uri = encodeURIComponent(url);
				window.location.href =
					`https://open.weixin.qq.com/connect/qrconnect?appid=${appid}&redirect_uri=${redirect_uri}&response_type=code&scope=snsapi_login&state=#wechat_redirect`;
			}
		}
	}
</script>

<style lang="scss" scoped>
	.wechat {
		cursor: pointer;
	}
</style>
