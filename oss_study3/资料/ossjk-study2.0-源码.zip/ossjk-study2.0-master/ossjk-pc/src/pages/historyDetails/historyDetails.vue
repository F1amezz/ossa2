/**
* @title: 历史详情页
* @description:
* @author JUN
*/
<template>
	<div class="historyDetails main_container">

		<!-- 选项卡 -->
		<tabs v-if="paperVo" :paperVo="paperVo" ref="tabs"></tabs>

	</div>
</template>

<script>
	import tabs from "components/tabs.vue"

	import * as api from "api/historyDetails.js"

	export default {
		props:{
			id:{//考试id
				type:String,
				required:true
			}
		},
		provide:{
			isDisabled:true//是否可以控制
		},
		components: {
			tabs,
		},
		data() {
			return {
				paperVo: "", //试卷数据
			}
		},
		methods: {
			async API_transcriptById(id) { //获取试卷，知识点API
				let result = {
					params: {
						id //考试id
					}
				}
				return await api.transcriptById(result)
			}
		},
		async created() {
			let res = await this.API_transcriptById(this.id) 
			
			this.paperVo = JSON.parse(res.data.content.answer)
			console.log(this.paperVo)
		},
	}
</script>

<style lang="scss" scoped>
	.historyDetails {
		max-width: 900px;
	}
</style>
