/**
* @title: 考试详情页
* @description:
* @author JUN
*/
<template>
	<div class="examDetails main_container">

		<!-- 选项卡 -->
		<tabs v-if="paperVo" :paperVo="paperVo" ref="tabs"></tabs>

		<!-- 考试信息卡片 -->
		<exam-info-card v-if="record" :exam="exam" :record="record"></exam-info-card>

		<!-- 提交试卷弹窗 -->
		<submit-dialog v-if="exam" :exam="exam" ref="submitDialog"></submit-dialog>
	</div>
</template>

<script>
	import tabs from "components/tabs.vue"
	import examInfoCard from "./components/examInfoCard.vue"
	import submitDialog from "./components/submitDialog.vue"

	import * as api from "api/examDetails.js"

	import {
		createNamespacedHelpers
	} from 'vuex'
	const {
		mapState
	} = createNamespacedHelpers('userModule')

	export default {
		components: {
			tabs,
			examInfoCard,
			submitDialog
		},
		data() {
			return {
				paperVo: "", //试卷数据
				exam: "", //考试数据
				record: "", //试卷记录
				isExam:false//是否有考试
			}
		},
		provide:{
			isDisabled:false//是否可以控制
		},
		computed: {
			...mapState(["userInfo"])
		},
		methods: {
			async API_dailyOne(cid) { //获取试卷，知识点API
				let result = {
					params: {
						cid //班级id
					}
				}
				return await api.dailyOne(result)
			}
		},
		async created() {
			localStorage.removeItem("minutes")
			localStorage.removeItem("seconds")
			let res = await this.API_dailyOne(this.userInfo.clzid) //获取试卷，知识点API
			console.log(res)
			if (res.data.statusCode === "300") {//没有考试
				this.$message({
					message: res.data.message,
					type: 'warning'
				});
				this.$router.replace("/history")
			} else {
				this.paperVo = res.data.paperVo
				this.exam = res.data.exam
				this.record = res.data.record
				this.isExam = true
			}
		},
		beforeRouteLeave(to, from, next) { //路由拦截
			if(this.isExam){//有考试
				
				var bool = this.$store.state.examDetailsModule.examOver//是否为考试结束
				console.log("考试是否为结束")
				console.log(bool)
				if(!bool){//考试没结束
					if(!this.$refs.submitDialog._data.dialogVisible){//没有弹窗才显示
						this.$confirm('离开当前页将会提交试卷，是否继续?', '提示', {
							confirmButtonText: '确定',
							cancelButtonText: '取消',
							type: 'warning'
						}).then(() => {
							this.$refs.submitDialog.submitSanswer() //提交试卷
							next()
						}).catch(()=>{
							
						})
					}else{//有弹窗
						next()
					}
				}else{//考试结束了
					next()
				}
			}else{//没有考试
				next()
			}
		}
	}
</script>

<style lang="scss" scoped>
	.examDetails {
		max-width: 900px;
	}
</style>
