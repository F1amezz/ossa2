/**
* @name 提交试卷弹窗
* @description: 如果题目没做完要显示没做完的题目
* @param
* @return
*/
<template>
	<el-dialog title="提交试卷" :visible.sync="dialogVisible" width="30%">
		<!-- 没做完 -->
		<template v-if="checkSanswerArr.length">
			<div>还有以下题目没完成，确定提交吗？</div>
			<div>
				<p v-for="items of checkSanswerArr" :key="items.type">
					<template v-if="items.type === 1">
						<span>单选题：</span>
					</template>
					<template v-if="items.type === 2">
						<span>多选题：</span>
					</template>
					<template v-if="items.type === 3">
						<span>判断题：</span>
					</template>
					<template v-if="items.type === 4">
						<span>天空题：</span>
					</template>
					<template v-if="items.type === 5">
						<span>简答题：</span>
					</template>
					<template v-if="items.type === 6">
						<span>编程题：</span>
					</template>
					<template v-if="items.type === 7">
						<span>逻辑题：</span>
					</template>
					<span v-for="(item,idx) of items.sArr" :key="idx">{{item}}、 </span>
				</p>
			</div>
		</template>

		<!-- 做完 -->
		<template v-else>
			<div>已经全部做完，确定提交吗？</div>
		</template>

		<span slot="footer" class="dialog-footer">
			<el-button @click="dialogVisible = false">取 消</el-button>
			<el-button type="primary" @click="submitSanswer" :loading="submitLoading">提交</el-button>
		</span>
	</el-dialog>
</template>

<script>
	import * as api from "api/examDetails.js"
	export default {
		props: {
			exam: { //考试数据
				type: Object,
				required: true
			}
		},
		data() {
			return {
				dialogVisible: false, //是否显示弹窗
				checkSanswerArr: [], //检查学生答案
				sAnswerArr: [], //学生答案
				submitLoading: false //提交loading
			};
		},
		methods: {
			async API_insert(cid, expid, eid, answer) { //提交试卷接口
				let result = {
					cid, //班级id
					expid, //试卷id
					eid, //考试id
					answer //学生答案
				}
				return await api.insert(result)
			},
			getSanswer() { //获取学生答案
				let obj = this.$parent.$refs.tabs.$refs
				let checkSanswerArr = [] //检查学生的答案
				let sAnswerArr = [] //学生答案

				Object.values(obj).forEach((item) => {
					let {
						type,
						sArr
					} = this.checkSanswer(item[0]._data.type, item[0]._data.sanswerList)
					if (sArr.length) {
						checkSanswerArr.push({
							type,
							sArr
						})
					}
					sAnswerArr.push({
						type,
						sanswer: item[0]._data.sanswerList
					})
				})

				this.checkSanswerArr = checkSanswerArr
				this.sAnswerArr = sAnswerArr
			},
			checkSanswer(type, sanswer) { //检查学生答案
				let sArr = []
				sanswer.map((item, idx) => {
					if (!item) {
						sArr.push(idx + 1)
					}
				})
				return {
					type,
					sArr
				}
			},
			async submitSanswer() { //提交学生答案
				this.submitLoading = true
				let res = await this.API_insert(this.exam.cid, this.exam.expid, this.exam.id, JSON.stringify(this.sAnswerArr))
				this.submitLoading = false
				this.$message({
					message: res.data.message,
					type: 'success'
				});
				this.$router.replace("/history")
			}
		},
		created() {
			this.$eventBus.$on("showSubmitDialog", () => { //显示弹窗
				this.dialogVisible = true
				this.getSanswer() //获取学生答案
			})
		}
	}
</script>

<style>
</style>
