/**
* @name 考试信息卡片组件
* @description:
* @param
* @return
*/
<template>
	<div class="examInfoCard">
		<div class="examName">{{record.name}}</div>
		<div class="examDuration">剩余时间:{{minutes}}分{{seconds}}秒</div>
		<div class="examScore">合格:{{record.passScore}}/总分:{{record.score}}</div>
		<el-button class="btn" type="primary" @click="showSubmitDialog">提交试卷</el-button>
	</div>
</template>

<script>
	import {
		createNamespacedHelpers
	} from 'vuex'
	const {
		mapState,
		mapMutations
	} = createNamespacedHelpers('examDetailsModule')
	import * as api from "api/examDetails.js"

	export default {
		props: {
			record: { //试卷记录
				type: Object,
				// required:true
			},
			exam: { //考试数据
				type: Object,
				required: true
			}
		},
		data() {
			return {
				checkSanswerArr: [], //检查学生答案
				sAnswerArr: [], //学生答案
			}
		},
		computed: {
			...mapState(["minutes", "seconds"]),
			minutes: { //分
				get() {
					return this.$store.state.examDetailsModule.minutes
				},
				set(newVal) {
					this.GET_MINUTES(newVal)
				}
			},
			seconds: { //秒
				get() {
					return this.$store.state.examDetailsModule.seconds
				},
				set(newVal) {
					this.GET_SECONDS(newVal)
				}
			}
		},
		methods: {
			...mapMutations(["GET_MINUTES", "GET_SECONDS", "SET_examOver"]),
			showSubmitDialog() { //显示弹窗
				this.$eventBus.$emit("showSubmitDialog")
			},
			initTime(minutes, seconds) { //初始化时间
				let time = setInterval(async () => {
					if (seconds === 0 && minutes !== 0) {
						seconds = 59
						minutes -= 1
					} else if (seconds === 0 && minutes === 0) {
						seconds = 0
						clearInterval(time) //清除计时器
						this.SET_examOver() //考试结束
						this.$message({
							message: '时间到，将自动提交试卷。',
							type: 'warning'
						});

						// this.$parent.$refs.submitDialog.submitSanswer() //提交试卷
						await this.getSanswer() //获取学生答案
						await this.submitSanswer() //提交试卷
					} else {
						seconds -= 1
					}
					this.minutes = minutes
					this.seconds = seconds

				}, 1000)
				this.$once('hook:beforeDestroy', () => {//离开的时候清除计时器
					clearInterval(time);
					time = null;
				})
			},
			async API_insert(cid, expid, eid, answer) { //提交试卷接口
				let result = {
					cid, //班级id
					expid, //试卷id
					eid, //考试id
					answer //学生答案
				}
				return await api.insert(result)
			},
			async submitSanswer() { //提交学生答案
				this.submitLoading = true
				let res = await this.API_insert(this.exam.cid, this.exam.expid, this.exam.id, JSON.stringify(this.sAnswerArr))
				this.submitLoading = false
				this.$message({
					message: res.data.message,
					type: 'success'
				});
				this.$router.replace("/history")
			},
			checkSanswer(type, sanswer) { //检查学生答案
				let sArr = []
				sanswer.map((item, idx) => {
					if (!item) {
						sArr.push(idx + 1)
					}
				})
				return {
					type,
					sArr
				}
			},
			async getSanswer() { //获取学生答案
				let obj = this.$parent.$refs.tabs.$refs
				let checkSanswerArr = [] //检查学生的答案
				let sAnswerArr = [] //学生答案

				Object.values(obj).forEach((item) => {
					let {
						type,
						sArr
					} = this.checkSanswer(item[0]._data.type, item[0]._data.sanswerList)
					if (sArr.length) {
						checkSanswerArr.push({
							type,
							sArr
						})
					}
					sAnswerArr.push({
						type,
						sanswer: item[0]._data.sanswerList
					})
				})

				this.checkSanswerArr = checkSanswerArr
				this.sAnswerArr = sAnswerArr
			},
		},
		created() {
			if (this.minutes && this.seconds) { //如果已经有时间

				this.initTime(this.minutes, this.seconds)
			} else {
				this.initTime(this.record.duration, 0) //初始化时间
				this.GET_MINUTES(this.record.duration) //获取分
				this.GET_SECONDS(0) //获取秒
			}

		}
	}
</script>

<style lang="scss" scoped>
	.examInfoCard {
		width: 200px;
		height: 250px;
		border: solid 1px #e6e6e6;
		border-radius: 6px;
		position: fixed;
		top: 20%;
		right: 2%;
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: space-around;
		background: #fff;
		overflow: hidden;
		z-index: 1;

		.examName {
			//试卷名称
			font-size: 28px;
		}
	}
</style>
