<template>
	<div class="loading" v-loading="loading"></div>
</template>

<script>
	import * as api from "api/userInfo.js";

	import {
		createNamespacedHelpers
	} from 'vuex'
	const {
		mapActions
	} = createNamespacedHelpers('userModule')

	export default {
		data(){
			return{
				loading:false//loading效果
			}
		},
		methods: {
			...mapActions(["ASYNC_GET_TOKEN", "ASYNC_GET_USER_INFO"]),
			async API_GET_INFO() { //获取用户信息
				let res = await api.getInfo()
				return res
			},
			async toLogin() { //登录操作
				this.loading = true
				let token = this.$route.query.token //获取token

				if (token && token !== "null") { //有token并且不为空
					await this.ASYNC_GET_TOKEN(token)//存token

					let res = await this.API_GET_INFO()//获取用户信息
					if (res.data.statusCode === "200") { //登录成功
						await this.ASYNC_GET_USER_INFO(res.data.content) //存用户信息
						this.$message({
							message: '登录成功',
							type: 'success'
						});
						this.loading = false
						this.$router.push("/home")
					} else {
						this.$message.error('登录失败');
						this.loading = false
						this.$router.replace("/")
					}
				} else {
					this.$message.error('登录失败');
					this.loading = false
					this.$router.replace("/")
				}
			}
		},
		created() {
			this.toLogin()
		}
	};
</script>

<style>
	.loading {
		height: 100%;
	}

	.loading .ant-spin-nested-loading {
		height: 100%;
	}

	.ant-spin-nested-loading>div>.ant-spin {
		max-height: 100%;
	}
</style>
