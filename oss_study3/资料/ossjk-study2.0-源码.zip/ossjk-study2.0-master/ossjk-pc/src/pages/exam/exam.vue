/**
* @Description: 考试列表页
* @author Administrator
*/
<template>
	<div class="exam main_container">
		<div class="main_title">考试安排</div>
		<div class="container-box main">
			
			<!-- 日历 -->
			<div class="calendar">
				<calendar></calendar>
			</div>
			
			<!-- 日历信息 -->
			<div class="dateInfo box">
				<date-info></date-info>
			</div>
			
			<!-- 考试信息说明 -->
			<div class="examInfo box">
				<exam-info></exam-info>
			</div>
		</div>
	</div>
</template>

<script>
	import calendar from "./components/calendar.vue"
	import dateInfo from "./components/dateInfo.vue"
	import examInfo from "./components/examInfo.vue"
	
	export default {
		components:{
			calendar,
			dateInfo,
			examInfo
		},
		created(){
			localStorage.removeItem("minutes")
			localStorage.removeItem("seconds")
		}
	}
</script>

<style lang="scss" scoped>
	.exam {
		display: flex;
		flex-direction: column;

		.main {
			//主体内容
			width: 80%;
			flex: 1;
			display: grid;
			grid-template-columns: repeat(3, 1fr);
			grid-template-rows: repeat(2, 1fr);

			.calendar {//日历组件
				grid-column-start: 1;
				grid-column-end: 3;
				grid-row-start: 1;
				grid-row-end: 3;
				padding: 40px;
				box-sizing: border-box;
			}
			
			.box{//日历标记说明
				padding: 20px;
				box-sizing: border-box;
			}
		}
	}
</style>
