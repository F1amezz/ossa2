/**
  * @Description: 考试信息说明
  * @author Administrator
  */
<template>
	<div class="examInfo" v-loading="loading">
		<div class="title">{{date}} 考试信息</div>
		
		<div class="container">
			<template v-if="examInfo">
				<div class="examName examItem">考试名称:{{examInfo.expname}}</div>
				
				<div class="examType examItem">考试类型:{{exptype(examInfo.exptype)}}</div>
				
				<div class="examScore examItem">试卷分数:{{examInfo.exppassscore}}/{{examInfo.expscore}}</div>
				
				<div class="score examItem">你的得分:</div>
				
				<div class="duration examItem">考试时长:{{examInfo.expduration}}分钟</div>
			</template>
			
			<template v-else>
				<div class="noExam">暂无考试</div>
			</template>
		</div>
	</div>
</template>

<script>
	import * as api from "api/exam.js"
	
	export default{
		data(){
			return{
				examInfo:"",//考试信息
				loading:false,//loading
				date:""//日期
			}
		},
		computed:{
			ossjk_exam_date(){//考试日期
				return this.$store.state.examModule.ossjk_exam_date
			},
			cid(){//班级id
				return this.$store.state.userModule.userInfo.clzid
			}
		},
		watch:{
			ossjk_exam_date:{//监听日期变化，获取考试信息内容
				async handler(date){
					this.loading = true
					let res = await this.API_examList(this.cid,date)
					this.loading = false
					this.examInfo = res.data.content[0]
					this.date = date
				},
				immediate:true
			}
		},
		methods:{
			async API_examList(cid,date){//获取考试信息内容
				let result = {
					params:{
						cid,//班级id
						date//日期 格式:yyyy-mm-dd
					}
				}
				return await api.examList(result)
			},
			exptype(type){//考试类型过滤
				if(type === "1"){
					type = "小测"
				}else if(type === "2"){
					type = "周测"
				}else if(type === "3"){
					type = "阶段测"
				}else if(type === "4"){
					type = "面试测"
				}
				return type
			}
		}
	}
</script>

<style lang="scss" scoped>
	.examInfo{
		width: 100%;
		height: 100%;
		border: solid 1px #e6e6e6;
		border-radius: 6px;
		display: flex;
		flex-direction: column;
		&:hover{
			box-shadow: 3px 3px 3px 3px;
		}
		.title{//标题
			text-align: center;
			padding: 10px 0;
		}
		.container{//容器
			flex:1;
			padding: 0 40px;
			box-sizing: border-box;
			display: flex;
			flex-direction: column;
			justify-content: space-around;
			.noExam{//无信息
				text-align: center;
			}
		}
	}
</style>
