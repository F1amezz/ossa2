/**
  * @Description: 日历标记说明
  * @author Administrator
  */
<template>
	<div class="dateInfo">
		<div class="title">日历标记说明</div>
		<div class="info">
			<div class="info-item">
				<span class="green box"></span>
				<p>:当天已参加考试</p>
			</div>
			
			<div class="info-item">
				<span class="red box"></span>
				<p>:当天错过的考试</p>
			</div>
		</div>
		
		<div class="btn">
			<el-button type="primary" v-if="statusCode === 200" @click="start">开始考试</el-button>
			<el-button type="info" disabled v-else>当天没有考试</el-button>
		</div>
	</div>
</template>

<script>
	import { createNamespacedHelpers } from 'vuex'
	const { mapState } = createNamespacedHelpers('userModule')
	
	import * as api from "api/exam.js"
	
	export default{
		data(){
			return{
				statusCode:"300",//状态码 200:今天有考试 '300':今天没有考试
				exam:""//考试信息
			}
		},
		computed:{
			...mapState(['userInfo'])
		},
		methods:{
			async API_list(cid){//获取试卷API
				let result = {
					params:{
						cid//班级id
					}
				}
				return await api.list(result)
			},
			start(){//开始考试-进入考试详情页
				this.$router.replace("/examDetails")
			}
		},
		async created() {
			let res = await this.API_list(this.userInfo.clzid)
			console.log(res)
			this.statusCode = res.data.statusCode
			this.exam = res.data.exam
		}
	}
</script>

<style lang="scss" scoped>
	.dateInfo{
		width: 100%;
		height: 100%;
		border: solid 1px #e6e6e6;
		border-radius: 6px;
		display: flex;
		flex-direction: column;
		justify-content: space-around;
		align-items: center;
		&:hover{
			box-shadow: 3px 3px 3px 3px;
		}
		.title{//标题
			font-size: 20px;
		}
		.info{
			.info-item{
				display: flex;
				align-items: center;
				.box{
					width: 20px;
					height: 20px;
					display: block;
				}
				.green{
					background: rgba(123, 241, 93, 0.7);
				}
				.red{
					background: rgba(223, 8, 8, 0.7);
				}
			}
		}
	}
</style>
