/**
  * @Description: 日历组件
  * @author Administrator
  */
<template>
	<el-calendar class="calendar" v-model="date"></el-calendar>
</template>

<script>
	import { createNamespacedHelpers } from 'vuex'
	const { mapMutations } = createNamespacedHelpers('examModule')
	
	import {formDate} from "utils/formDate.js"
	
	export default {
		data() {
			return {
				date: new Date()
			}
		},
		watch:{
			date:{
				handler(date){
					this.GET_DATE(formDate(date))
				},
				immediate:true
			}
		},
		methods:{
			...mapMutations(["GET_DATE"])
		}
	}
</script>

<style lang="scss" scoped>
	.calendar{
		border-radius: 6px;
		overflow: hidden;
		&:hover{
			box-shadow: 3px 3px 3px 3px;
		}
		/deep/.el-calendar-day{//控制每个日历组件每个单元格高度
			height: 40px;
			padding: 0px;
			text-align: center;
			line-height: 40px;
		}
	}
</style>
