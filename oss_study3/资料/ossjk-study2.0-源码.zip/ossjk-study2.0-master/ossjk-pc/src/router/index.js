/*
 * @Descripttion: 路由唯一出口
 * @version: 
 * @Author: Bruce
 * @Date: 2020-08-06 09:56:54
 * @LastEditors: Bruce
 * @LastEditTime: 2020-08-10 11:53:37
 */
import Vue from "vue"
import VueRouter from "vue-router"
import {routes} from "./routes/commonRoutes"
import store from "@/store/index.js"

Vue.use(VueRouter)

let router = new VueRouter({
    routes
})

// 路由拦截
router.beforeEach((to,from,next)=>{
    let bool = to.matched.some(item => item.meta.requiresAuth)
    if(bool){//如果这个路由需要拦截,就判断是否有token
		let token = store.state.userModule.token
        
        if(!token){//如果没有则回登录页
            next("/login")
        }else{//如果有token，则通过
            next()
        }
    }else{//如果不需要拦截，则让其通过
        next()
    }
})

export default  router