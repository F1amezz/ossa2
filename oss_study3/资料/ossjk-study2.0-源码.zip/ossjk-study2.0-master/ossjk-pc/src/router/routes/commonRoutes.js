/*
 * @Descripttion: 公共路由
 * @version: 
 * @Author: Bruce
 * @Date: 2020-08-06 09:58:38
 * @LastEditors: Bruce
 * @LastEditTime: 2020-08-10 11:12:22
 */
import layout from "@/components/layout/layout"
export const routes = [{
	path: "/login", //登录页
	name: "login",
	alias: "/",
	meta: {
		requiresAuth: false //不需要拦截
	},
	component: () => import("@/pages/login/login")
}, {
	path: "/main", //主要内容
	name: "main",
	component: layout,
	meta: {
		requiresAuth: true //需要拦截
	},
	children: [{
		path: "/home", //首页
		alias: "/main",
		name: "home",
		meta: {
			requiresAuth: true //需要拦截
		},
		component: () => import("@/pages/home/home")
	}, {
		path: "/exam", //考试列表页
		name: "exam",
		meta: {
			requiresAuth: true //需要拦截
		},
		component: () => import("@/pages/exam/exam")
	}, {
		path: "/examDetails", //考试详情页
		name: "examDetails",
		meta: {
			requiresAuth: true //需要拦截
		},
		component: () => import("@/pages/examDetails/examDetails")
	}, {
		path: "/history", //历史列表页
		name: "history",
		meta: {
			requiresAuth: true //需要拦截
		},
		component: () => import("@/pages/history/history")
	}, {
		path: "/historyDetails", //历史详情页
		name: "historyDetails",
		meta: {
			requiresAuth: true //需要拦截
		},
		props: (route) => ({
			id: route.query.id
		}),
		component: () => import("@/pages/historyDetails/historyDetails")
	}, ]
}, {
	path: "/loading", //loading页
	name: "loading",
	meta: {
		requiresAuth: false //不需要拦截
	},
	component: () => import('@/pages/loading/loading'),
}, {
	path: "*", //404页
	name: "404",
	meta: {
		requiresAuth: false //不需要拦截
	},
	component: () => import("@/pages/404/404")
}]
