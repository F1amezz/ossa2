/*
 * @Descripttion: element-ui
 * @version: 
 * @Author: Bruce
 * @Date: 2020-08-06 15:34:07
 * @LastEditors: Bruce
 * @LastEditTime: 2020-08-06 16:02:18
 */
import Vue from "vue"
import ElementUI from "element-ui"
import 'element-ui/lib/theme-chalk/index.css';
import 'element-ui/lib/theme-chalk/display.css';

Vue.use(ElementUI)