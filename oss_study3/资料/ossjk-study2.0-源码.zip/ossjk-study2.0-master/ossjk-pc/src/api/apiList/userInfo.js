/**
 * @Description: 用户接口
 * @author JUN
 */
import {
	ajaxGet
} from "utils/request.js"

/**
 * 方法说明 获取用户信息
 * @param 
 * @return 
 */
export const getInfo = (data, config) => {
	const url = "pc/user/getInfo"
	return ajaxGet(url, data, config)
}
