/**
  * @Description: 历史详情页
  * @author JUN
  */
import { ajaxGet } from "@/utils/request.js"

/**
  * 方法说明 获取成绩单
  * @param 
  * @return 
  */
export function transcriptById(config){
	const url = "/pc/api/transcript/transcriptById"
	return ajaxGet(url,config)
}