/**
 * @Description: 首页接口
 * @author JUN
 */
import {
	ajaxGet
} from "@/utils/request.js"

/**
 * 方法说明 获取所有学生该考的试卷
 * @param 
 * @return 
 */
export function listMark(config) {
	const url = "/pc/api/daily/listMark"
	return ajaxGet(url, config)
}

/**
 * 方法说明 获取成绩单列表
 * @param 
 * @return 
 */
export function reportList(config) {
	const url = "/pc/api/transcript/list"
	return ajaxGet(url, config)
}

/**
 * 方法说明 获取成绩单列表
 * @param 
 * @return 
 */
export function examNum(config) {
	const url = "/pc/api/index/getCount"
	return ajaxGet(url, config)
}
