/**
 * @Description: 历史列表页
 * @author JUN
 */
import {
	ajaxGet
} from "@/utils/request.js"

/**
 * @name 获取成绩单列表
 * @description: 
 * @param {date:string} 查询时间：1-参数为空查询所有数据、2-参数（yyyy-MM）查询当月数据、3-参数（yyyy-MM-dd）查询当日数据
 * @return 
 */
export function list(config) {
	const url = "/pc/api/transcript/list"
	return ajaxGet(url, config)
}
