/**
 * @Description:登录页接口
 * @author JUN
 */
import {
	ajaxPost
} from "utils/request.js"

/**
 * 方法说明 登录
 * @param {lname:string} 登录名
 * @param {pwd:string} 密码
 */
export const login = (data, config) => {
	const url = "pc/user/login"
	return ajaxPost(url, data, config)
}
