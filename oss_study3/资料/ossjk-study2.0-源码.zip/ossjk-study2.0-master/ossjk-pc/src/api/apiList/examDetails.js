/**
 * @Description: 考试详情页接口
 * @author JUN
 */
import {
	ajaxPost,
	ajaxGet
} from "@/utils/request.js"

/**
 * 方法说明 获取试卷，知识点API
 * @param {cid:String} 班级id
 * @return 
 */
export function dailyOne(config) {
	const url = "/pc/api/daily/dailyOne"
	return ajaxGet(url, config)
}

/**
 * 方法说明 提交试卷
 * @param 
 * @return 
 */
export function insert(data, config) {
	const url = "/pc/api/daily/insert"
	return ajaxPost(url, data, config)
}
