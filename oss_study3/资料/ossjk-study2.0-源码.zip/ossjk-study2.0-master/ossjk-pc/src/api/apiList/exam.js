/**
 * @Description:考试列表页接口
 * @author JUN
 */

import {
	ajaxGet
} from "@/utils/request.js"

/**
 * 方法说明 获取试卷API
 * @param {cid:string} 班级id
 * @return 
 */
export function list(config) {
	const url = "/pc/api/daily/list"
	return ajaxGet(url, config)
}

/**
 * 方法说明 获取所有学生该考的试卷
 * @param 
 * @return 
 */
export function listMark(config) {
	const url = "/pc/api/daily/listMark"
	return ajaxGet(url, config)
}

/**
 * 方法说明 获取成绩单列表
 * @param 
 * @return 
 */
export function reportList(config) {
	const url = "/pc/api/transcript/list"
	return ajaxGet(url, config)
}

/**
 * 方法说明 获取考试信息内容
 * @param {cid:String} 班级id
 * @param {date:String} 日期 格式:yyyy-mm-dd
 * @return 
 */
export function examList(config) {
	const url = "/pc/api/daily/examList"
	return ajaxGet(url, config)
}
