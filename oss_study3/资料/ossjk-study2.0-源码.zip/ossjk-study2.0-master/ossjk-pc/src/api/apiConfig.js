/*
 * @Descripttion: axios配置
 * @version: 
 * @Author: Bruce
 * @Date: 2020-08-06 14:14:15
 * @LastEditors: Bruce
 * @LastEditTime: 2020-08-10 10:59:19
 */
import axios from "axios"
import store from "@/store/index.js"
import router from "@/router/index.js"
import {
	Message
} from 'element-ui';

var httpRequest = axios.create({
	baseURL: 'https://s2.ossjk.com/',
	// baseURL:'http://192.168.1.11:18098',
	// baseURL:'http://cjs.4yd67.cn:18098/',
	timeout: 10000,
	headers: {
		'content-type': 'application/x-www-form-urlencoded'
	}
});

// 添加请求拦截器
httpRequest.interceptors.request.use(function(config) {
	// 每次请求都带上token

	let token = store.state.userModule.token
	if (token) {
		config.headers.token = token
	}

	return config;
}, function(error) {
	// 对请求错误做些什么
	return Promise.reject(error);
});

// 添加响应拦截器
httpRequest.interceptors.response.use(function(response) {
	// 对响应数据做点什么
	let code = response.data.statusCode //状态码
	
	switch (code) {
		case '1006':
			{ //没有token,返回登陆页
				console.log(1006)
				Message.error('请登陆后再访问页面!');
				router.replace('/') // 重定向到登录页
				break;
			}

		case '1007':
			{ //刷新token
				console.log(1007)
				console.log(response)
				store.commit('userModule/GET_TOKEN', response.data.content) //获取刷新后的token

				// 重置配置
				let config = response.config
				config.headers.token = response.data.content
				config.baseURL = '' //url已经带上/api,避免出现/api/api的情况
				return httpRequest.request(config) //重新发起请求
			}

		case '1008':
			{ //token超时
				console.log(1008)
				Message.error('登陆超时请重新登陆!');
				store.commit('userModule/REMOVE_ALL') //删除所有信息
				router.replace('/') // 重定向到登录页
				break;
			}


		case '1009':
			{ //账号在其他地方登陆
				console.log(1009)
				Message.error('账号已在其他地方登陆!');
				store.commit('userModule/REMOVE_ALL') //删除所有信息
				router.replace('/') //重定向到登录页
				break;
			}


		default:
			{ //正常
				console.log(1000)
			}

	}

	return response;
}, function(error) {
	// 对响应错误做点什么
	return Promise.reject(error);
});

export default httpRequest
