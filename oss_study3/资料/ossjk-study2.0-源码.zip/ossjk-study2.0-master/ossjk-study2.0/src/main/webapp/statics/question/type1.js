//----------------------------单选题逻辑----------------------------
var choiceListTag = new Array('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H');

// 添加选项
function initType1() {
	
	//初始化答案
	
	
	// 初始化题目内容参数
	var content = $("#fd_type1", navTab.getCurrentPanel()).data("content");
	if (!content) {
		var init_content = {
			"title" : "",
			"choiceList" : {
				"A" : "",
				"B" : "",
				"C" : "",
				"D" : ""
			}
		};
		$("#fd_type1", navTab.getCurrentPanel()).data("content", JSON.stringify(init_content));
		content = init_content;
	} else {
		// if(typeof content == 'string'){
		content = JSON.parse(content);
		// }
	}
	// 初始化答案参数
	var answer = $("#fd_type1", navTab.getCurrentPanel()).data("answer");
	if (!answer) {
		var init_answer = "A";
		$("#fd_type1", navTab.getCurrentPanel()).data("answer", init_answer);
		answer = init_answer;
	}
	// 清空内容
	$("#fd_type1", navTab.getCurrentPanel()).empty();

	// 动态渲染内容
	var bodyStr = '';
	bodyStr += '<legend>单选题</legend>';
	bodyStr += '<dl class="nowrap"><dt>试题内容：</dt><dd><textarea class="title textInput" cols="80" rows="2">' + content.title + '</textarea></dd></dl>';
	// 选项
	bodyStr += '<dl class="nowrap"><dt>选项：</dt><dd><div id="choiceList">';
	var index = 0;
	for (choice in content.choiceList) {
		//bodyStr += '<p><label>' + choice + '：</label> <input type="text" class="textInput choice" value="' + content.choiceList[choice] + '" />';
		bodyStr += '<p class="nowrap"><label>' + choice + '：</label><textarea class="title choice textInput" cols="80" rows="2">' + content.choiceList[choice]  + '</textarea>';
		if (index >= 2) {
			bodyStr += '<a class="button" style="margin-left: 10px" href="javascript:;" onclick="type1_sub_choice()" ><span>删除</span></a>';
		}
		if (index == (Object.keys(content.choiceList).length-1)) {
			bodyStr += '<a class="button" style="margin-left: 10px" href="javascript:;" onclick="type1_add_choice()"><span>添加</span></a>';
		}
		bodyStr+='</p>';
		index++;
	}
	//bodyStr += '<a class="button" href="javascript:;" onclick="type1_add_choice()"><span>添加</span></a>';
	bodyStr += '</div></dd></dl>';
	// 答案
	bodyStr += '<dl class="nowrap"><dt>答案：</dt><dd><select class="answer">';
	var index = 0;
	for (choice in content.choiceList) {
		bodyStr += '<option class="opt_answer">' + choice + '</option>';
		index++;
	}
	bodyStr += '</select></dd></dl>';
	$("#fd_type1", navTab.getCurrentPanel()).html(bodyStr);

	if (answer < choiceListTag[index]) {
		$("#fd_type1 .answer", navTab.getCurrentPanel()).val(answer);
	} else {
		$("#fd_type1 .answer", navTab.getCurrentPanel()).val(choiceListTag[0]);
	}

}

function type1_sub_choice() {
	type1_flush_data();
	var content = JSON.parse($("#fd_type1", navTab.getCurrentPanel()).data("content"));
	var choices = $("#fd_type1 .choice", navTab.getCurrentPanel());
	delete content.choiceList[choiceListTag[choices.length - 1]];
	$("#fd_type1", navTab.getCurrentPanel()).data("content", JSON.stringify(content));
	initType1();
}

function type1_add_choice() {
	type1_flush_data();
	var content = JSON.parse($("#fd_type1", navTab.getCurrentPanel()).data("content"));
	var choices = $("#fd_type1 .choice", navTab.getCurrentPanel());
	if (choices.length >= choiceListTag.length) {
		alertMsg.error("选项大于限制！");
		return;
	}
	content.choiceList[choiceListTag[choices.length]] = '';
	$("#fd_type1", navTab.getCurrentPanel()).data("content", JSON.stringify(content));
	initType1();
}

function type1_flush_data() {
	// 把标签内容同步到根标签的DATA里面去
	var content = JSON.parse($("#fd_type1", navTab.getCurrentPanel()).data("content"));
	content.title = $("#fd_type1 .title", navTab.getCurrentPanel()).val();
	var choices = $("#fd_type1 .choice", navTab.getCurrentPanel());
	var choiceList = {};
	for (var i = 0; i < choices.length; i++) {
		choiceList[choiceListTag[i]] = choices[i].value;
	}
	content.choiceList = choiceList;
	$("#fd_type1", navTab.getCurrentPanel()).data("content", JSON.stringify(content));

	var answer = $("#fd_type1 .answer", navTab.getCurrentPanel()).val();
	$("#fd_type1", navTab.getCurrentPanel()).data("answer", answer);

}