//----------------------------多选题逻辑----------------------------
var choiceListTag = new Array('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H');

// 添加选项
function initType2() {
	var content = $("#fd_type2", navTab.getCurrentPanel()).data("content");
	if (!content) {
		var init_content = {
			"title" : "",
			"choiceList" : {
				"A" : "",
				"B" : "",
				"C" : "",
				"D" : ""
			}
		};
		$("#fd_type2", navTab.getCurrentPanel()).data("content", JSON.stringify(init_content));
		content = init_content;
	} else {
		if(typeof content == 'string'){
			content = JSON.parse(content);
		}
	}
	var answer = $("#fd_type2", navTab.getCurrentPanel()).data("answer");
	if (!answer) {
		var init_answer = "";
		$("#fd_type2", navTab.getCurrentPanel()).data("answer", init_answer);
		answer = init_answer;
	}

	$("#fd_type2", navTab.getCurrentPanel()).empty();
	var bodyStr = '';
	bodyStr += '<legend>多选题</legend>';
	bodyStr += '<dl class="nowrap"><dt>试题内容：</dt><dd><textarea class="title textInput" cols="80" rows="2">' + content.title + '</textarea></dd></dl>';
	// 选项
	bodyStr += '<dl class="nowrap"><dt>选项：</dt><dd><div id="choiceList">';
	var index = 0;
	for (choice in content.choiceList) {
//		bodyStr += '<p><label>' + choice + '：</label> <input type="text" class="textInput choice" value="' + content.choiceList[choice] + '" />';
		bodyStr += '<p class="nowrap"><label>' + choice + '：</label><textarea class="title choice textInput" cols="80" rows="2">' + content.choiceList[choice]  + '</textarea>';
		if (index >= 2) {
			bodyStr += '<a class="button" style="margin-left: 10px" href="javascript:;" onclick="type2_sub_choice()" ><span>删除</span></a>';
		}
		if (index == (Object.keys(content.choiceList).length-1)) {
			bodyStr += '<a class="button" style="margin-left: 10px" href="javascript:;" onclick="type2_add_choice()"><span>添加</span></a>';
		}
//		if (index >= 2) {
//			bodyStr += '<a class="button" style="margin-left: 10px" href="javascript:;" onclick="type2_sub_choice()" ><span>删除</span></a>';
//		}
		bodyStr+='</p>';
		index++;
	}
	//bodyStr += '<a class="button" href="javascript:;" onclick="type2_add_choice()"><span>添加</span></a>';
	bodyStr += '</div></dd></dl>';
	// 答案
	bodyStr += '<dl class="nowrap"><dt>答案：</dt><dd>';
	var index = 0;
	for (choice in content.choiceList) {
		bodyStr += '<label class="answer"><input type="checkbox" value="' + choice + '" />' + choice + '</label>';
		index++;
	}
	bodyStr += '</dd></dl>';

	$("#fd_type2", navTab.getCurrentPanel()).html(bodyStr);
	var answerTag = $("#fd_type2 .answer input", navTab.getCurrentPanel());
	var answerArray = new Array();
	for (var i = 0; i < answerTag.length; i++) {
		if (answer.indexOf(answerTag[i].value) != -1) {
			answerTag[i].checked = true;
		}
	}

}

function type2_sub_choice() {
	type2_flush_data();
	var content = JSON.parse($("#fd_type2", navTab.getCurrentPanel()).data("content"));
	var choices = $("#fd_type2 .choice", navTab.getCurrentPanel());
	delete content.choiceList[choiceListTag[choices.length - 1]];
	$("#fd_type2", navTab.getCurrentPanel()).data("content", JSON.stringify(content));
	initType2();
}
function type2_add_choice() {
	type2_flush_data();
	var content = JSON.parse($("#fd_type2", navTab.getCurrentPanel()).data("content"));
	var choices = $("#fd_type2 .choice", navTab.getCurrentPanel());
	if (choices.length >= choiceListTag.length) {
		alertMsg.error("选项大于限制！");
		return;
	}
	content.choiceList[choiceListTag[choices.length]] = '';
	$("#fd_type2", navTab.getCurrentPanel()).data("content", JSON.stringify(content));
	initType2();
}

function type2_flush_data() {
	var content = JSON.parse($("#fd_type2", navTab.getCurrentPanel()).data("content"));
	content.title = $("#fd_type2 .title", navTab.getCurrentPanel()).val();
	var choices = $("#fd_type2 .choice", navTab.getCurrentPanel());
	var choiceList = {};
	for (var i = 0; i < choices.length; i++) {
		choiceList[choiceListTag[i]] = choices[i].value;
	}
	content.choiceList = choiceList;
	$("#fd_type2", navTab.getCurrentPanel()).data("content", JSON.stringify(content));
	var answer = $("#fd_type2 .answer input", navTab.getCurrentPanel());
	var answerArray = new Array();
	for (var i = 0; i < answer.length; i++) {
		if (answer[i].checked == true) {
			answerArray.push(choiceListTag[i]);
		}
	}
	$("#fd_type2", navTab.getCurrentPanel()).data("answer", answerArray + "");

}