//----------------------------填空题逻辑----------------------------
// 添加选项
function initType4() {
	var content = $("#fd_type4", navTab.getCurrentPanel()).data("content");
	if (!content) {
		var init_content = {
			"title" : "",
			"choiceList" : {}
		};
		$("#fd_type4", navTab.getCurrentPanel()).data("content", JSON.stringify(init_content));
		content = init_content;
	} else {
		if (typeof content == 'string') {
			content = JSON.parse(content);
		}
	}
	var sort = $("#fd_type4", navTab.getCurrentPanel()).data("sort");
	var answer = $("#fd_type4", navTab.getCurrentPanel()).data("answer");
	if (!answer) {
		var init_answer = "";
		$("#fd_type4", navTab.getCurrentPanel()).data("answer", init_answer);
		answer = init_answer;
	}

	$("#fd_type4", navTab.getCurrentPanel()).empty();
	var bodyStr = '';
	bodyStr += '<legend>填空题</legend>';
	bodyStr += '<dl class="nowrap"><dt>试题内容：</dt><dd><textarea class="title" cols="80" rows="2">' + content.title + '</textarea></dd></dl>';
	bodyStr += '<dl class="nowrap"><dt>答案顺序：</dt><dd>';
	bodyStr += '<select class="isSort">';
	bodyStr += '<option value="1">无序</option>';
	bodyStr += '<option value="2">有序</option>';
	bodyStr += '</select>';
	bodyStr += '</dd></dl>';
	// 答案
	bodyStr += '<dl class="nowrap"><dt>答案：</dt><dd>';
	bodyStr += '<div class="blank">';
	if (answer) {
		var answerArray = answer;
		for (var i = 0; i < answerArray.length; i++) {
			bodyStr += '<input type="text" class="textInput answer" value="' + answerArray[i] + '" />';
		}

	}
	bodyStr += '</div></dd></dl>';

	$("#fd_type4", navTab.getCurrentPanel()).html(bodyStr);
	$("#fd_type4 .isSort", navTab.getCurrentPanel()).val(sort);

	$('#fd_type4 .title', navTab.getCurrentPanel()).bind('input propertychange', function() {
		var questionContent = $(this, navTab.getCurrentPanel()).val();
		var blankSize = questionContent.split('(__)').length - 1;
		if (blankSize) {
			/* <input type="text" class="textInput required" > */
			var ansewerSize = $("#fd_type4 .blank", navTab.getCurrentPanel()).children('.answer').length;
			if (ansewerSize != blankSize) {
				$("#fd_type4 .blank", navTab.getCurrentPanel()).empty();
				for (var i = 0; i < blankSize; i++) {
					$("#fd_type4 .blank", navTab.getCurrentPanel()).append('<input type="text" class="textInput answer" />');
				}
			}
		}
	});
}

function type4_flush_data() {
	var content = JSON.parse($("#fd_type4", navTab.getCurrentPanel()).data("content"));
	content.title = $("#fd_type4 .title", navTab.getCurrentPanel()).val();
	var answer = $("#fd_type4 .blank .answer", navTab.getCurrentPanel());
	var isSort = $("#fd_type4 .isSort", navTab.getCurrentPanel()).val();
	var answerArray = [];
	for (var i = 0; i < answer.length; i++) {
		var answerEncode = HtmlUtil.htmlEncode();
		answerArray.push(answer[i].value);
	}
	$("#fd_type4", navTab.getCurrentPanel()).data("content", JSON.stringify(content));
	$("#fd_type4", navTab.getCurrentPanel()).data("answer", JSON.stringify(answerArray));
	$("#fd_type4", navTab.getCurrentPanel()).data("sort", isSort);

}
