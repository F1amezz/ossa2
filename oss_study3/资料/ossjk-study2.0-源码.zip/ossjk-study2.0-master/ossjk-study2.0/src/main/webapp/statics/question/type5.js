//----------------------------简答题、分析题、论述题逻辑----------------------------
// 添加选项
function initType5() {
	var content = $("#fd_type5", navTab.getCurrentPanel()).data("content");
	if (!content) {
		var init_content = {
			"title" : "",
			"choiceList" : {}
		};
		$("#fd_type5", navTab.getCurrentPanel()).data("content", JSON.stringify(init_content));
		content = init_content;
	} else {
		if (typeof content == 'string') {
			content = JSON.parse(content);
		}
	}
	var answer = $("#fd_type5", navTab.getCurrentPanel()).data("answer");
	if (!answer) {
		var init_answer = "";
		$("#fd_type5", navTab.getCurrentPanel()).data("answer", init_answer);
		answer = init_answer;
	}

	$("#fd_type5", navTab.getCurrentPanel()).empty();
	var bodyStr = '';
	bodyStr += '<legend>简答题、编程题、逻辑题</legend>';
	bodyStr += '<dl class="nowrap"><dt>试题内容：</dt><dd><textarea class="title" cols="80" rows="5">' + content.title + '</textarea></dd></dl>';
	// 答案
	bodyStr += '<dl class="nowrap"><dt>答案：</dt><dd>';
	bodyStr += '<textarea class="answer" cols="100" rows="16">'+answer+'</textarea>';
	bodyStr += '</dd></dl>';

	$("#fd_type5", navTab.getCurrentPanel()).html(bodyStr);

}

function type5_flush_data() {
	var content = JSON.parse($("#fd_type5", navTab.getCurrentPanel()).data("content"));
	content.title = $("#fd_type5 .title", navTab.getCurrentPanel()).val();
	$("#fd_type5", navTab.getCurrentPanel()).data("content", JSON.stringify(content));
	var answer = HtmlUtil.htmlEncode($("#fd_type5 .answer", navTab.getCurrentPanel()).val());
	var answerJson={
			"answer":answer
	}
	$("#fd_type5", navTab.getCurrentPanel()).data("answer",JSON.stringify(answerJson) );

}
