//----------------------------判断题逻辑----------------------------
//添加选项
function initType3() {
	var content = $("#fd_type3", navTab.getCurrentPanel()).data("content");
	if (!content) {
		var init_content = {
			"title" : "",
			// "choiceList" : {
			// 	"正确" : "T",
			// 	"错误" : "F",
			// }
            "choiceList" : {
                "T" : "正确",
                "F" : "错误",
            }
		};
		$("#fd_type3", navTab.getCurrentPanel()).data("content", JSON.stringify(init_content));
		content = init_content;
	} else {
		if (typeof content == 'string') {
			content = JSON.parse(content);
		}
	}
	var answer = $("#fd_type3", navTab.getCurrentPanel()).data("answer");
	if (!answer) {
		var init_answer = "";
		$("#fd_type3", navTab.getCurrentPanel()).data("answer", init_answer);
		answer = init_answer;
	}

	$("#fd_type3", navTab.getCurrentPanel()).empty();
	var bodyStr = '';
	bodyStr += '<legend>填空题</legend>';
	bodyStr += '<dl class="nowrap"><dt>试题内容：</dt><dd><textarea class="title" cols="80" rows="2">' + content.title + '</textarea></dd></dl>';
	// 答案
	bodyStr += '<dl class="nowrap"><dt>答案：</dt><dd>';
	bodyStr += '<label><input type="radio" name="r1" class="answer" checked="checked" value="T" />正确</label>';
	bodyStr += '<label><input type="radio" name="r1" class="answer" value="F" />错误</label>';
	bodyStr += '</dd></dl>';

	$("#fd_type3", navTab.getCurrentPanel()).html(bodyStr);
	var answerTag = $("#fd_type3 .answer", navTab.getCurrentPanel());
	for (var i = 0; i < answerTag.length; i++) {
		if (answerTag[i].value == answer) {
			answerTag[i].checked = true;
		}
	}

}
function type3_flush_data() {
	var content = JSON.parse($("#fd_type3", navTab.getCurrentPanel()).data("content"));
	content.title = $("#fd_type3 .title", navTab.getCurrentPanel()).val();
	$("#fd_type3", navTab.getCurrentPanel()).data("content", JSON.stringify(content));
	var answer = $("#fd_type3 .answer", navTab.getCurrentPanel());
	var answerArray = new Array();
	for (var i = 0; i < answer.length; i++) {
		if (answer[i].checked == true) {
			answerArray.push(answer[i].value);
		}
	}
	$("#fd_type3", navTab.getCurrentPanel()).data("answer", answerArray + "");
}
