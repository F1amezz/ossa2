package com.jkoss.study.interview.controller;

import java.util.Arrays;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.baomidou.mybatisplus.mapper.Condition;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.jkoss.base.controller.BaseController;
import com.jkoss.common.util.CommonUtil;
import com.jkoss.common.vo.DwzPageBean;
import com.jkoss.study.interview.entity.Enterprise;
import com.jkoss.study.interview.entity.Post;
import com.jkoss.study.interview.service.IEnterpriseService;
import com.jkoss.study.interview.service.IPostService;

/**
 * 企业表 前端控制器
 * 
 * @Author chair
 * @Version 1.0, 2019-06-20
 * @See
 * @Since com.jkoss.study.interview.controller
 * @Description: TODO
 */
@Controller
@RequestMapping("/interview/enterprise")
public class EnterpriseController extends BaseController {

	@Autowired
	private IEnterpriseService iEnterpriseService;
	@Autowired
	private IPostService iPostService;

	@RequestMapping("/list")
	@RequiresPermissions("/interview/enterprise/list")
	public String list(String name, String scale, DwzPageBean dwzPageBean, ModelMap map, HttpServletRequest request,
			HttpServletResponse response) {
		Wrapper wrapper = Condition.create();

		if (!CommonUtil.isBlank(name)) {
			// 根据学生搜索
			wrapper.like("name", name);
			dwzPageBean.getCountResultMap().put("name", name);
		}
		if (!CommonUtil.isBlank(scale)) {
			// 根据班级搜索
			wrapper.eq("scale", scale);
			dwzPageBean.getCountResultMap().put("scale", scale);
		}
		if (!CommonUtil.isBlank(dwzPageBean.getOrderField()) && !CommonUtil.isBlank(dwzPageBean.getOrderDirection())) {
			wrapper.orderBy(dwzPageBean.getOrderField(), CommonUtil.isEquals(dwzPageBean.getOrderDirection(), "asc"));
		} else {
			// 默认排序字段
			wrapper.orderBy("create_time", false);
		}
		Page resultPage = iEnterpriseService.selectPage(dwzPageBean.toPage(), wrapper);
		map.put("dwzPageBean", dwzPageBean.toDwzPageBean(resultPage));
		return "interview/enterprise/list";
	}

	@RequestMapping("/toInsert")
	@RequiresPermissions("/interview/enterprise/toInsert")
	public String toInsert(HttpServletRequest request, HttpServletResponse response) {
		return "interview/enterprise/edit";
	}

	@RequestMapping("/insert")
	@RequiresPermissions("/interview/enterprise/toInsert")
	@ResponseBody
	public Object insert(@Valid Enterprise enterprise, HttpServletRequest request, HttpServletResponse response) {
		if (iEnterpriseService.insert(enterprise)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}

	}

	@RequestMapping("/toUpdate")
	@RequiresPermissions("/interview/enterprise/toUpdate")
	public String toUpdate(String id, ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		map.put("record", iEnterpriseService.selectById(id));
		return "interview/enterprise/edit";
	}

	@RequestMapping("/update")
	@RequiresPermissions("/interview/enterprise/toUpdate")
	@ResponseBody
	public Object update(@Valid Enterprise enterprise, HttpServletRequest request, HttpServletResponse response) {
		if (iEnterpriseService.updateById(enterprise)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/delete")
	@RequiresPermissions("/interview/enterprise/delete")
	@ResponseBody
	public Object delete(String[] id, HttpServletRequest request, HttpServletResponse response) {
		if (iEnterpriseService.deleteBatchIds(Arrays.asList(id))) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/toDetail")
	@RequiresPermissions("/interview/enterprise/toDetail")
	public String toDetail(String id, ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		map.put("posts", iPostService.selectList(Condition.create().eq("eid", id).orderBy("create_time", true)));
		map.put("record", iEnterpriseService.selectById(id));
		return "interview/enterprise/detail";
	}

	@RequestMapping("/listPost")
	@RequiresPermissions("/interview/enterprise/listPost")
	public String listPost(String name, String eid, String education, String experience, DwzPageBean dwzPageBean,
			ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		Wrapper wrapper = Condition.create();

		if (!CommonUtil.isBlank(name)) {
			// 根据学生搜索
			wrapper.like("name", name);
			dwzPageBean.getCountResultMap().put("name", name);
		}
		if (!CommonUtil.isBlank(education)) {
			// 根据学生搜索
			wrapper.eq("education", education);
			dwzPageBean.getCountResultMap().put("education", education);
		}
		if (!CommonUtil.isBlank(experience)) {
			// 根据学生搜索
			wrapper.eq("experience", experience);
			dwzPageBean.getCountResultMap().put("experience", experience);
		}
		wrapper.eq("eid", eid);
		dwzPageBean.getCountResultMap().put("eid", eid);
		if (!CommonUtil.isBlank(dwzPageBean.getOrderField()) && !CommonUtil.isBlank(dwzPageBean.getOrderDirection())) {
			wrapper.orderBy(dwzPageBean.getOrderField(), CommonUtil.isEquals(dwzPageBean.getOrderDirection(), "asc"));
		} else {
			// 默认排序字段
			wrapper.orderBy("create_time", false);
		}
		Page resultPage = iPostService.selectPage(dwzPageBean.toPage(), wrapper);
		map.put("dwzPageBean", dwzPageBean.toDwzPageBean(resultPage));
		return "interview/enterprise/listPost";
	}

	@RequestMapping("/toInsertPost")
	@RequiresPermissions("/interview/enterprise/toInsertPost")
	public String toInsertPost(String id, ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		map.put("eid", id);
		map.put("dialogId", "/interview/enterprise/listPost");
		return "interview/enterprise/editPost";
	}

	@RequestMapping("/insertPost")
	@RequiresPermissions("/interview/enterprise/toInsertPost")
	@ResponseBody
	public Object insertPost(Post post, ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		if (iPostService.insert(post)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/toUpdatePost")
	@RequiresPermissions("/interview/enterprise/toUpdatePost")
	public String toUpdatePost(String id, ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		map.put("record", iPostService.selectById(id));
		map.put("dialogId", "/interview/enterprise/toUpdatePost");
		return "interview/enterprise/editPost";
	}

	@RequestMapping("/updatePost")
	@RequiresPermissions("/interview/enterprise/toUpdatePost")
	@ResponseBody
	public Object updatePost(Post post, ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		if (iPostService.updateById(post)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/deletePost")
	@RequiresPermissions("/interview/enterprise/deletePost")
	@ResponseBody
	public Object deletePost(String id, HttpServletRequest request, HttpServletResponse response) {
		if (iPostService.deleteById(id)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

}
