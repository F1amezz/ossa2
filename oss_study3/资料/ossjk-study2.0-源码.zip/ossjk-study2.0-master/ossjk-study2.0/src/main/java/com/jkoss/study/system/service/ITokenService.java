package com.jkoss.study.system.service;

import com.baomidou.mybatisplus.service.IService;
import com.jkoss.study.system.entity.Token;

/**
 *  服务类
 * 
 * @Author Jason
 * @Version 1.0, 2019-11-06
 * @See
 * @Since com.jkoss.examination.system.service
 * @Description: TODO
 */
public interface ITokenService extends IService<Token> {

}
