package com.jkoss.study.system.entity;

import java.io.Serializable;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.jkoss.base.entity.BaseEntity;

/**
 * 教师
 * 
 * @Author chair
 * @Version 1.0, 2019-07-23
 * @See
 * @Since com.jkoss.study.system.entity
 * @Description: TODO
 */
public class Teacher extends BaseEntity<Teacher> {

	private static final long serialVersionUID = 1L;

	/**
	 * id
	 */
	@TableId("id")
	private String id;
	/**
	 * 登录名
	 */
	@TableField("lname")
	private String lname;
	/**
	 * 密码
	 */
	@TableField("pwd")
	private String pwd;
	/**
	 * 姓名
	 */
	@TableField("name")
	private String name;
	/**
	 * 年龄
	 */
	@TableField("age")
	private Integer age;
	/**
	 * 微信id
	 */
	@TableField("wxuid")
	private String wxuid;
	/**
	 * 手机号码
	 */
	@TableField("phone")
	private String phone;
	/**
	 * 状态 1-启用、2-停用
	 */
	@TableField("state")
	private Integer state;
	/**
	 * 备注
	 */
	@TableField("remk")
	private String remk;
	/**
	 * 性别 1-男、2-女
	 */
	@TableField("sex")
	private Integer sex;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getWxuid() {
		return wxuid;
	}

	public void setWxuid(String wxuid) {
		this.wxuid = wxuid;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public String getRemk() {
		return remk;
	}

	public void setRemk(String remk) {
		this.remk = remk;
	}

	public Integer getSex() {
		return sex;
	}

	public void setSex(Integer sex) {
		this.sex = sex;
	}

	@Override
	protected Serializable pkVal() {
		return this.id;	
	}

	@Override
	public String toString() {
		return "Teacher{" + ", id=" + id + ", lname=" + lname + ", pwd=" + pwd + ", name=" + name + ", age=" + age + ", wxuid=" + wxuid + ", phone=" + phone + ", state=" + state + ", remk=" + remk + ", sex=" + sex + "}";
	}
}
