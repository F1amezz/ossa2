package com.jkoss.study.educational.entity;

import java.io.Serializable;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.jkoss.base.entity.BaseEntity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 学生
 * 
 * @Author chair
 * @Version 1.0, 2019-07-21
 * @See
 * @Since com.jkoss.study.educational.entity
 * @Description: TODO
 */
// @ApiModel(value = "Student", description = "学生")
public class Student extends BaseEntity<Student> {

	private static final long serialVersionUID = 1L;

	// /**
	// * id
	// */
	// @ApiModelProperty(value = "id", name = "id")
	// @TableId("id")
	// private String id;
	/**
	 * 班级id
	 */
	// @ApiModelProperty(value = "班级id", name = "clzid", example = "")
	@TableField("clzid")
	private String clzid;
	/**
	 * 登录名
	 */
	@TableField("lname")
	private String lname;
	/**
	 * 密码
	 */
	@TableField("pwd")
	private String pwd;
	/**
	 * 姓名
	 */
	@TableField("name")
	private String name;
	/**
	 * 性别 1-男、2-女
	 */
	@TableField("sex")
	private Integer sex;
	/**
	 * 生日
	 */
	@TableField("birth")
	private String birth;
	/**
	 * 手机号码
	 */
	@TableField("phone")
	private String phone;
	/**
	 * 住址
	 */
	@TableField("addr")
	private String addr;
	/**
	 * 头像
	 */
	@TableField("img")
	private String img;
	/**
	 * 备注
	 */
	@TableField("remk")
	private String remk;
	/**
	 * 状态 1-启用、2-停用
	 */
	@TableField("state")
	private Integer state;
	/**
	 * 分组号
	 */
	@TableField("groupno")
	private String groupno;
	/**
	 * 微信id
	 */
	@TableField("wxuid")
	private String wxuid;

	/**
	 * 修改人
	 */
	@TableField("modifier")
	private String modifier;
	/**
	 * 学校
	 */
	@TableField("school")
	private String school;
	/**
	 * 专业
	 */
	@TableField("specialty")
	private String specialty;
	/**
	 * 籍贯
	 */
	@TableField("birthplace")
	private String birthplace;
	/**
	 * 报到时间
	 */
	@TableField("rttm")
	private String rttm;
	/**
	 * 紧急联系人关系
	 */
	@TableField("egrs")
	private Integer egrs;
	/**
	 * 紧急联系人
	 */
	@TableField("egct")
	private String egct;
	/**
	 * 上课时间
	 */
	@TableField("cltm")
	private String cltm;
	/**
	 * 紧急联系人电话
	 */
	@TableField("egph")
	private String egph;
	/**
	 * 身份证
	 */
	@TableField("idcard")
	private String idcard;

	public String getSchool() {
		return school;
	}

	public void setSchool(String school) {
		this.school = school;
	}

	public String getSpecialty() {
		return specialty;
	}

	public void setSpecialty(String specialty) {
		this.specialty = specialty;
	}

	public String getBirthplace() {
		return birthplace;
	}

	public void setBirthplace(String birthplace) {
		this.birthplace = birthplace;
	}

	public String getRttm() {
		return rttm;
	}

	public void setRttm(String rttm) {
		this.rttm = rttm;
	}

	public Integer getEgrs() {
		return egrs;
	}

	public void setEgrs(Integer egrs) {
		this.egrs = egrs;
	}

	public String getEgct() {
		return egct;
	}

	public void setEgct(String egct) {
		this.egct = egct;
	}

	public String getCltm() {
		return cltm;
	}

	public void setCltm(String cltm) {
		this.cltm = cltm;
	}

	public String getEgph() {
		return egph;
	}

	public void setEgph(String egph) {
		this.egph = egph;
	}

	public String getIdcard() {
		return idcard;
	}

	public void setIdcard(String idcard) {
		this.idcard = idcard;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getClzid() {
		return clzid;
	}

	public void setClzid(String clzid) {
		this.clzid = clzid;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getSex() {
		return sex;
	}

	public void setSex(Integer sex) {
		this.sex = sex;
	}

	public String getBirth() {
		return birth;
	}

	public void setBirth(String birth) {
		this.birth = birth;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAddr() {
		return addr;
	}

	public void setAddr(String addr) {
		this.addr = addr;
	}

	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}

	public String getRemk() {
		return remk;
	}

	public void setRemk(String remk) {
		this.remk = remk;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public String getGroupno() {
		return groupno;
	}

	public void setGroupno(String groupno) {
		this.groupno = groupno;
	}

	public String getWxuid() {
		return wxuid;
	}

	public void setWxuid(String wxuid) {
		this.wxuid = wxuid;
	}

	@Override
	protected Serializable pkVal() {
		return this.id;
	}

	@Override
	public String toString() {
		return "Student{" + ", id=" + id + ", clzid=" + clzid + ", lname=" + lname + ", pwd=" + pwd + ", name=" + name + ", sex=" + sex + ", birth=" + birth + ", phone=" + phone + ", addr=" + addr + ", img=" + img + ", remk=" + remk + ", state=" + state + ", groupno=" + groupno + ", wxuid=" + wxuid + "}";
	}
}
