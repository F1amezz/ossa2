package com.jkoss.study.learn.vo;

import com.jkoss.study.learn.entity.Feedback;

/**
 * 反馈表Vo
 * 
 * @Author chair
 * @Version 1.0, 2019-06-14
 * @See
 * @Since com.jkoss.study.learn.vo
 * @Description: TODO
 */
public class FeedbackVo extends Feedback {

	private String sname;
	private String cname;
	private String tname;
	private String qa1;
	private String qa2;
	private String qa3;
	private String qa4;
	private String qa5;
	private String qa6;

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getQa1() {
		return qa1;
	}

	public void setQa1(String qa1) {
		this.qa1 = qa1;
	}

	public String getQa2() {
		return qa2;
	}

	public void setQa2(String qa2) {
		this.qa2 = qa2;
	}

	public String getQa3() {
		return qa3;
	}

	public void setQa3(String qa3) {
		this.qa3 = qa3;
	}

	public String getQa4() {
		return qa4;
	}

	public void setQa4(String qa4) {
		this.qa4 = qa4;
	}

	public String getQa5() {
		return qa5;
	}

	public void setQa5(String qa5) {
		this.qa5 = qa5;
	}

	public String getQa6() {
		return qa6;
	}

	public void setQa6(String qa6) {
		this.qa6 = qa6;
	}

	public String getTname() {
		return tname;
	}

	public void setTname(String tname) {
		this.tname = tname;
	}

	@Override
	public String toString() {
		return "FeedbackVo [sname=" + sname + ", cname=" + cname + ", tname=" + tname + ", qa1=" + qa1 + ", qa2=" + qa2 + ", qa3=" + qa3 + ", qa4=" + qa4 + ", qa5=" + qa5 + ", qa6=" + qa6 + "]";
	}

	 

}
