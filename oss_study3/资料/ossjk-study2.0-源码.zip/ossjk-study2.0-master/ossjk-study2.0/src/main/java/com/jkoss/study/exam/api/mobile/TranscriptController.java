package com.jkoss.study.exam.api.mobile;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.baomidou.mybatisplus.mapper.Condition;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.jkoss.base.controller.BaseController;
import com.jkoss.study.exam.service.IAnswerService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

/**
 * 成绩单API
 * 
 * @author SIMOBAI
 * 
 *
 */
@Api(tags = "移动端成绩单API")
@Controller
@RequestMapping("/api/transcript")
public class TranscriptController extends BaseController {

	@Autowired
	private IAnswerService iAnswerService;

	/**
	 * @return 获取成绩单列表API
	 */
	@ApiOperation("获取成绩单列表API")
	@GetMapping("/list")
	@ResponseBody
	public Object transcriptlist() {
		Wrapper wrapper = Condition.create();
		wrapper.eq("a.sid", getStudentId()).orderBy("a.create_time", false);// 倒序
		return ajaxSuccess(iAnswerService.selectTranscript(wrapper));
	}

	/**
	 * @return 获取成绩单API
	 */
	@ApiOperation("获取成绩单API,根据id查询成绩单")
	@ApiImplicitParam(name = "id", value = "答题卡id", paramType = "query", required = true, dataType = "String")
	@GetMapping("/transcriptById")
	@ResponseBody
	public Object transcriptById(String id) {
		return ajaxSuccess(iAnswerService.selectTranscriptById(id));
	}

}
