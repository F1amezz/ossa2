package com.jkoss.study.educational.mapper;

import com.jkoss.study.educational.entity.Standard;
import com.jkoss.study.educational.entity.Standarditem;
import com.jkoss.study.educational.vo.StandardVo;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;

/**
 * 老师考评题; InnoDB free: 11264 kB Mapper 接口
 * 
 * @Author wuyu
 * @Version 1.0, 2019-06-05
 * @See
 * @Since com.jkoss.study.educational.mapper
 * @Description: TODO
 */
public interface StandardMapper extends BaseMapper<Standard> {
	 
	
}
