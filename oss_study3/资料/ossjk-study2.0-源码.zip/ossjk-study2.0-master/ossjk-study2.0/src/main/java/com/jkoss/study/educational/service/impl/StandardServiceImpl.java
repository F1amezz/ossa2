package com.jkoss.study.educational.service.impl;

import com.jkoss.common.util.CommonUtil;
import com.jkoss.study.educational.entity.Standard;
import com.jkoss.study.educational.entity.Standarditem;
import com.jkoss.study.educational.mapper.StandardMapper;
import com.jkoss.study.educational.mapper.StandarditemMapper;
import com.jkoss.study.educational.service.IStandardService;
import com.jkoss.study.educational.service.IStandarditemService;
import com.jkoss.study.educational.vo.StandardVo;
import com.baomidou.mybatisplus.mapper.Condition;
import com.baomidou.mybatisplus.mapper.SqlHelper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * 老师考评题; InnoDB free: 11264 kB 服务实现类
 * 
 * @Author wuyu
 * @Version 1.0, 2019-06-05
 * @See
 * @Since com.jkoss.study.educational.service.impl
 * @Description: TODO
 */
@Service
public class StandardServiceImpl extends ServiceImpl<StandardMapper, Standard> implements IStandardService {

	@Autowired
	private IStandarditemService iStandarditemService;

	@Override
	public boolean insertStandardVo(StandardVo standardVo) {
		Standard standard = new Standard();
		standard.setTitle(standardVo.getTitle());
		standard.setType(standardVo.getType());
		standard.setState(standardVo.getState());
		standard.setDimension(standardVo.getDimension());
		standard.setScore(standardVo.getScore());
		standard.setRemk(standardVo.getRemk());
		baseMapper.insert(standard);
		// 添加子項
		if (!CommonUtil.isBlank(standardVo.getItems())) {
			// for (Standarditem item : standardVo.getItems()) {
			// item.setSid(standard.getId());
			// }
			for (int i = 0; i < standardVo.getItems().size(); i++) {
				standardVo.getItems().get(i).setSid(standard.getId());
				standardVo.getItems().get(i).setInde(i + 1);
			}
		}
		return iStandarditemService.insertBatch(standardVo.getItems());
	}

	@Override
	public boolean updateStandardVoById(StandardVo standardVo) {

		List<Standarditem> items = standardVo.getItems();
		List<Standarditem> updateItems = new ArrayList();
		List<Standarditem> insertItems = new ArrayList();

		if (!CommonUtil.isBlank(items)) {
			for (int i = 0; i < items.size(); i++) {
				// 列表分两个情况
				if (CommonUtil.isBlank(items.get(i).getId())) {
					items.get(i).setSid(standardVo.getId());
					items.get(i).setInde(i + 1);
					// 新增的列表
					insertItems.add(items.get(i));
				} else {
					// 更新的李彪
					updateItems.add(items.get(i));
				}
			}
			if (!CommonUtil.isBlank(insertItems)) {
				iStandarditemService.insertBatch(insertItems);
			}
			if (!CommonUtil.isBlank(updateItems)) {
				iStandarditemService.updateBatchById(updateItems);
			}
		}
		// 转为父类把items属性去掉
		Standard standard = standardVo;
		return this.updateById(standard);
	}

	@Override
	public boolean deleteStandardVoById(List<String> id) {
		// 删除子项
		for (String idStr : id) {
			iStandarditemService.delete(Condition.create().eq("sid", idStr));
		}
		return this.deleteBatchIds(id);
	}

}
