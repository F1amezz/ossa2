package com.jkoss.study.system.service.impl;

import com.jkoss.study.system.entity.Permission;
import com.jkoss.study.system.mapper.PermissionMapper;
import com.jkoss.study.system.service.IPermissionService;
import com.baomidou.mybatisplus.mapper.Condition;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;

import java.util.List;

import org.springframework.stereotype.Service;

/**
 * 权限 服务实现类
 * 
 * @Author Jason
 * @Version 1.0, 2019-05-28
 * @See
 * @Since com.jkoss.study.system.service.impl
 * @Description: TODO
 */
@Service
public class PermissionServiceImpl extends ServiceImpl<PermissionMapper, Permission> implements IPermissionService {
	@Override
	public List<Permission> selectByUid(String id) {
		//相当于sql的where 条件
		return this.baseMapper.selectByUid(id);
	}
}
