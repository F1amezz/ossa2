package com.jkoss.study.educational.service;

import com.jkoss.study.educational.entity.TeacherClazz;

import java.util.List;

import com.baomidou.mybatisplus.service.IService;

/**
 * 教师班级中间表 服务类
 * 
 * @Author chair
 * @Version 1.0, 2019-06-10
 * @See
 * @Since com.jkoss.study.educational.service
 * @Description: TODO
 */
public interface ITeacherClazzService extends IService<TeacherClazz> {
	

	int updateTeacher(String id, String tid);

	List selectVoByCid(String cid);

}
