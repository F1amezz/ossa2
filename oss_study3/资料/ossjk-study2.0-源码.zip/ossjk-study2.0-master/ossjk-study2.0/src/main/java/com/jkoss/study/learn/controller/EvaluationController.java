package com.jkoss.study.learn.controller;

import java.util.Arrays;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.baomidou.mybatisplus.mapper.Condition;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.jkoss.base.controller.BaseController;
import com.jkoss.common.util.CommonMethod;
import com.jkoss.common.util.CommonUtil;
import com.jkoss.common.vo.DwzPageBean;
import com.jkoss.study.constant.Constant;
import com.jkoss.study.educational.entity.Student;
import com.jkoss.study.educational.service.IClazzService;
import com.jkoss.study.educational.service.IStudentService;
import com.jkoss.study.learn.entity.Evaluation;
import com.jkoss.study.learn.service.IEvaluationService;
import com.jkoss.study.learn.vo.EvaluationVo;

/**
 * 总结 前端控制器
 * 
 * @Author chair
 * @Version 1.0, 2019-06-11
 * @See
 * @Since com.jkoss.study.learn.controller
 * @Description: TODO
 */
@Controller
@RequestMapping("/learn/evaluation")
public class EvaluationController extends BaseController {

	@Autowired
	private IEvaluationService iEvaluationService;
	@Autowired
	private IClazzService iClazzService;
	@Autowired
	private IStudentService iStudentService;

	@RequestMapping("/list")
	@RequiresPermissions("/learn/evaluation/list")
	public String list(String isFm, String sname, String cid, String writedate, String isread, DwzPageBean dwzPageBean,
			ModelMap map, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		Wrapper wrapper = Condition.create();

		sessionLikeStored(isFm, "s.name", "sname", sname, session, wrapper);
		sessionEqStored(isFm, "e.cid", "cid", cid, session, wrapper);
		sessionEqStored(isFm, "e.writedate", "writedate", writedate, session, wrapper);
		sessionEqStored(isFm, "e.isread", "isread", isread, session, wrapper);

		if (isStudent()) {
			// 学生
			// 新增的拿到学生信息
			String sid = (String) session.getAttribute(Constant.SESSION_USERID_KEY);
			// 学生只能查找自己的
			wrapper.isWhere(true);
			wrapper.eq("e.sid", sid);
		}

		if (!CommonUtil.isBlank(dwzPageBean.getOrderField()) && !CommonUtil.isBlank(dwzPageBean.getOrderDirection())) {
			wrapper.orderBy(dwzPageBean.getOrderField(), CommonUtil.isEquals(dwzPageBean.getOrderDirection(), "asc"));
		} else {
			// 默认排序字段
			wrapper.orderBy("writedate", false);
		}

		Page resultPage = iEvaluationService.selectVoPage(dwzPageBean.toPage(), wrapper);
		map.put("dwzPageBean", dwzPageBean.toDwzPageBean(resultPage));
		// 查询所有班级
		map.put("clazzs", iClazzService.selectList(null));
		return "learn/evaluation/list";
	}

	@RequestMapping("/toInsert")
	@RequiresPermissions("/learn/evaluation/toInsert")
	public String toInsert(HttpServletRequest request, HttpServletResponse response) {
		return "learn/evaluation/edit";
	}

	@RequestMapping("/insert")
	@RequiresPermissions("/learn/evaluation/toInsert")
	@ResponseBody
	public Object insert(@Valid Evaluation evaluation, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) {
		// 新增的拿到学生信息
		Student student = (Student) session.getAttribute(Constant.SESSION_USER_KEY);
		// 拿到填写日期
		String currentDay = evaluation.getWritedate();
		// 拿到当前学生id
		String sid = student.getId();
		Wrapper wrapper = Condition.create().eq("writedate", currentDay).eq("sid", sid);
		if (!CommonUtil.isBlank(iEvaluationService.selectList(wrapper))) {
			return ajaxError("当天已经填写了");
		}

		// 设置学生id
		evaluation.setSid(student.getId());
		// 设置班级id
		evaluation.setCid(student.getClzid());
		// 已读 1-是、2否
		evaluation.setIsread(2);
		if (iEvaluationService.insert(evaluation)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}

	}

	@RequestMapping("/toUpdate")
	@RequiresPermissions("/learn/evaluation/toUpdate")
	public String toUpdate(String id, ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		map.put("record", iEvaluationService.selectById(id));
		return "learn/evaluation/edit";
	}

	@RequestMapping("/update")
	@RequiresPermissions("/learn/evaluation/toUpdate")
	@ResponseBody
	public Object update(@Valid Evaluation evaluation, HttpServletRequest request, HttpServletResponse response) {
		if (iEvaluationService.updateById(evaluation)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/delete")
	@RequiresPermissions("/learn/evaluation/delete")
	@ResponseBody
	public Object delete(String[] id, HttpServletRequest request, HttpServletResponse response) {
		if (iEvaluationService.deleteBatchIds(Arrays.asList(id))) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/toDetail")
	@RequiresPermissions("/learn/evaluation/toDetail")
	// public String toDetail(String id, String sname, String cid, String
	// writedate,
	// String isread, Integer index, Integer currentPage, DwzPageBean
	// numPerPage,
	// ModelMap map, HttpServletRequest request, HttpServletResponse response,
	// HttpSession session) {
	public String toDetail(String id, String sname, String cid, String writedate, String isread, Integer index,
			String from, DwzPageBean dwzPageBean, ModelMap map, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) {
		Wrapper wrapper = Condition.create();
		if (!CommonUtil.isBlank(sname)) {
			// 根据学生搜索
			wrapper.isWhere(true);
			wrapper.like("s.name", sname);
			map.put("sname", sname);
		}
		if (!CommonUtil.isBlank(cid)) {
			// 根据班级搜索
			wrapper.isWhere(true);
			wrapper.eq("e.cid", cid);
			map.put("cid", cid);
		}
		if (!CommonUtil.isBlank(writedate)) {
			// 根据日期搜索
			wrapper.isWhere(true);
			wrapper.eq("e.writedate", writedate);
			map.put("writedate", writedate);
		}

		if (!CommonUtil.isBlank(isread)) {
			// 根据是否已读搜索
			wrapper.isWhere(true);
			wrapper.eq("e.isread", isread);
			map.put("isread", isread);
		}
		if (isStudent()) {
			// 学生
			// 新增的拿到学生信息
			String sid = (String) session.getAttribute(Constant.SESSION_USERID_KEY);
			// 学生只能查找自己的
			wrapper.isWhere(true);
			wrapper.eq("e.sid", sid);
		}

		if (!CommonUtil.isBlank(dwzPageBean.getOrderField()) && !CommonUtil.isBlank(dwzPageBean.getOrderDirection())) {
			wrapper.orderBy(dwzPageBean.getOrderField(), CommonUtil.isEquals(dwzPageBean.getOrderDirection(), "asc"));
		} else {
			// 默认排序字段
			wrapper.orderBy("writedate", false);
		}
		Page resultPage = iEvaluationService.selectVoPage(dwzPageBean.toPage(), wrapper);
		if (index > 0) {
			map.put("preRecord", ((EvaluationVo) resultPage.getRecords().get(index - 1)).getId());
			map.put("preIndex", index - 1);
		}
		if (index < (resultPage.getRecords().size() - 1)) {
			map.put("nextRecord", ((EvaluationVo) resultPage.getRecords().get(index + 1)).getId());
			map.put("nextIndex", index + 1);
		}

		map.put("index", index);
		if (isTeacher()) {
			Evaluation evaluation = iEvaluationService.selectById(id);
			if (evaluation.getIsread() == 2) {
				// 查看的时候更新查看人
				// 已读 1-是、2否
				evaluation.setIsread(1);
				// 阅读人id
				evaluation.setReader(session.getAttribute(Constant.SESSION_USERID_KEY).toString());
				// 阅读时间
				evaluation.setReadtime(CommonUtil.date6());
				iEvaluationService.updateById(evaluation);
			}
		}
		map.put("record", iEvaluationService.selectVo(Condition.create().isWhere(true).eq("e.id", id)).get(0));
		return "learn/evaluation/detail";
	}

	@RequestMapping("/detail")
	@RequiresPermissions("/learn/evaluation/toDetail")
	@ResponseBody
	public Object detail(HttpServletRequest request, HttpServletResponse response) {
		return ajaxSuccess();
	}

	@RequestMapping("/read")
	@RequiresPermissions("/learn/evaluation/read")
	@ResponseBody
	public Object read(String id, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		Evaluation evaluation = iEvaluationService.selectById(id);
		if (evaluation.getIsread() == 2) {
			// 查看的时候更新查看人
			// 已读 1-是、2否
			evaluation.setIsread(1);
			// 阅读人id
			evaluation.setReader(session.getAttribute(Constant.SESSION_USERID_KEY).toString());
			// 阅读时间
			evaluation.setReadtime(CommonUtil.date6());
			if (iEvaluationService.updateById(evaluation)) {
				return ajaxSuccess();
			} else {
				return ajaxError();
			}

		}
		return ajaxSuccess();
	}

	@RequestMapping("/toListNoCommit")
	@RequiresPermissions("/learn/evaluation/toListNoCommit")
	public String toListNoCommit(String cid, String writedate, String sname, ModelMap map, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) {
		if (CommonUtil.isBlank(writedate)) {
			writedate = (String) session.getAttribute("writedate");
		} else {
			session.setAttribute("writedate", writedate);
		}

		if (CommonUtil.isBlank(cid)) {
			cid = (String) session.getAttribute("cid");
		} else {
			session.setAttribute("cid", cid);
		}
		
		if (CommonUtil.isBlank(sname)) {
			sname = (String) session.getAttribute("sname");
		} else {
			session.setAttribute("sname", sname);
		}

		if (!CommonUtil.isBlank(cid) && !CommonUtil.isBlank(writedate)) {
			// 查询条件
			map.put("students", iStudentService.selectNoCommitEvaluationByCidAndWritedate(cid, writedate, sname));
		}
		map.put("cid", cid);
		// 查询所有班级
		map.put("clazzs", iClazzService.selectList(null));
		return "learn/evaluation/listNoCommit";
	}
}
