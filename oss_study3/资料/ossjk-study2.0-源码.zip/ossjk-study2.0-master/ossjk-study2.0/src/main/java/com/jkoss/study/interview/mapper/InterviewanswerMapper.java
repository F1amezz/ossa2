package com.jkoss.study.interview.mapper;

import com.jkoss.study.interview.entity.Interviewanswer;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.mapper.Wrapper;

/**
 * 试题解答 Mapper 接口
 * 
 * @Author Jason
 * @Version 1.0, 2019-08-11
 * @See
 * @Since com.jkoss.study.interview.mapper
 * @Description: TODO
 */
public interface InterviewanswerMapper extends BaseMapper<Interviewanswer> {

	List selectVoList(@Param("ew") Wrapper wrapper);

}
