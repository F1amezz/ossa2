package com.jkoss.study.system.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.mapper.Condition;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.jkoss.base.controller.BaseController;
import com.jkoss.common.util.CommonUtil;
import com.jkoss.common.vo.DwzPageBean;
import com.jkoss.common.vo.ZtreeBean;
import com.jkoss.study.system.entity.Permission;
import com.jkoss.study.system.service.IPermissionService;

/**
 * 权限 前端控制器
 * 
 * @Author Jason
 * @Version 1.0, 2019-05-28
 * @See
 * @Since com.jkoss.study.system.controller
 * @Description: TODO
 */
@Controller
@RequestMapping("/system/permission")
public class PermissionController extends BaseController {

	@Autowired
	private IPermissionService iPermissionService;

	/**
	 * 列表
	 * 
	 * @param map
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/list")
	@RequiresPermissions("/system/permission/list")
	public String list(ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		// 构建排序条件
		Wrapper wrapper = Condition.create().orderBy("level",true).orderBy("sort", true);
		List<Permission> Permissions = iPermissionService.selectList(wrapper);
		// 把查询回来的实体转成ZtreeBean
		if (!CommonUtil.isBlank(Permissions)) {
			List<ZtreeBean> ztreeBeans = new ArrayList();
			for (Permission Permission : Permissions) {
				ZtreeBean ztreeBean = new ZtreeBean();
				ztreeBean.setId(Permission.getId() + "");
				ztreeBean.setIsParent(CommonUtil.isBlank(Permission.getPid()));
				ztreeBean.setName(Permission.getName());
				ztreeBean.setPId(Permission.getPid());
				ztreeBean.setOpen(true);
				ztreeBeans.add(ztreeBean);
			}
			map.put("ztreeBeans", JSON.toJSONString(ztreeBeans));
		} else {
			map.put("ztreeBeans", "[]");
		}

		return "system/permission/list";
	}

	/**
	 * 去新增
	 * 
	 * @param pid
	 * @param map
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/toInsert")
	@RequiresPermissions("/system/permission/toInsert")
	public String toInsert(String pid, ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		map.put("parent", iPermissionService.selectById(pid));
		return "system/permission/edit";
	}

	/**
	 * 
	 * @param permission
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/insert")
	@RequiresPermissions("/system/permission/toInsert")
	@ResponseBody
	public Object insert(Permission permission, HttpServletRequest request, HttpServletResponse response) {
		if (iPermissionService.insert(permission)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	/**
	 * 去修改
	 * 
	 * @param id
	 * @param map
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/toUpdate")
	@RequiresPermissions("/system/permission/toUpdate")
	public String toUpdate(String id, ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		// 查询权限
		Permission permission = iPermissionService.selectById(id);
		map.put("record", permission);
		map.put("parent", iPermissionService.selectById(permission.getPid()));
		map.put("type", permission.getType());
		return "system/permission/edit";
	}

	/**
	 * 修改
	 * 
	 * @param permission
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/update")
	@RequiresPermissions("/system/permission/toUpdate")
	@ResponseBody
	public Object update(Permission permission, HttpServletRequest request, HttpServletResponse response) {
		if (iPermissionService.updateById(permission)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	/**
	 * 去删除
	 * 
	 * @param id
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/delete")
	@RequiresPermissions("/system/permission/delete")
	@ResponseBody
	public Object delete(String[] id, HttpServletRequest request, HttpServletResponse response) {
		List<Permission> list = new ArrayList<Permission>();
		// 查询所有子集数据
		for (String string : id) {
			Permission permission = iPermissionService.selectById(string);
			if (!CommonUtil.isBlank(permission)) {
				list.add(permission);
			}
			list = getAllPermission(list, string);
		}
		// 修改为删除数据
		List dellist = new ArrayList();
		for (Permission permission : list) {
			dellist.add(permission.getId());
		}
		if (iPermissionService.deleteBatchIds(dellist)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	// 递归获取所有子级节点
	public List getAllPermission(List<Permission> list, String id) {
		Wrapper wrapper = Condition.create().eq("pid", id);
		List<Permission> permissions = iPermissionService.selectList(wrapper);
		if (!CommonUtil.isBlank(permissions)) {
			list.addAll(permissions);
		}
		for (Permission permission : permissions) {
			getAllPermission(list, permission.getId());
		}
		return list;
	}
}
