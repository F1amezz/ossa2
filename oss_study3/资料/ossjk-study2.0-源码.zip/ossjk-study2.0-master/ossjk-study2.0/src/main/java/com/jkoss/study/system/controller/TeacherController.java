package com.jkoss.study.system.controller;

import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.baomidou.mybatisplus.mapper.Condition;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.jkoss.base.controller.BaseController;
import com.jkoss.common.util.CommonUtil;
import com.jkoss.common.util.CryptoUtils;
import com.jkoss.common.vo.DwzPageBean;
import com.jkoss.study.educational.service.ITeacherClazzService;
import com.jkoss.study.system.entity.Teacher;
import com.jkoss.study.system.entity.UserRole;
import com.jkoss.study.system.service.IRoleService;
import com.jkoss.study.system.service.ITeacherService;
import com.jkoss.study.system.service.IUserRoleService;

/**
 * 教师 前端控制器
 * 
 * @Author Jason
 * @Version 1.0, 2019-05-27
 * @See
 * @Since com.jkoss.study.system.controller
 * @Description: TODO
 */
@Controller
@RequestMapping("/system/teacher")
public class TeacherController extends BaseController {

	@Autowired
	private ITeacherService iTeacherService;
	@Autowired
	private IUserRoleService iUserRoleService;
	@Autowired
	private IRoleService iRoleService;
	@Autowired
	private ITeacherClazzService iTeacherClazzService;

	/**
	 * 列表
	 * 
	 * @param dwzPageBean
	 * @param map
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/list")
	@RequiresPermissions("/system/teacher/list")
	public String list(String name, DwzPageBean dwzPageBean, ModelMap map, HttpServletRequest request, HttpServletResponse response) {

		// DwzPageBean是我前端交互的一个基础类

		dwzPageBean.getCountResultMap().put("name", name);
		Wrapper wrapper = Condition.create().lt("state", 2).like("name", name);
		// 字段排序
		if (!CommonUtil.isBlank(dwzPageBean.getOrderField()) && !CommonUtil.isBlank(dwzPageBean.getOrderDirection())) {
			wrapper.orderBy(dwzPageBean.getOrderField(), CommonUtil.isEquals(dwzPageBean.getOrderDirection(), "asc"));
		} else {
			wrapper.orderBy("create_time", false);
		}
		Page resultPage = iTeacherService.selectPage(dwzPageBean.toPage(), wrapper);
		map.put("dwzPageBean", dwzPageBean.toDwzPageBean(resultPage));
		return "system/teacher/list";
	}

	/**
	 * 去添加
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/toInsert")
	@RequiresPermissions("/system/teacher/toInsert")
	public String toInsert(ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		return "system/teacher/edit";
	}

	@RequestMapping("/insert")
	@RequiresPermissions("/system/teacher/toInsert")
	@ResponseBody
	public Object insert(@Valid Teacher teacher, String[] rid, HttpServletRequest request, HttpServletResponse response) {
		// 判断用户是否存在
		Wrapper wrapper = Condition.create().eq("lname", teacher.getLname());
		Teacher employees = iTeacherService.selectOne(wrapper);
		if (!CommonUtil.isBlank(employees)) {
			return ajaxError("用户已存在");
		}
		// 判断手机号码是否存在
		Wrapper wrapper1 = Condition.create().eq("phone", teacher.getPhone());
		Teacher employees1 = iTeacherService.selectOne(wrapper1);
		if (!CommonUtil.isBlank(employees1)) {
			return ajaxError("电话已存在");
		}
		// 密碼
		teacher.setPwd(CryptoUtils.encodeMD5("88888888"));
		if (iTeacherService.insert(teacher)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}

	}

	/**
	 * 去修改
	 * 
	 * @param id
	 * @param map
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/toUpdate")
	@RequiresPermissions("/system/teacher/toUpdate")
	public String toUpdate(String id, ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		map.put("record", iTeacherService.selectById(id));
		return "system/teacher/edit";
	}

	/**
	 * 修改
	 * 
	 * @param teacher
	 * @param rid
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/update")
	@RequiresPermissions("/system/teacher/toUpdate")
	@ResponseBody
	public Object update(@Valid Teacher teacher, HttpServletRequest request, HttpServletResponse response) {
		// 不能修改用户名
		teacher.setLname(null);
		if (iTeacherService.updateById(teacher)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	/**
	 * 删除
	 * 
	 * @param id
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/delete")
	@RequiresPermissions("/system/teacher/delete")
	@ResponseBody
	public Object delete(String[] id, HttpServletRequest request, HttpServletResponse response) {
		if (iTeacherService.deleteBatchIds(Arrays.asList(id))) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	/**
	 * 去修改角色
	 * 
	 * @param id
	 * @param map
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/toUpdateRole")
	@RequiresPermissions("/system/teacher/toUpdateRole")
	public String toUpdateRole(String id, ModelMap map, HttpServletRequest request, HttpServletResponse response) {

		// 找到所有角色
		map.put("roles", iRoleService.selectList(Condition.create()));
		// 传递到前端
		map.put("id", id);
		Wrapper wrapper = Condition.create().eq("uid", id);
		List<UserRole> userRoles = iUserRoleService.selectList(wrapper);
		if (!CommonUtil.isBlank(userRoles)) {
			String rid = "";
			for (UserRole userRole : userRoles) {
				rid += userRole.getRid() + ",";
			}
			map.put("rid", rid);
		}
		return "system/teacher/updateRole";
	}

	/**
	 * 分配角色
	 * 
	 * @param id
	 * @param rid
	 * @param map
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/updateRole")
	@RequiresPermissions("/system/teacher/toUpdateRole")
	@ResponseBody
	public Object updateRole(String id, String[] rid, ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		if (iUserRoleService.updateRole(id, rid)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

}
