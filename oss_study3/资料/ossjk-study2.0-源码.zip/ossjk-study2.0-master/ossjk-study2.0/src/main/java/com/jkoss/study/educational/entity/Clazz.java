package com.jkoss.study.educational.entity;

import java.io.Serializable;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.jkoss.base.entity.BaseEntity;

/**
 * 班级
 * 
 * @Author chair
 * @Version 1.0, 2019-07-09
 * @See
 * @Since com.jkoss.study.educational.entity
 * @Description: TODO
 */
public class Clazz extends BaseEntity<Clazz> {

	private static final long serialVersionUID = 1L;

	/**
	 * id
	 */
	@TableId("id")
	private String id;
	/**
	 * 名称
	 */
	@TableField("name")
	private String name;
	/**
	 * 类型：1-后台、2-前端
	 */
	@TableField("type")
	private Integer type;
	/**
	 * 课程id（只对应1级菜单）
	 */
	@TableField("cid")
	private String cid;
	/**
	 * 结课时间
	 */
	@TableField("edtm")
	private String edtm;
	/**
	 * 预科时间
	 */
	@TableField("rdtm")
	private String rdtm;
	/**
	 * 备注
	 */
	@TableField("remk")
	private String remk;
	/**
	 * 开班时间
	 */
	@TableField("crtm")
	private String crtm;
	/**
	 * 班级密码
	 */
	@TableField("pwd")
	private String pwd;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public String getCid() {
		return cid;
	}

	public void setCid(String cid) {
		this.cid = cid;
	}

	public String getEdtm() {
		return edtm;
	}

	public void setEdtm(String edtm) {
		this.edtm = edtm;
	}

	public String getRdtm() {
		return rdtm;
	}

	public void setRdtm(String rdtm) {
		this.rdtm = rdtm;
	}

	public String getRemk() {
		return remk;
	}

	public void setRemk(String remk) {
		this.remk = remk;
	}

	public String getCrtm() {
		return crtm;
	}

	public void setCrtm(String crtm) {
		this.crtm = crtm;
	}

	@Override
	protected Serializable pkVal() {
		return this.id;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	@Override
	public String toString() {
		return "Clazz [id=" + id + ", name=" + name + ", type=" + type + ", cid=" + cid + ", edtm=" + edtm + ", rdtm="
				+ rdtm + ", remk=" + remk + ", crtm=" + crtm + ", pwd=" + pwd + "]";
	}

}
