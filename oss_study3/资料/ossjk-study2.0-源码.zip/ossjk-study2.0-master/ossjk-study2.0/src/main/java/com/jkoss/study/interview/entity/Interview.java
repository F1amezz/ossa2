package com.jkoss.study.interview.entity;

import java.io.Serializable;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.jkoss.base.entity.BaseEntity;

/**
 * 面试表
 * 
 * @Author Jason
 * @Version 1.0, 2019-08-11
 * @See
 * @Since com.jkoss.study.interview.entity
 * @Description: TODO
 */
public class Interview extends BaseEntity<Interview> {

	private static final long serialVersionUID = 1L;

	/**
	 * id
	 */
	@TableId("id")
	private String id;
	/**
	 * 学生id
	 */
	@TableField("sid")
	private String sid;
	/**
	 * 企业id
	 */
	@TableField("eid")
	private String eid;
	/**
	 * 岗位id
	 */
	@TableField("pid")
	private String pid;
	/**
	 * 面试时间
	 */
	@TableField("interviewdate")
	private String interviewdate;
	/**
	 * 准备打分 1-准备充分、2-准备欠缺、3-没有准备
	 */
	@TableField("preparescoring")
	private Integer preparescoring;
	/**
	 * 经历
	 */
	@TableField("experience")
	private String experience;
	/**
	 * 面试打分 1-一定offer、2-感觉良好、3-一知半解、4完全不懂
	 */
	@TableField("scoring")
	private Integer scoring;
	/**
	 * 状态 1-准备、2-面试完成
	 */
	@TableField("state")
	private Integer state;
	/**
	 * 面试结果 1-通过、2-不通过
	 */
	@TableField("result")
	private Integer result;
	/**
	 * 备注
	 */
	@TableField("remk")
	private String remk;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getSid() {
		return sid;
	}

	public void setSid(String sid) {
		this.sid = sid;
	}

	public String getEid() {
		return eid;
	}

	public void setEid(String eid) {
		this.eid = eid;
	}

	public String getPid() {
		return pid;
	}

	public void setPid(String pid) {
		this.pid = pid;
	}

	public String getInterviewdate() {
		return interviewdate;
	}

	public void setInterviewdate(String interviewdate) {
		this.interviewdate = interviewdate;
	}

	public Integer getPreparescoring() {
		return preparescoring;
	}

	public void setPreparescoring(Integer preparescoring) {
		this.preparescoring = preparescoring;
	}

	public String getExperience() {
		return experience;
	}

	public void setExperience(String experience) {
		this.experience = experience;
	}

	public Integer getScoring() {
		return scoring;
	}

	public void setScoring(Integer scoring) {
		this.scoring = scoring;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public Integer getResult() {
		return result;
	}

	public void setResult(Integer result) {
		this.result = result;
	}

	public String getRemk() {
		return remk;
	}

	public void setRemk(String remk) {
		this.remk = remk;
	}

	@Override
	protected Serializable pkVal() {
		return this.id;
	}

	@Override
	public String toString() {
		return "Interview{" + ", id=" + id + ", sid=" + sid + ", eid=" + eid + ", pid=" + pid + ", interviewdate="
				+ interviewdate + ", preparescoring=" + preparescoring + ", experience=" + experience + ", scoring="
				+ scoring + ", state=" + state + ", result=" + result + ", remk=" + remk + ", createTime=" + createTime
				+ ", creator=" + creator + ", modifyTime=" + modifyTime + ", modifier=" + modifier + "}";
	}
}
