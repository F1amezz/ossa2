package com.jkoss.study.system.service;

import com.jkoss.study.system.entity.UserRole;
import com.baomidou.mybatisplus.service.IService;

/**
 * 用户角色 服务类
 * 
 * @Author Jason
 * @Version 1.0, 2019-05-27
 * @See
 * @Since com.jkoss.study.system.service
 * @Description: TODO
 */
public interface IUserRoleService extends IService<UserRole> {

	boolean updateRole(String id, String[] rid);

	boolean updateStudentRoleByCid(String cid, String rid);

}
