package com.jkoss.study.system.controller;

import java.util.Calendar;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.DisabledAccountException;
import org.apache.shiro.authc.IncorrectCredentialsException;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.baomidou.mybatisplus.mapper.Condition;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.jkoss.base.controller.BaseController;
import com.jkoss.common.util.CommonUtil;
import com.jkoss.common.util.CryptoUtils;
import com.jkoss.study.config.wxlogin.WxLoginConfig;
import com.jkoss.study.config.wxlogin.WxLoginVo;
import com.jkoss.study.constant.Constant;
import com.jkoss.study.educational.entity.Student;
import com.jkoss.study.educational.service.IStudentService;
import com.jkoss.study.exam.service.IPointService;
import com.jkoss.study.system.entity.Teacher;
import com.jkoss.study.system.service.ITeacherService;

/**
 * 主页 前端控制器
 * 
 * @Author chair
 * @Version 1.0,2018 年9月23日
 * @See
 * @Since com.jkoss.mengal.system.controller
 * @Description :TODO
 */
@Controller()
@RequestMapping("/")
public class IndexController extends BaseController {
	@Autowired
	private ITeacherService iTeacherService;
	@Autowired
	private IStudentService iStudentService;
	@Autowired
	private WxLoginConfig wxLoginConfig;

	@Autowired
	private IPointService iPointService;

	/**
	 * 去主页
	 * 
	 * @return
	 */
	@RequestMapping("/")
	public String index(ModelMap map) {
		return "index";
	}

	/**
	 * 去登录
	 * 
	 * @return
	 */
	@RequestMapping("/toLogin")
	public String toLoing() {
		if (isAjax(getRequest())) {
			return "forward:/toTimeOut";
		}
		return "login";
	}

	@RequestMapping("/toMain")
	public String toMain(HttpSession session) {
		if (isStudent()) {
			// 学生
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(CommonUtil.getDate());
			if (calendar.get(Calendar.DAY_OF_YEAR) % 2 == 0) {
				// 去管理条例
				return "regulations";
			} else {
				// 去安全条例
				return "safety";
			}
		} else {
			// 1-老师
			// 工作流程
			return "workNorm";

		}
	}

	// /**
	// * 去管理条例
	// *
	// * @return
	// */
	// @RequestMapping("/toRegulations")
	// public String toRegulations() {
	// return "regulations";
	// }
	//
	// /**
	// * 去安全条例
	// *
	// * @return
	// */
	// @RequestMapping("/toSafety")
	// public String toSafety() {
	// return "safety";
	// }

	/**
	 * 登录逻辑
	 * 
	 * @param lgnName 登录用户
	 * @param pwd     密码
	 * @param map
	 * @param session
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/login")
	public String login(String lgnName, String pwd, ModelMap map, HttpSession session) throws Exception {
		// 构造登录参数
		UsernamePasswordToken token = new UsernamePasswordToken(lgnName, CryptoUtils.encodeMD5(pwd));
		try {
			// 交给Realm类处理
			SecurityUtils.getSubject().login(token);
 
			//全部在职老师
			session.setAttribute("thrs", 	this.iTeacherService.selectTeacherOnJob());
		} catch (UnknownAccountException uae) {
			map.put("msg", "未知用户");
			return "forward:/toLogin";
		} catch (IncorrectCredentialsException ice) {
			map.put("msg", "密码错误");
			return "forward:/toLogin";
		} catch (DisabledAccountException ae) {
			map.put("msg", "帐号停用");
			return "forward:/toLogin";
		} catch (AuthenticationException ae) {
			// unexpected condition? error?
			map.put("msg", "服务器繁忙");
			return "forward:/toLogin";
		}
		return "redirect:/";
	}

	@RequestMapping(value = "/wxlogin")
	public String wxlogin(String code, ModelMap map, HttpSession session) throws Exception {
		System.out.println("跳转ok，code=" + code);
		WxLoginVo wxLoginVo = wxLoginConfig.wxLogin(code);
		Wrapper wrapper = Condition.create().eq("wxuid", wxLoginVo.getUnionid());
		Teacher teacher = iTeacherService.selectOne(wrapper);
		Student student = iStudentService.selectOne(wrapper);
		if (!CommonUtil.isBlank(teacher)) {
			// 构造登录参数
			UsernamePasswordToken token = new UsernamePasswordToken(teacher.getLname(), teacher.getPwd());
			try {
				// 交给Realm类处理
				SecurityUtils.getSubject().login(token);
				//全部在职老师
				session.setAttribute("thrs", 	this.iTeacherService.selectTeacherOnJob());
			} catch (UnknownAccountException uae) {
				map.put("msg", "未知用户");
				return "forward:/toLogin";
			} catch (IncorrectCredentialsException ice) {
				map.put("msg", "密码错误");
				return "forward:/toLogin";
			} catch (DisabledAccountException ae) {
				map.put("msg", "帐号停用");
				return "forward:/toLogin";
			} catch (AuthenticationException ae) {
				// unexpected condition? error?
				map.put("msg", "服务器繁忙");
				return "forward:/toLogin";
			}
			return "redirect:/";
		} else if (!CommonUtil.isBlank(student)) {
			// 构造登录参数
			UsernamePasswordToken token = new UsernamePasswordToken(student.getLname(), student.getPwd());
			try {
				// 交给Realm类处理
				SecurityUtils.getSubject().login(token);
				//全部在职老师
				session.setAttribute("thrs", 	this.iTeacherService.selectTeacherOnJob());
			} catch (UnknownAccountException uae) {
				map.put("msg", "未知用户");
				return "forward:/toLogin";
			} catch (IncorrectCredentialsException ice) {
				map.put("msg", "密码错误");
				return "forward:/toLogin";
			} catch (DisabledAccountException ae) {
				map.put("msg", "帐号停用");
				return "forward:/toLogin";
			} catch (AuthenticationException ae) {
				// unexpected condition? error?
				map.put("msg", "服务器繁忙");
				return "forward:/toLogin";
			}
			return "redirect:/";
		} else {
			// 为保证安全暂用session把微信暂存
			session.setAttribute("wxLoginVo", wxLoginVo);
			return "redirect:/toBind";
		}

	}

	/**
	 * 绑定账号
	 * 
	 * @return
	 */
	@RequestMapping("/toBind")
	public String toBind(ModelMap map, HttpSession session) {
		WxLoginVo wxLoginVo = (WxLoginVo) session.getAttribute("wxLoginVo");
		if (!CommonUtil.isBlank(wxLoginVo)) {
			map.put("unionid", wxLoginVo.getUnionid());
		}
		return "bind";
	}

	/**
	 * 绑定账号
	 * 
	 * @return
	 */
	@RequestMapping("/bind")
	public String bind(String name, String pwd, String unionid, ModelMap map, HttpSession session) {
		Wrapper wrapper = Condition.create().eq("lname", name).or().eq("phone", name).andNew().eq("pwd", CryptoUtils.encodeMD5(pwd));
		Teacher teacher = iTeacherService.selectOne(wrapper);
		Student student = iStudentService.selectOne(wrapper);
		if (!CommonUtil.isBlank(teacher)) {
			session.removeAttribute("wxLoginVo");
			teacher.setWxuid(unionid);
			iTeacherService.updateById(teacher);
			map.put("msg", "1");
		} else if (!CommonUtil.isBlank(student)) {
			session.removeAttribute("wxLoginVo");
			student.setWxuid(unionid);
			iStudentService.updateById(student);
			map.put("msg", "1");
		} else {
			map.put("msg", "2");
		}
		return "forward:/toBind";
	}

	/**
	 * 去登出
	 * 
	 * @return
	 */
	@RequestMapping("/toLogout")
	public String toLogout() {
		return "logoutConfirm";
	}

	/**
	 * 登出逻辑
	 * 
	 * @param session
	 * @return
	 */
	@RequestMapping("/logout")
	public String logout(HttpSession session) {
		session.removeAttribute(Constant.SESSION_MENU_KEY);
		session.removeAttribute(Constant.SESSION_USER_KEY);
		session.removeAttribute(Constant.SESSION_URLS_KEY);
		SecurityUtils.getSecurityManager().logout(SecurityUtils.getSubject());
		return "login";
	}

	/**
	 * 超时逻辑
	 * 
	 * @return
	 */
	@RequestMapping("/toTimeOut")
	public String toTimeOut() {
		return "timeoutConfirm";
	}

	/**
	 * 没有权限
	 * 
	 * @return
	 */
	@RequestMapping("/toNoAuth")
	public String toNoAuth() {
		return "noAuthConfirm";
	}

	/**
	 * 去修改密码
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/toChangePassword")
	public String toChangePassword() {
		return "changePassword";
	}

	/**
	 * 修改密码
	 * 
	 * @param oldPwd   旧密码
	 * @param pwd      新密码
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/changePassword")
	@ResponseBody
	public Object changePassword(String oldPwd, String pwd, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		Student student = (Student) session.getAttribute(Constant.SESSION_USER_KEY);
		if (CommonUtil.isEquals(CryptoUtils.encodeMD5(oldPwd), student.getPwd())) {
			student.setPwd(CryptoUtils.encodeMD5(pwd));
		} else {
			return ajaxError("请输入正确的旧密码");
		}
		if (iStudentService.updateById(student)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/listChildrenPointByPid")
	@ResponseBody
	public Object listChildrenPointByPid(String pid, ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		Wrapper wrapper = Condition.create().eq("pid", pid);
		return ajaxSuccess(iPointService.selectList(wrapper));
	}

}
