package com.jkoss.study.learn.controller;

import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.baomidou.mybatisplus.mapper.Condition;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.jkoss.base.controller.BaseController;
import com.jkoss.common.util.CommonMethod;
import com.jkoss.common.util.CommonUtil;
import com.jkoss.common.vo.DwzPageBean;
import com.jkoss.study.constant.Constant;
import com.jkoss.study.educational.entity.Clazz;
import com.jkoss.study.educational.entity.Course;
import com.jkoss.study.educational.entity.Standard;
import com.jkoss.study.educational.entity.Standarditem;
import com.jkoss.study.educational.entity.Student;
import com.jkoss.study.educational.entity.TeacherClazz;
import com.jkoss.study.educational.service.IClazzService;
import com.jkoss.study.educational.service.ICourseService;
import com.jkoss.study.educational.service.IStandardService;
import com.jkoss.study.educational.service.IStandarditemService;
import com.jkoss.study.educational.service.IStudentService;
import com.jkoss.study.educational.service.ITeacherClazzService;
import com.jkoss.study.learn.entity.Feedback;
import com.jkoss.study.learn.entity.Selfevaluation;
import com.jkoss.study.learn.entity.Standardplan;
import com.jkoss.study.learn.service.ISelfevaluationService;
import com.jkoss.study.learn.service.IStandardplanService;
import com.jkoss.study.learn.vo.EvaluationVo;
import com.jkoss.study.learn.vo.SelfevaluationVo;

/**
 * 自我评价 前端控制器
 * 
 * @Author chair
 * @Version 1.0, 2019-06-28
 * @See
 * @Since com.jkoss.study.learn.controller
 * @Description: TODO
 */
@Controller
@RequestMapping("/learn/selfevaluation")
public class SelfevaluationController extends BaseController {

	@Autowired
	private ISelfevaluationService iSelfevaluationService;
	@Autowired
	private IClazzService iClazzService;
	@Autowired
	private ICourseService iCourseService;
	@Autowired
	private IStandardplanService iStandardplanService;
	@Autowired
	private IStandardService iStandardService;
	@Autowired
	private IStandarditemService iStandarditemService;
	@Autowired
	private ITeacherClazzService iTeacherClazzService;
	@Autowired
	private IStudentService iStudentService;

	@RequestMapping("/list")
	@RequiresPermissions("/learn/selfevaluation/list")
	public String list(String sname, String isFm, String cid, String week, String isread, DwzPageBean dwzPageBean,
			ModelMap map, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		Wrapper wrapper = Condition.create();

		sessionLikeStored(isFm, "s.name", "sname", sname, session, wrapper);
		sessionEqStored(isFm, "se.cid", "cid", cid, session, wrapper);
		sessionEqStored(isFm, "se.week", "week", week, session, wrapper);
		sessionEqStored(isFm, "se.isread", "isread", isread, session, wrapper);

		if (isStudent()) {
			// 学生
			// 新增的拿到学生信息
			String sid = (String) session.getAttribute(Constant.SESSION_USERID_KEY);
			// 学生只能查找自己的
			wrapper.isWhere(true);
			wrapper.eq("se.sid", sid);
		}
		if (!CommonUtil.isBlank(dwzPageBean.getOrderField()) && !CommonUtil.isBlank(dwzPageBean.getOrderDirection())) {
			wrapper.orderBy(dwzPageBean.getOrderField(), CommonUtil.isEquals(dwzPageBean.getOrderDirection(), "asc"));
		} else {
			// 默认排序字段
			wrapper.orderBy("se.week", false);
		}
		Page resultPage = iSelfevaluationService.selectVoPage(dwzPageBean.toPage(), wrapper);
		map.put("dwzPageBean", dwzPageBean.toDwzPageBean(resultPage));
		// 查询所有班级
		map.put("clazzs", iClazzService.selectList(null));
		return "learn/selfevaluation/list";
	}

	@RequestMapping("/toInsert")
	@RequiresPermissions("/learn/selfevaluation/toInsert")
	public String toInsert(ModelMap map, HttpSession session, HttpServletRequest request,
			HttpServletResponse response) {
		// 拿到登录的学生
		// 查找每周固定问题
		Map standardMap = new LinkedHashMap();
		Wrapper wrapper = Condition.create().eq("type", 3).eq("state", 1);
		List<Standard> standards = iStandardService.selectList(wrapper);
		for (Standard standard : standards) {
			wrapper = Condition.create().eq("sid", standard.getId()).orderBy("inde", true);
			List<Standarditem> standarditems = iStandarditemService.selectList(wrapper);
			standardMap.put(standard, standarditems);
		}
		map.put("standards", standardMap);
		return "learn/selfevaluation/add";
	}

	@RequestMapping("/insert")
	@RequiresPermissions("/learn/selfevaluation/toInsert")
	@ResponseBody
	public Object insert(@Valid Selfevaluation selfevaluation, HttpSession session, HttpServletRequest request,
			HttpServletResponse response) {
		// 新增的拿到学生信息
		Student student = (Student) session.getAttribute(Constant.SESSION_USER_KEY);
		// 查询到班级
		Clazz clazz = iClazzService.selectById(student.getClzid());

		if (CommonUtil.isBlank(clazz.getCrtm())) {
			// 未开班
			return ajaxError("该班级还没有开班时间。");
		}

		// // 开班时间
		// Date beginDate = CommonUtil.getDate(clazz.getCrtm(), "@ISO");
		// // 填写时间
		// Date writeDate = CommonUtil.getDate(selfevaluation.getWritedate(),
		// "@ISO");
		// Calendar calendar = Calendar.getInstance();
		// calendar.setTime(beginDate);
		// int beginDay = calendar.get(Calendar.DAY_OF_YEAR);
		// calendar.setTime(writeDate);
		// int writeDay = calendar.get(Calendar.DAY_OF_YEAR);
		// if (writeDay >= beginDay) {
		// // 已经开班
		// selfevaluation.setWeek((writeDay - beginDay) / 7);
		// } else {
		// // 未开班
		// return ajaxError("预科阶段，不需要填写周总结。");
		// }

		// 拿到填写周数
		Integer week = selfevaluation.getWeek();
		// 拿到当前学生id
		String sid = student.getId();
		Wrapper wrapper = Condition.create().eq("week", week).eq("sid", sid);
		if (!CommonUtil.isBlank(selfevaluation.selectList(wrapper))) {
			return ajaxError("当周已经填写了");
		}
		// 学生id
		selfevaluation.setSid(sid);
		// 班级id
		selfevaluation.setCid(student.getClzid());
		// 已读 1-是、2否
		selfevaluation.setIsread(2);
		// 拿到当前班级在教老师
		wrapper = Condition.create().eq("cid", student.getClzid()).eq("state", "1");
		TeacherClazz teacherClazz = iTeacherClazzService.selectOne(wrapper);
		selfevaluation.setTid(teacherClazz.getTid());
		if (iSelfevaluationService.insert(selfevaluation)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/toUpdate")
	@RequiresPermissions("/learn/selfevaluation/toUpdate")
	public String toUpdate(String id, ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		Selfevaluation selfevaluation = iSelfevaluationService.selectById(id);
		map.put("record", selfevaluation);
		// 拿到记录的学生
		Student student = iStudentService.selectById(selfevaluation.getSid());
		// 查询班级
		Clazz clazz = iClazzService.selectById(student.getClzid());
		// 查找当天反馈计划
		// 状态 1-启用、2停用
		Wrapper wrapper2 = Condition.create().eq("plantdate", CommonUtil.date()).eq("state", "1");
		Standardplan standardplan = iStandardplanService.selectOne(wrapper2);
		Map standardMap = new LinkedHashMap();
		// 查询反馈问题
		// 查找每周固定问题
		Wrapper wrapper = Condition.create().eq("type", 3).eq("state", 1);
		List<Standard> standards = iStandardService.selectList(wrapper);
		for (Standard standard : standards) {
			wrapper = Condition.create().eq("sid", standard.getId()).orderBy("inde", true);
			List<Standarditem> standarditems = iStandarditemService.selectList(wrapper);
			standardMap.put(standard, standarditems);
		}
		map.put("standards", standardMap);
		return "learn/selfevaluation/edit";
	}

	@RequestMapping("/update")
	@RequiresPermissions("/learn/selfevaluation/toUpdate")
	@ResponseBody
	public Object update(@Valid Selfevaluation selfevaluation, HttpServletRequest request,
			HttpServletResponse response) {
		if (iSelfevaluationService.updateById(selfevaluation)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/delete")
	@RequiresPermissions("/learn/selfevaluation/delete")
	@ResponseBody
	public Object delete(String[] id, HttpServletRequest request, HttpServletResponse response) {
		if (iSelfevaluationService.deleteBatchIds(Arrays.asList(id))) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/toDetail")
	@RequiresPermissions("/learn/selfevaluation/toDetail")
	public String toDetail(String id, String sname, String cid, String week, String isread, Integer index, String from,
			DwzPageBean dwzPageBean, ModelMap map, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) {
		Wrapper wrapper = Condition.create();
		if (!CommonUtil.isBlank(sname)) {
			// 根据学生搜索
			wrapper.isWhere(true);
			wrapper.like("s.name", sname);
			map.put("sname", sname);
		}
		if (!CommonUtil.isBlank(cid)) {
			// 根据班级搜索
			wrapper.isWhere(true);
			wrapper.eq("se.cid", cid);
			map.put("cid", cid);
		}
		if (!CommonUtil.isBlank(week)) {
			// 根据周数搜索
			wrapper.isWhere(true);
			wrapper.eq("se.week", week);
			map.put("week", week);
		}
		if (!CommonUtil.isBlank(isread)) {
			// 根据是否已读搜索
			wrapper.isWhere(true);
			wrapper.eq("se.isread", isread);
			map.put("isread", isread);
		}
		if (isStudent()) {
			// 学生
			// 新增的拿到学生信息
			String sid = (String) session.getAttribute(Constant.SESSION_USERID_KEY);
			// 学生只能查找自己的
			wrapper.isWhere(true);
			wrapper.eq("se.sid", sid);
		}

		if (!CommonUtil.isBlank(dwzPageBean.getOrderField()) && !CommonUtil.isBlank(dwzPageBean.getOrderDirection())) {
			wrapper.orderBy(dwzPageBean.getOrderField(), CommonUtil.isEquals(dwzPageBean.getOrderDirection(), "asc"));
		} else {
			// 默认排序字段
			wrapper.orderBy("se.week", false);
		}
		Page resultPage = iSelfevaluationService.selectVoPage(dwzPageBean.toPage(), wrapper);
		if (index > 0) {
			map.put("preRecord", ((SelfevaluationVo) resultPage.getRecords().get(index - 1)).getId());
			map.put("preIndex", index - 1);
		}
		if (index < (resultPage.getRecords().size() - 1)) {
			map.put("nextRecord", ((SelfevaluationVo) resultPage.getRecords().get(index + 1)).getId());
			map.put("nextIndex", index + 1);
		}

		map.put("index", index);

		Selfevaluation selfevaluation = iSelfevaluationService.selectById(id);
		map.put("record", iSelfevaluationService.selectVo(Condition.create().isWhere(true).eq("se.id", id)).get(0));
		// map.put("record", selfevaluation);
		// 拿到记录的学生
		Student student = iStudentService.selectById(selfevaluation.getSid());
		// 查询班级
		Clazz clazz = iClazzService.selectById(student.getClzid());
		// 查找当天反馈计划
		// 状态 1-启用、2停用
		Wrapper wrapper2 = Condition.create().eq("plantdate", CommonUtil.date()).eq("state", "1");
		Standardplan standardplan = iStandardplanService.selectOne(wrapper2);
		Map standardMap = new LinkedHashMap();
		// 查询反馈问题
		// 查找每周固定问题
		wrapper = Condition.create().eq("type", 3).eq("state", 1);
		List<Standard> standards = iStandardService.selectList(wrapper);
		for (Standard standard : standards) {
			wrapper = Condition.create().eq("sid", standard.getId()).orderBy("inde", true);
			List<Standarditem> standarditems = iStandarditemService.selectList(wrapper);
			standardMap.put(standard, standarditems);
		}
		map.put("standards", standardMap);
		if (isTeacher()) {
			if (selfevaluation.getIsread() == 2) {
				// 查看的时候更新查看人
				// 已读 1-是、2否
				selfevaluation.setIsread(1);
				// 阅读人id
				selfevaluation.setReader(session.getAttribute(Constant.SESSION_USERID_KEY).toString());
				// 阅读时间
				selfevaluation.setReadtime(CommonUtil.date6());
				iSelfevaluationService.updateById(selfevaluation);
			}
		}
		return "learn/selfevaluation/detail";
	}

	@RequestMapping("/detail")
	@RequiresPermissions("/learn/selfevaluation/toDetail")
	@ResponseBody
	public Object detail(HttpServletRequest request, HttpServletResponse response) {
		return ajaxSuccess();
	}

	@RequestMapping("/read")
	@RequiresPermissions("/learn/selfevaluation/read")
	@ResponseBody
	public Object read(String id, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		Selfevaluation selfevaluation = iSelfevaluationService.selectById(id);
		if (selfevaluation.getIsread() == 2) {
			// 查看的时候更新查看人
			// 已读 1-是、2否
			selfevaluation.setIsread(1);
			// 阅读人id
			selfevaluation.setReader(session.getAttribute(Constant.SESSION_USERID_KEY).toString());
			// 阅读时间
			selfevaluation.setReadtime(CommonUtil.date6());
			if (iSelfevaluationService.updateById(selfevaluation)) {
				return ajaxSuccess();
			} else {
				return ajaxError();
			}
		}
		return ajaxSuccess();
	}

	@RequestMapping("/toListNoCommit")
	@RequiresPermissions("/learn/selfevaluation/toListNoCommit")
	public String toListNoCommit(String cid, String week, String sname, ModelMap map, HttpServletRequest request,
			HttpServletResponse response) {
		if (!CommonUtil.isBlank(cid) && !CommonUtil.isBlank(week)) {
			// 查询条件
			map.put("students", iStudentService.selectNoCommitSelfevaluationByCidAndWeek(cid, week, sname));
		}
		map.put("cid", cid);
		map.put("week", week);
		// 查询所有班级
		map.put("clazzs", iClazzService.selectList(null));
		return "learn/selfevaluation/listNoCommit";
	}
}
