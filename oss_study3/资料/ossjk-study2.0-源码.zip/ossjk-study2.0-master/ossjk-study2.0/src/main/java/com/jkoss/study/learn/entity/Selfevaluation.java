package com.jkoss.study.learn.entity;

import java.io.Serializable;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.jkoss.base.entity.BaseEntity;

/**
 * 自我评价
 * 
 * @Author chair
 * @Version 1.0, 2019-07-12
 * @See
 * @Since com.jkoss.study.learn.entity
 * @Description: TODO
 */
public class Selfevaluation extends BaseEntity<Selfevaluation> {

	private static final long serialVersionUID = 1L;

	@TableId("id")
	private String id;
	/**
	 * 学生id
	 */
	@TableField("sid")
	private String sid;
	/**
	 * 班级 id
	 */
	@TableField("cid")
	private String cid;
	/**
	 * 老师id
	 */
	@TableField("tid")
	private String tid;
	/**
	 * 课程id
	 */
	@TableField("crid")
	private String crid;
	/**
	 * 标题
	 */
	@TableField("title")
	private String title;
	/**
	 * 周数
	 */
	@TableField("week")
	private Integer week;
	/**
	 * 反馈内容
	 */
	@TableField("content")
	private String content;
	/**
	 * 问题id
	 */
	@TableField("quest1")
	private String quest1;
	/**
	 * 问题id
	 */
	@TableField("quest2")
	private String quest2;
	/**
	 * 问题id
	 */
	@TableField("quest3")
	private String quest3;
	/**
	 * 答案
	 */
	@TableField("answer1")
	private String answer1;
	/**
	 * 答案
	 */
	@TableField("answer2")
	private String answer2;
	/**
	 * 答案
	 */
	@TableField("answer3")
	private String answer3;
	/**
	 * 已读 1-是、2否
	 */
	@TableField("isread")
	private Integer isread;
	/**
	 * 阅读人id
	 */
	@TableField("reader")
	private String reader;
	/**
	 * 阅读时间
	 */
	@TableField("readtime")
	private String readtime;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getSid() {
		return sid;
	}

	public void setSid(String sid) {
		this.sid = sid;
	}

	public String getCid() {
		return cid;
	}

	public void setCid(String cid) {
		this.cid = cid;
	}

	public String getTid() {
		return tid;
	}

	public void setTid(String tid) {
		this.tid = tid;
	}

	public String getCrid() {
		return crid;
	}

	public void setCrid(String crid) {
		this.crid = crid;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Integer getWeek() {
		return week;
	}

	public void setWeek(Integer week) {
		this.week = week;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getQuest1() {
		return quest1;
	}

	public void setQuest1(String quest1) {
		this.quest1 = quest1;
	}

	public String getQuest2() {
		return quest2;
	}

	public void setQuest2(String quest2) {
		this.quest2 = quest2;
	}

	public String getQuest3() {
		return quest3;
	}

	public void setQuest3(String quest3) {
		this.quest3 = quest3;
	}

	public String getAnswer1() {
		return answer1;
	}

	public void setAnswer1(String answer1) {
		this.answer1 = answer1;
	}

	public String getAnswer2() {
		return answer2;
	}

	public void setAnswer2(String answer2) {
		this.answer2 = answer2;
	}

	public String getAnswer3() {
		return answer3;
	}

	public void setAnswer3(String answer3) {
		this.answer3 = answer3;
	}

	public Integer getIsread() {
		return isread;
	}

	public void setIsread(Integer isread) {
		this.isread = isread;
	}

	public String getReader() {
		return reader;
	}

	public void setReader(String reader) {
		this.reader = reader;
	}

	public String getReadtime() {
		return readtime;
	}

	public void setReadtime(String readtime) {
		this.readtime = readtime;
	}

	@Override
	protected Serializable pkVal() {
		return this.id;
	}

	@Override
	public String toString() {
		return "Selfevaluation{" + ", id=" + id + ", sid=" + sid + ", cid=" + cid + ", tid=" + tid + ", crid=" + crid + ", title=" + title + ", week=" + week + ", content=" + content + ", quest1=" + quest1 + ", quest2=" + quest2 + ", quest3=" + quest3 + ", answer1=" + answer1 + ", answer2=" + answer2 + ", answer3=" + answer3 + ", isread=" + isread + ", reader=" + reader + ", readtime=" + readtime + "}";
	}
}
