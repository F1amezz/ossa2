package com.jkoss.study.shiro;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.DisabledAccountException;
import org.apache.shiro.authc.IncorrectCredentialsException;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.session.mgt.eis.SessionDAO;
import org.apache.shiro.subject.PrincipalCollection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.mapper.Condition;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.jkoss.common.util.CommonUtil;
import com.jkoss.study.constant.Constant;
import com.jkoss.study.educational.entity.Student;
import com.jkoss.study.educational.service.IStudentService;
import com.jkoss.study.system.entity.Permission;
import com.jkoss.study.system.entity.Role;
import com.jkoss.study.system.entity.Teacher;
import com.jkoss.study.system.service.IPermissionService;
import com.jkoss.study.system.service.IRoleService;
import com.jkoss.study.system.service.ITeacherService;

public class AuthRealm extends AuthorizingRealm {

	@Autowired
	private SessionDAO sessionDAO;
	@Autowired
	private ITeacherService iTeacherService;
	@Autowired
	private IPermissionService iPermissionService;
	@Autowired
	private IStudentService iStudentService;
	@Autowired
	private IRoleService iRoleService;

	// 认证.登录
	@Override
	protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token) {
		// 全局获取request对象
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
		UsernamePasswordToken usernamePasswordToken = (UsernamePasswordToken) token;

		Object loginUser = null;
		Object loginId = null;
		Object loginPwd = null;

		// 查找老师
		// 根据名字查找
		Wrapper wrapper = Condition.create().eq("lname", usernamePasswordToken.getUsername()).or().eq("phone", usernamePasswordToken.getUsername());
		Teacher teacher = iTeacherService.selectOne(wrapper);
		if (!CommonUtil.isBlank(teacher)) {
			if (CommonUtil.isBlank(teacher)) {
				// 找不到用户
				throw new UnknownAccountException();
			}
			if (!CommonUtil.isEquals(teacher.getPwd(), new String(usernamePasswordToken.getPassword()))) {
				// 密码错误
				throw new IncorrectCredentialsException();
			}
			// 状态 1-启用、2-停用
			if (CommonUtil.isEquals(teacher.getState() + "", "2")) {
				throw new DisabledAccountException();
			}
			loginUser = teacher;
			loginId = teacher.getId();
			loginPwd = teacher.getPwd();
		} else {
			// 学生登录
			// 根据名字查找
			Student student = iStudentService.selectOne(wrapper);
			if (CommonUtil.isBlank(student)) {
				// 找不到用户
				throw new UnknownAccountException();
			}
			if (!CommonUtil.isEquals(student.getPwd(), new String(usernamePasswordToken.getPassword()))) {
				// 密码错误
				throw new IncorrectCredentialsException();
			}
			// 状态 1-启用、2-停用
			if (CommonUtil.isEquals(student.getState() + "", "2")) {
				throw new DisabledAccountException();
			}
			loginUser = student;
			loginId = student.getId();
			loginPwd = student.getPwd();
		}
		// 登录成功

		// if (CommonUtil.isEquals(teacher.getEmployeeState().toString(), "1"))
		// {
		// // 帐号停用
		// throw new DisabledAccountException();
		// }
		// 以下为只允许同一账户单个登录
		// Collection<Session> sessions = sessionDAO.getActiveSessions();
		// if (sessions.size() > 0) {
		// for (Session session : sessions) {
		// System.out.println("::::::::::::::::" + session);
		// // 获得session中已经登录用户的名字
		// if (null != session.getAttribute(Constant.SESSION_USER_KEY)) {
		// if (CommonUtil.isEquals(
		// ((MerchantEmployees)
		// session.getAttribute(Constant.SESSION_USER_KEY)).getEmployeeName(),
		// merchantEmployees.getEmployeeName())) {
		// sessionDAO.delete(session);
		// // session.removeAttribute(Constant.SESSION_USER_KEY);
		// System.out.println("清除了");
		// }
		// }
		// }
		// }
		// 查找所有权限
		List<Permission> permissions = iPermissionService.selectByUid(loginId.toString());
		// 菜单集合
		List<Permission> menus = new ArrayList();
		// 权限标识集合
		List<String> urls = new ArrayList();
		if (!CommonUtil.isBlank(permissions)) {
			for (Permission permission : permissions) {
				if (CommonUtil.isBlank(permission.getPid())) {
					// 把查询回来的权限筛选到菜单集合里面
					submenu(permission, permissions);
					menus.add(permission);
				}
				if (!CommonUtil.isBlank(permission.getUrl())) {
					// 把查询回来的权限筛选到权限标识集合
					urls.add(permission.getUrl());
				}
			}
		}
		List<String> roleArray = new ArrayList();
		// 查询当前用户的角色
		List<Role> roles = iRoleService.selectListByUid(loginId.toString());
		if (!CommonUtil.isBlank(roles)) {
			for (Role role : roles) {
				roleArray.add(role.getName());
			}

		}
		SecurityUtils.getSubject().getSession(true).setAttribute(Constant.SESSION_USERROLE_KEY, roleArray);
		SecurityUtils.getSubject().getSession(true).setAttribute(Constant.SESSION_USER_KEY, loginUser);
		SecurityUtils.getSubject().getSession(true).setAttribute(Constant.SESSION_USERID_KEY, loginId);
		String menusJSON = JSON.toJSONString(menus);
		SecurityUtils.getSubject().getSession(true).setAttribute(Constant.SESSION_MENU_KEY, menusJSON);
		SecurityUtils.getSubject().getSession(true).setAttribute(Constant.SESSION_URLS_KEY, urls);
		SecurityUtils.getSubject().getSession(true).setAttribute(Constant.SESSION_URLS_JSON, JSON.toJSONString(urls));
		return new SimpleAuthenticationInfo(loginUser, loginPwd, getName());
	}

	// 授权
	@Override
	protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principal) {
		// 授权
		SimpleAuthorizationInfo simpleAuthenticationInfo = new SimpleAuthorizationInfo();
		// 从session里面拿到该用户所有的权限标识
		// SecurityUtils.getSubject().getSession(true).getAttribute(Constant.SESSION_URLS_KEY)
		simpleAuthenticationInfo.addStringPermissions((List) SecurityUtils.getSubject().getSession(true).getAttribute(Constant.SESSION_URLS_KEY));
		simpleAuthenticationInfo.addRoles((List) SecurityUtils.getSubject().getSession(true).getAttribute(Constant.SESSION_USERROLE_KEY));
		return simpleAuthenticationInfo;
	}

	private void submenu(Permission permission, List<Permission> permissions) {
		for (Permission permission2 : permissions) {
			if (CommonUtil.isEquals(permission.getId().toString(), permission2.getPid())) {
				List list = permission.getSubmenu();
				if (CommonUtil.isBlank(list)) {
					list = new ArrayList();
				}
				list.add(permission2);
				permission.setSubmenu(list);
				submenu(permission2, permissions);
			}
		}
	}

}