package com.jkoss.study.exam.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.jkoss.study.exam.entity.Point;
import com.jkoss.study.exam.mapper.PointMapper;
import com.jkoss.study.exam.service.IPointService;
import com.jkoss.study.exam.vo.PointVo;

/**
 * ֪ʶ�� 服务实现类
 * 
 * @Author Jason
 * @Version 1.0, 2019-06-10
 * @See
 * @Since com.jkoss.study.exam.service.impl
 * @Description: TODO
 */
@Service
public class PointServiceImpl extends ServiceImpl<PointMapper, Point> implements IPointService {

	@Override
	public List<PointVo> selectAllLevelByPid(Wrapper wrapper) {
		// TODO Auto-generated method stub
		return baseMapper.selectAllLevelByPid(wrapper);
	}

}
