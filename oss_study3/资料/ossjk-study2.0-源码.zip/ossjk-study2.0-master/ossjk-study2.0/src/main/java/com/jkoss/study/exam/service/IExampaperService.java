package com.jkoss.study.exam.service;

import com.jkoss.study.exam.entity.Exampaper;
import com.baomidou.mybatisplus.service.IService;

/**
 *  服务类
 * 
 * @Author Jason
 * @Version 1.0, 2019-06-05
 * @See
 * @Since com.jkoss.study.exam.service
 * @Description: TODO
 */
public interface IExampaperService extends IService<Exampaper> {

}
