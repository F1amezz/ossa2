package com.jkoss.study.exam.controller;

import java.util.Arrays;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.baomidou.mybatisplus.mapper.Condition;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.jkoss.base.controller.BaseController;
import com.jkoss.common.util.CommonUtil;
import com.jkoss.common.vo.DwzPageBean;
import com.jkoss.study.exam.entity.Question;
import com.jkoss.study.exam.service.IPointService;
import com.jkoss.study.exam.service.IQuestionService;

/**
 * ����� 前端控制器
 * 
 * @Author Jason
 * @Version 1.0, 2019-06-10
 * @See
 * @Since com.jkoss.study.exam.controller
 * @Description: TODO
 */
@Controller
@RequestMapping("/exam/question")
public class QuestionController extends BaseController {

	@Autowired
	private IQuestionService iQuestionService;

	@Autowired
	private IPointService iPointService;

	@RequestMapping("/list")
	@RequiresPermissions("/exam/question/list")
	public String list(String type, String cpid, String mpid, String name,String zpid, DwzPageBean dwzPageBean, ModelMap map,
			HttpServletRequest request, HttpServletResponse response) {
		Wrapper wrapper = Condition.create();
		wrapper.like("cpid", cpid).like("mpid", mpid).like("zpid", zpid);

		dwzPageBean.getCountResultMap().put("cpid", cpid);
		dwzPageBean.getCountResultMap().put("mpid", mpid);
		dwzPageBean.getCountResultMap().put("zpid", zpid);
		if (!CommonUtil.isBlank(type)) {
			wrapper.eq("type", type);
			map.put("type", type);
		}
		
		if (!CommonUtil.isBlank(name)) {
			wrapper.like("q.name", name);
			map.put("name", name);
		}

		if (!CommonUtil.isBlank(dwzPageBean.getOrderField()) && !CommonUtil.isBlank(dwzPageBean.getOrderDirection())) {
			dwzPageBean.getCountResultMap().put("orderField", dwzPageBean.getOrderField());
			dwzPageBean.getCountResultMap().put("orderDirection", dwzPageBean.getOrderDirection());
			wrapper.orderBy(dwzPageBean.getOrderField(), CommonUtil.isEquals(dwzPageBean.getOrderDirection(), "asc"));
		} else {
			// 默认排序字段
			wrapper.orderBy("create_time", false);
		}
		Page resultPage = iQuestionService.selectVoPage(dwzPageBean.toPage(), wrapper);
		map.put("dwzPageBean", dwzPageBean.toDwzPageBean(resultPage));
		Wrapper wrapper1 = Condition.create().eq("level", "1");
		map.put("cpnames", iPointService.selectList(wrapper1));
		Wrapper wrapper2 = Condition.create().eq("level", "2").like("pid", cpid);
		map.put("mpnames", iPointService.selectList(wrapper2));
		Wrapper wrapper3 = Condition.create().eq("level", "3").like("pid", mpid);
		map.put("zpnames", iPointService.selectList(wrapper3));
		return "exam/question/list";
	}

	@RequestMapping("/toInsert")
	@RequiresPermissions("/exam/question/toInsert")
	public String toInsert(ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		Wrapper wrapper1 = Condition.create().eq("level", "1");
		map.put("cpnames", iPointService.selectList(wrapper1));
		
		//Wrapper wrapper2 = Condition.create().eq("level", "2");
		//map.put("mpnames", iPointService.selectList(wrapper2));
		//Wrapper wrapper3 = Condition.create().eq("level", "3");
		//map.put("zpnames", iPointService.selectList(wrapper3));
		return "exam/question/edit";
	}

	@RequestMapping("/insert")
	@RequiresPermissions("/exam/question/toInsert")
	@ResponseBody
	public Object insert(@Valid Question question, HttpServletRequest request, HttpServletResponse response) {
		
		question.setIsSubjective(question.getType()>3?1:2);//主观题/客观题
 
		if (iQuestionService.insert(question)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}

	}

	@RequestMapping("/toUpdate")
	@RequiresPermissions("/exam/question/toUpdate")
	public String toUpdate(String id, ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		Wrapper wrapper1 = Condition.create().eq("level", "1");
		map.put("cpnames", iPointService.selectList(wrapper1));
		Wrapper wrapper2 = Condition.create().eq("level", "2");
		map.put("mpnames", iPointService.selectList(wrapper2));
		Wrapper wrapper3 = Condition.create().eq("level", "3");
		map.put("zpnames", iPointService.selectList(wrapper3));
		map.put("record", iQuestionService.selectById(id));
		return "exam/question/edit";
	}

	@RequestMapping("/update")
	@RequiresPermissions("/exam/question/toUpdate")
	@ResponseBody
	public Object update(@Valid Question question, HttpServletRequest request, HttpServletResponse response) {
		if (iQuestionService.updateById(question)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/delete")
	@RequiresPermissions("/exam/question/delete")
	@ResponseBody
	public Object delete(String[] id, HttpServletRequest request, HttpServletResponse response) {
		if (iQuestionService.deleteBatchIds(Arrays.asList(id))) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

}
