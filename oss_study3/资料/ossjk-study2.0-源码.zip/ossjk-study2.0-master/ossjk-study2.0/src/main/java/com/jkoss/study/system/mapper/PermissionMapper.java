package com.jkoss.study.system.mapper;

import com.jkoss.study.system.entity.Permission;

import java.util.List;

import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * 权限 Mapper 接口
 * 
 * @Author Jason
 * @Version 1.0, 2019-05-28
 * @See
 * @Since com.jkoss.study.system.mapper
 * @Description: TODO
 */
public interface PermissionMapper extends BaseMapper<Permission> {
	List<Permission> selectByUid(String uid);
}
