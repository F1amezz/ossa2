package com.jkoss.study.educational.entity;

import java.io.Serializable;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.jkoss.base.entity.BaseEntity;


/**
 * 老师考评题; InnoDB free: 11264 kB
 * 
 * @Author wuyu
 * @Version 1.0, 2019-06-05
 * @See
 * @Since com.jkoss.study.educational.entity
 * @Description: TODO
 */
public class Standard extends BaseEntity<Standard> {

    private static final long serialVersionUID = 1L;

    /**
     * id
     */
    @TableId("id")
    private String id;
    /**
     * 标题
     */
    @TableField("title")
    private String title;
    /**
     * 类型 1-固定、2-随机、3-每周一次
     */
    @TableField("type")
    private Integer type;
    /**
     * 状态 1-启用、2-禁用
     */
    @TableField("state")
    private Integer state;
    /**
     * 维度 1-技巧、2-技能、3-内容组织
     */
    @TableField("dimension")
    private Integer dimension;
    /**
     * 分数
     */
    @TableField("score")
    private Integer score;
    /**
     * 备注
     */
    @TableField("remk")
    private String remk;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public Integer getDimension() {
        return dimension;
    }

    public void setDimension(Integer dimension) {
        this.dimension = dimension;
    }

    public Integer getScore() {
        return score;
    }

    public void setScore(Integer score) {
        this.score = score;
    }

    public String getRemk() {
        return remk;
    }

    public void setRemk(String remk) {
        this.remk = remk;
    }

    @Override
    protected Serializable pkVal() {
        return this.id;
    }

    @Override
    public String toString() {
        return "Standard{" +
        ", id=" + id +
        ", title=" + title +
        ", type=" + type +
        ", state=" + state +
        ", dimension=" + dimension +
        ", score=" + score +
        ", remk=" + remk +
        "}";
    }
}
