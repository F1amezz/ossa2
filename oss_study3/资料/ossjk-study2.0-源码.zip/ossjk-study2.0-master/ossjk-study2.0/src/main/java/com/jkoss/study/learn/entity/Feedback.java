package com.jkoss.study.learn.entity;

import java.io.Serializable;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.jkoss.base.entity.BaseEntity;

/**
 * 反馈表
 * 
 * @Author chair
 * @Version 1.0, 2019-06-14
 * @See
 * @Since com.jkoss.study.learn.entity
 * @Description: TODO
 */
public class Feedback extends BaseEntity<Feedback> {

	private static final long serialVersionUID = 1L;

	@TableId("id")
	private String id;
	/**
	 * 学生id
	 */
	@TableField("sid")
	private String sid;
	/**
	 * 班级 id
	 */
	@TableField("cid")
	private String cid;
	/**
	 * 老师id
	 */
	@TableField("tid")
	private String tid;
	/**
	 * 课程id
	 */
	@TableField("crid")
	private String crid;
	/**
	 * 日期
	 */
	@TableField("writedate")
	private String writedate;
	/**
	 * 标题
	 */
	@TableField("title")
	private String title;
	/**
	 * 反馈内容
	 */
	@TableField("content")
	private String content;
	/**
	 * 问题id
	 */
	@TableField("quest1")
	private String quest1;
	/**
	 * 问题id
	 */
	@TableField("quest2")
	private String quest2;
	/**
	 * 问题id
	 */
	@TableField("quest3")
	private String quest3;
	/**
	 * 问题id
	 */
	@TableField("quest4")
	private String quest4;
	/**
	 * 问题id
	 */
	@TableField("quest5")
	private String quest5;
	/**
	 * 问题id
	 */
	@TableField("quest6")
	private String quest6;
	/**
	 * 答案
	 */
	@TableField("answer1")
	private String answer1;
	/**
	 * 答案
	 */
	@TableField("answer2")
	private String answer2;
	/**
	 * 答案
	 */
	@TableField("answer3")
	private String answer3;
	/**
	 * 答案
	 */
	@TableField("answer4")
	private String answer4;
	/**
	 * 答案
	 */
	@TableField("answer5")
	private String answer5;
	/**
	 * 答案
	 */
	@TableField("answer6")
	private String answer6;
	/**
	 * 已读 1-是、2否
	 */
	@TableField("isread")
	private Integer isread;
	/**
	 * 阅读人id
	 */
	@TableField("reader")
	private String reader;
	/**
	 * 阅读时间
	 */
	@TableField("readtime")
	private String readtime;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getSid() {
		return sid;
	}

	public void setSid(String sid) {
		this.sid = sid;
	}

	public String getCid() {
		return cid;
	}

	public void setCid(String cid) {
		this.cid = cid;
	}

	public String getTid() {
		return tid;
	}

	public void setTid(String tid) {
		this.tid = tid;
	}

	public String getCrid() {
		return crid;
	}

	public void setCrid(String crid) {
		this.crid = crid;
	}

	public String getWritedate() {
		return writedate;
	}

	public void setWritedate(String writedate) {
		this.writedate = writedate;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getQuest1() {
		return quest1;
	}

	public void setQuest1(String quest1) {
		this.quest1 = quest1;
	}

	public String getQuest2() {
		return quest2;
	}

	public void setQuest2(String quest2) {
		this.quest2 = quest2;
	}

	public String getQuest3() {
		return quest3;
	}

	public void setQuest3(String quest3) {
		this.quest3 = quest3;
	}

	public String getQuest4() {
		return quest4;
	}

	public void setQuest4(String quest4) {
		this.quest4 = quest4;
	}

	public String getQuest5() {
		return quest5;
	}

	public void setQuest5(String quest5) {
		this.quest5 = quest5;
	}

	public String getQuest6() {
		return quest6;
	}

	public void setQuest6(String quest6) {
		this.quest6 = quest6;
	}

	public String getAnswer1() {
		return answer1;
	}

	public void setAnswer1(String answer1) {
		this.answer1 = answer1;
	}

	public String getAnswer2() {
		return answer2;
	}

	public void setAnswer2(String answer2) {
		this.answer2 = answer2;
	}

	public String getAnswer3() {
		return answer3;
	}

	public void setAnswer3(String answer3) {
		this.answer3 = answer3;
	}

	public String getAnswer4() {
		return answer4;
	}

	public void setAnswer4(String answer4) {
		this.answer4 = answer4;
	}

	public String getAnswer5() {
		return answer5;
	}

	public void setAnswer5(String answer5) {
		this.answer5 = answer5;
	}

	public String getAnswer6() {
		return answer6;
	}

	public void setAnswer6(String answer6) {
		this.answer6 = answer6;
	}

	public Integer getIsread() {
		return isread;
	}

	public void setIsread(Integer isread) {
		this.isread = isread;
	}

	public String getReader() {
		return reader;
	}

	public void setReader(String reader) {
		this.reader = reader;
	}

	public String getReadtime() {
		return readtime;
	}

	public void setReadtime(String readtime) {
		this.readtime = readtime;
	}

	@Override
	protected Serializable pkVal() {
		return this.id;
	}

	@Override
	public String toString() {
		return "Feedback{" + ", id=" + id + ", sid=" + sid + ", cid=" + cid + ", tid=" + tid + ", crid=" + crid + ", writedate=" + writedate + ", title=" + title + ", content=" + content + ", quest1=" + quest1 + ", quest2=" + quest2 + ", quest3=" + quest3 + ", quest4=" + quest4 + ", quest5=" + quest5 + ", quest6=" + quest6 + ", answer1=" + answer1 + ", answer2=" + answer2 + ", answer3=" + answer3 + ", answer4=" + answer4 + ", answer5=" + answer5 + ", answer6=" + answer6 + ", isread=" + isread + ", reader=" + reader + ", readtime=" + readtime + "}";
	}
}
