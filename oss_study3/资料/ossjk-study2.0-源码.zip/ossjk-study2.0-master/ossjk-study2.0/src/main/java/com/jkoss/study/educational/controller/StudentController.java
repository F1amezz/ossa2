package com.jkoss.study.educational.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.baomidou.mybatisplus.mapper.Condition;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.jkoss.base.controller.BaseController;
import com.jkoss.common.util.CommonUtil;
import com.jkoss.common.util.CryptoUtils;
import com.jkoss.common.util.UuidUtil;
import com.jkoss.common.vo.DwzPageBean;
import com.jkoss.study.constant.Constant;
import com.jkoss.study.educational.entity.Clazz;
import com.jkoss.study.educational.entity.Student;
import com.jkoss.study.educational.service.IClazzService;
import com.jkoss.study.educational.service.IStudentService;
import com.jkoss.study.educational.vo.StudentExcelVo;

import cn.afterturn.easypoi.entity.vo.NormalExcelConstants;
import cn.afterturn.easypoi.excel.ExcelImportUtil;
import cn.afterturn.easypoi.excel.entity.ExportParams;
import cn.afterturn.easypoi.excel.entity.ImportParams;
import cn.afterturn.easypoi.excel.entity.enmus.ExcelType;
import cn.afterturn.easypoi.excel.entity.result.ExcelImportResult;

/**
 * 学生 前端控制器
 * 
 * @Author chair
 * @Version 1.0, 2019-06-04
 * @See
 * @Since com.jkoss.study.educational.controller
 * @Description: TODO
 */
@Controller
@RequestMapping("/educational/student")
public class StudentController extends BaseController {

	@Autowired
	private IStudentService iStudentService;
	@Autowired
	private IClazzService iClazzService;

	@RequestMapping("/list")
	@RequiresPermissions("/educational/student/list")
	public String list(String phone, String name, String cid, String schoolname, DwzPageBean dwzPageBean, ModelMap map,
			HttpServletRequest request, HttpServletResponse response) {
		Wrapper wrapper = Condition.create();
		if (!CommonUtil.isBlank(phone)) {
			wrapper.isWhere(true).like("s.phone", phone);
			dwzPageBean.getCountResultMap().put("phone", phone);
		}
		if (!CommonUtil.isBlank(name)) {
			wrapper.isWhere(true).like("s.name", name);
			dwzPageBean.getCountResultMap().put("name", name);
		}
		if (!CommonUtil.isBlank(cid)) {
			wrapper.isWhere(true).eq("s.clzid", cid);
			dwzPageBean.getCountResultMap().put("cid", cid);
		}
		if (!CommonUtil.isBlank(schoolname)) {
			wrapper.isWhere(true).like("s.school", schoolname);
			dwzPageBean.getCountResultMap().put("schoolname", schoolname);
		}

		if (!CommonUtil.isBlank(dwzPageBean.getOrderField()) && !CommonUtil.isBlank(dwzPageBean.getOrderDirection())) {
			wrapper.orderBy(dwzPageBean.getOrderField(), CommonUtil.isEquals(dwzPageBean.getOrderDirection(), "asc"));
		} else {
			// 默认排序字段
			wrapper.orderBy("create_time", false);
		}
		Page resultPage = iStudentService.selecVotPage(dwzPageBean.toPage(), wrapper);
		map.put("dwzPageBean", dwzPageBean.toDwzPageBean(resultPage));
		// 查找所有班级

		List<Clazz> clazzs = iClazzService.selectList(Condition.create().orderBy("crtm", false));
		map.put("clazzs", clazzs);
		return "educational/student/list";
	}

	@RequestMapping("/toInsert")
	@RequiresPermissions("/educational/student/toInsert")
	public String toInsert(ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		return "educational/student/edit";
	}

	@RequestMapping("/insert")
	@RequiresPermissions("/educational/student/toInsert")
	@ResponseBody
	public Object insert(MultipartFile file, @Valid Student student, HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		if (!CommonUtil.isBlank(file) && !CommonUtil.isBlank(file.getOriginalFilename())) {
			String filename = file.getOriginalFilename();
			int i = filename.lastIndexOf(".");
			String suffix = filename.substring(i);
			String imgpath = Constant.IMAGES_URL + UuidUtil.getUUID() + suffix;
			File file2 = new File(Constant.IMAGES_PATH);
			if (!file2.exists()) {
				file2.mkdirs();
			}
			File file3 = new File(imgpath);
			OutputStream out = new FileOutputStream(file3);
			FileCopyUtils.copy(file.getInputStream(), out);
			student.setImg(imgpath);
		}
		// 登录名和姓名一致
		student.setLname(student.getName());
		// 默认密码
		student.setPwd(CryptoUtils.encodeMD5("88888888"));
		// 状态 1-启用、2-停用
		student.setState(1);
		if (iStudentService.insert(student)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/toUpdate")
	@RequiresPermissions("/educational/student/toUpdate")
	public String toUpdate(String id, ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		// 查找所有班级
		Wrapper wrapper = Condition.create().orderBy("create_time", true);
		map.put("clazzs", iClazzService.selectList(wrapper));
		Student student = iStudentService.selectById(id);
		map.put("record", student);
		if (!CommonUtil.isBlank(student.getClzid())) {
			// 根据学生找到班级类型
			Clazz clazz = iClazzService.selectById(student.getClzid());
			if (!CommonUtil.isBlank(clazz)) {
				map.put("ctype", clazz.getType());
			}
		}

		return "educational/student/edit";
	}

	@RequestMapping("/update")
	@RequiresPermissions("/educational/student/toUpdate")
	@ResponseBody
	public Object update(MultipartFile file, @Valid Student student, HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		if (!CommonUtil.isBlank(file) && !CommonUtil.isBlank(file.getOriginalFilename())) {
			String filename = file.getOriginalFilename();
			int i = filename.lastIndexOf(".");
			String suffix = filename.substring(i);
			String imgpath = Constant.IMAGES_URL + UuidUtil.getUUID() + suffix;
			File file2 = new File(Constant.IMAGES_PATH);
			if (!file2.exists()) {
				file2.mkdirs();
			}
			File file3 = new File(imgpath);
			OutputStream out = new FileOutputStream(file3);
			FileCopyUtils.copy(file.getInputStream(), out);
			student.setImg(imgpath);
		}
		if (iStudentService.updateById(student)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/delete")
	@RequiresPermissions("/educational/student/delete")
	@ResponseBody
	public Object delete(String[] id, HttpServletRequest request, HttpServletResponse response) {
		if (iStudentService.deleteBatchIds(Arrays.asList(id))) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}

	}

	@RequestMapping("/updateState")
	@RequiresPermissions("/educational/student/updateState")
	@ResponseBody
	public Object updateState(String id, Integer state, HttpServletRequest request, HttpServletResponse response) {
		Student student = new Student();
		student.setId(id);
		student.setState(state);
		if (iStudentService.updateById(student)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	/**
	 * 获取班级
	 * 
	 * @param type     根据类型获取
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/getClazz")
	@RequiresPermissions({ "/educational/student/toUpdate", "/educational/student/toInsert" })
	@ResponseBody
	public Object getClazz(Integer type, HttpServletRequest request, HttpServletResponse response) {
		// 根据类型查找
		Wrapper wrapper = Condition.create().eq("type", type).orderBy("crtm");
		return ajaxSuccess(iClazzService.selectList(wrapper));

	}

	/**
	 * 去导入页面
	 * 
	 * @param map
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/toImportExcel")
	@RequiresPermissions("/educational/student/toImportExcel")
	public String toImportExcel(ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		return "educational/student/importExcel";
	}

	/**
	 * 导入EXCEL
	 *
	 * @param map
	 * @param dwzPageBean
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/importExcel")
	@RequiresPermissions("/educational/student/toImportExcel")
	@ResponseBody
	public Object importExcel(MultipartFile file, HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// 1.构造导入参数
		ImportParams params = new ImportParams();
		// 指定title位置
		// 2.importExcelMore解释Excel
		ExcelImportResult<StudentExcelVo> result = ExcelImportUtil.importExcelMore(file.getInputStream(),
				StudentExcelVo.class, params);
		// 3.插入数据库
		List<StudentExcelVo> studentExcelVos = result.getList();
		if (!CommonUtil.isBlank(studentExcelVos)) {
			iStudentService.insertImportExcel(studentExcelVos);
			return ajaxSuccess();
		} else {
			return ajaxError("数据内容为空！");
		}
	}

	/**
	 * 导出EXCEL
	 * 
	 * @param map
	 * @param dwzPageBean
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/export")
	@RequiresPermissions("/educational/student/export")
	public String export(String phone, String name, String cid, ModelMap map, DwzPageBean dwzPageBean,
			HttpServletRequest request, HttpServletResponse response) {
		Wrapper wrapper = Condition.create();
		if (!CommonUtil.isBlank(phone)) {
			wrapper.isWhere(true).like("s.phone", phone);
			dwzPageBean.getCountResultMap().put("phone", phone);
		}
		if (!CommonUtil.isBlank(name)) {
			wrapper.isWhere(true).like("s.name", name);
			dwzPageBean.getCountResultMap().put("name", name);
		}
		if (!CommonUtil.isBlank(cid)) {
			wrapper.isWhere(true).eq("s.clzid", cid);
			dwzPageBean.getCountResultMap().put("cid", cid);
		}
		if (!CommonUtil.isBlank(dwzPageBean.getOrderField()) && !CommonUtil.isBlank(dwzPageBean.getOrderDirection())) {
			wrapper.orderBy(dwzPageBean.getOrderField(), CommonUtil.isEquals(dwzPageBean.getOrderDirection(), "asc"));
		} else {
			// 默认排序字段
			wrapper.orderBy("create_time", false);
		}
		ExportParams params = new ExportParams(null, "客户信息", ExcelType.XSSF);
		map.put(NormalExcelConstants.DATA_LIST, iStudentService.selectVoExcel(wrapper)); // 数据集合
		map.put(NormalExcelConstants.CLASS, StudentExcelVo.class);// 导出实体
		map.put(NormalExcelConstants.PARAMS, params);// 参数
		map.put(NormalExcelConstants.FILE_NAME, "学生信息");// 文件名称
		return NormalExcelConstants.EASYPOI_EXCEL_VIEW;// View名称
	}

}
