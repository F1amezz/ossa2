package com.jkoss.study.system.mapper;

import com.jkoss.study.system.entity.RolePermission;

import java.util.List;

import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * 角色权限 Mapper 接口
 * 
 * @Author Jason
 * @Version 1.0, 2019-05-28
 * @See
 * @Since com.jkoss.study.system.mapper
 * @Description: TODO
 */
public interface RolePermissionMapper extends BaseMapper<RolePermission> {
	List<String> selectPidByRid(String id);
}
