package com.jkoss.study.exam.api.mobile;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.baomidou.mybatisplus.mapper.Condition;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.jkoss.base.controller.BaseController;
import com.jkoss.common.util.CommonUtil;
import com.jkoss.common.util.CryptoUtils;
import com.jkoss.common.util.JwtTokenUtil;
import com.jkoss.study.educational.entity.Student;
import com.jkoss.study.educational.service.IStudentService;
import com.jkoss.study.educational.vo.StudentVo;
import com.jkoss.study.system.service.ITokenService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

@Api(tags = "移动端登录API")
@RestController
@RequestMapping("/user")
public class LoginController extends BaseController {

	@Autowired
	private IStudentService iStudentService;
	@Autowired
	protected ITokenService iTokenService;
	@Autowired
	protected JwtTokenUtil jwtTokenUtil;

//	@PostMapping("/tologin")
//	@ResponseBody
//	public Object toLogin() {
//		return ajaxDone("300", "请登录在操作.");
//	}

	@ApiOperation("登录")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "lname", value = "用户名", dataType = "String", example = "datou",required = true,paramType="query"), 
			@ApiImplicitParam(name = "pwd", value = "密码", dataType = "String", example = "123456",required = true,paramType="query")
	})
	@PostMapping(value = "/login")
	@ResponseBody
	public Object login(@ApiIgnore Student student) {
		Wrapper wrapper = Condition.create();
		wrapper.eq("lname", student.getLname());
		String msg = "帐号不存在";
		// Student obj = iStudentService.selectOne(wrapper);

		StudentVo vo = iStudentService.selectVo(wrapper);

		if (!CommonUtil.isBlank(vo)) {
			if (vo.getPwd().equals(CryptoUtils.encodeMD5(student.getPwd()))) {
				return ajaxDone("200", "登录成功", vo);
			} else {
				msg = "密码错误";
			}

		}
		return ajaxDone("300", msg);
	}

}
