package com.jkoss.study.interview.mapper;

import com.jkoss.study.interview.entity.Enterprise;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * 企业表 Mapper 接口
 * 
 * @Author chair
 * @Version 1.0, 2019-06-20
 * @See
 * @Since com.jkoss.study.interview.mapper
 * @Description: TODO
 */
public interface EnterpriseMapper extends BaseMapper<Enterprise> {

	
	
	
}
