package com.jkoss.study.exam.service.impl;

import com.jkoss.study.exam.entity.Question;
import com.jkoss.study.exam.mapper.QuestionMapper;
import com.jkoss.study.exam.service.IQuestionService;
import com.jkoss.study.exam.vo.QusetionVo;
import com.baomidou.mybatisplus.mapper.SqlHelper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;

import java.util.List;

import org.springframework.stereotype.Service;

/**
 * ����� 服务实现类
 * 
 * @Author Jason
 * @Version 1.0, 2019-06-10
 * @See
 * @Since com.jkoss.study.exam.service.impl
 * @Description: TODO
 */
@Service
public class QuestionServiceImpl extends ServiceImpl<QuestionMapper, Question> implements IQuestionService {

	@Override
	public Page selectVoPage(Page page, Wrapper wrapper) {
		// TODO Auto-generated method stub
		SqlHelper.fillWrapper(page, wrapper);
		page.setRecords(baseMapper.selectVoPage(page, wrapper));
		return page;
	}

	@Override
	public List<QusetionVo> selectVo(Wrapper wrapper) {
		// TODO Auto-generated method stub
		return baseMapper.selectVo(wrapper);
	}

}
