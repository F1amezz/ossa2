package com.jkoss.study.interview.vo;

import com.jkoss.study.interview.entity.Interviewanswer;

/**
 * 试题解答
 * 
 * @Author Jason
 * @Version 1.0, 2019-08-11
 * @See
 * @Since com.jkoss.study.interview.entity
 * @Description: TODO
 */
public class InterviewanswerVo extends Interviewanswer {
	private String name;
	private String sid;

	public String getSid() {
		return sid;
	}

	public void setSid(String sid) {
		this.sid = sid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
