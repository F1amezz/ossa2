package com.jkoss.study.interview.controller;

import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.baomidou.mybatisplus.mapper.Condition;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.jkoss.base.controller.BaseController;
import com.jkoss.common.util.CommonUtil;
import com.jkoss.common.vo.DwzPageBean;
import com.jkoss.study.educational.service.IStudentService;
import com.jkoss.study.interview.entity.Interviewanswer;
import com.jkoss.study.interview.entity.Interviewquestion;
import com.jkoss.study.interview.service.IEnterpriseService;
import com.jkoss.study.interview.service.IInterviewanswerService;
import com.jkoss.study.interview.service.IInterviewquestionService;
import com.jkoss.study.interview.service.IPostService;

/**
 * 面试题 前端控制器
 * 
 * @Author Jason
 * @Version 1.0, 2019-08-23
 * @See
 * @Since com.jkoss.study.interview.controller
 * @Description: TODO
 */
@Controller
@RequestMapping("/interview/interviewquestion")
public class InterviewquestionController extends BaseController {

	@Autowired
	private IInterviewquestionService iInterviewquestionService;
	@Autowired
	private IInterviewanswerService iInterviewanswerService;

	@Autowired
	private IStudentService iStudentService;
	@Autowired
	private IEnterpriseService iEnterpriseService;
	@Autowired
	private IPostService iPostService;

	@RequestMapping("/list")
	@RequiresPermissions("/interview/interviewquestion/list")
	public String list(String pid, String sname, String eid, String interviewdate, DwzPageBean dwzPageBean, ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		Wrapper wrapper = Condition.create();
		if (!CommonUtil.isBlank(pid)) {
			// 根据班级搜索
			wrapper.isWhere(true);
			wrapper.eq("p.id", pid);
			dwzPageBean.getCountResultMap().put("pid", pid);
		}
		if (!CommonUtil.isBlank(sname)) {
			// 根据学生搜索
			wrapper.isWhere(true);
			wrapper.like("s.name", sname);
			dwzPageBean.getCountResultMap().put("sname", sname);
		}
		if (!CommonUtil.isBlank(eid)) {
			// 根据企业搜索
			wrapper.isWhere(true);
			wrapper.like("e.id", eid);
			dwzPageBean.getCountResultMap().put("eid", eid);
			// 查询回显岗位
			Wrapper wrapper2 = Condition.create().eq("eid", eid);
			map.put("posts", iPostService.selectList(wrapper2));
		}
		if (!CommonUtil.isBlank(interviewdate)) {
			// 根据学生搜索
			wrapper.isWhere(true);
			wrapper.like("interviewdate", interviewdate);
			dwzPageBean.getCountResultMap().put("interviewdate", interviewdate);
		}
		if (!CommonUtil.isBlank(dwzPageBean.getOrderField()) && !CommonUtil.isBlank(dwzPageBean.getOrderDirection())) {
			dwzPageBean.getCountResultMap().put("orderField", dwzPageBean.getOrderField());
			dwzPageBean.getCountResultMap().put("orderDirection", dwzPageBean.getOrderDirection());
			wrapper.orderBy(dwzPageBean.getOrderField(), CommonUtil.isEquals(dwzPageBean.getOrderDirection(), "asc"));
		} else {
			// 默认排序字段
			wrapper.orderBy("create_time", false);
		}
		Page resultPage = iInterviewquestionService.selectVoPage(dwzPageBean.toPage(), wrapper);
		map.put("dwzPageBean", dwzPageBean.toDwzPageBean(resultPage));
		// 查询所有的企业
		map.put("enterprises", iEnterpriseService.selectList(null));
		return "interview/interviewquestion/list";
	}

	@RequestMapping("/toInsert")
	@RequiresPermissions("/interview/interviewquestion/toInsert")
	public String toInsert(HttpServletRequest request, HttpServletResponse response) {
		return "interview/interviewquestion/edit";
	}

	@RequestMapping("/insert")
	@RequiresPermissions("/interview/interviewquestion/toInsert")
	@ResponseBody
	public Object insert(@Valid Interviewquestion interviewquestion, ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		if (iInterviewquestionService.insert(interviewquestion)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/toUpdate")
	@RequiresPermissions("/interview/interviewquestion/toUpdate")
	public String toUpdate(String id, ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		Interviewquestion interviewquestion = iInterviewquestionService.selectVoById(id);
		map.put("record", interviewquestion);
		Wrapper wrapper = Condition.create().isWhere(true).eq("iqid", interviewquestion.getId());
		List<Interviewanswer> interviewanswers = iInterviewanswerService.selectVoList(wrapper);
		map.put("interviewanswers", interviewanswers);
		return "interview/interviewquestion/edit";
	}

	@RequestMapping("/update")
	@RequiresPermissions("/interview/interviewquestion/toUpdate")
	@ResponseBody
	public Object update(@Valid Interviewquestion interviewquestion, HttpServletRequest request, HttpServletResponse response) {
		if (iInterviewquestionService.updateById(interviewquestion)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/delete")
	@RequiresPermissions("/interview/interviewquestion/delete")
	@ResponseBody
	public Object delete(String[] id, HttpServletRequest request, HttpServletResponse response) {
		if (iInterviewquestionService.deleteBatchIds(Arrays.asList(id))) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/toInsertAnswer")
	@RequiresPermissions("/interview/interviewquestion/toInsertAnswer")
	public String toInsertAnswer(ModelMap map, String iqid, HttpServletRequest request, HttpServletResponse response) {
		map.put("iqid", iqid);
		return "interview/interviewquestion/editAnswer";
	}

	@RequestMapping("/insertAnswer")
	@RequiresPermissions("/interview/interviewquestion/toInsertAnswer")
	@ResponseBody
	public Object insertAnswer(@Valid Interviewanswer interviewanswer, HttpServletRequest request, HttpServletResponse response) {
		interviewanswer.setInitiator(getUserId());
		if (!CommonUtil.isBlank(iStudentService.selectById(getUserId()))) {
			// 回答人类型 1-老师、-2学生
			interviewanswer.setAnswertype(2);
		} else {
			interviewanswer.setAnswertype(1);
		}
		if (iInterviewanswerService.insert(interviewanswer)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/toUpdateAnswer")
	@RequiresPermissions("/interview/interviewquestion/toUpdateAnswer")
	public String toUpdateAnswer(String id, ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		Interviewanswer interviewanswer = iInterviewanswerService.selectById(id);
		map.put("record", interviewanswer);
		map.put("iqid", interviewanswer.getIqid());
		return "interview/interviewquestion/editAnswer";
	}

	@RequestMapping("/updateAnswer")
	@RequiresPermissions("/interview/interviewquestion/toUpdateAnswer")
	@ResponseBody
	public Object updateAnswer(@Valid Interviewanswer interviewanswer, HttpServletRequest request, HttpServletResponse response) {
		if (iInterviewanswerService.updateById(interviewanswer)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/deleteAnswer")
	@RequiresPermissions("/interview/interviewquestion/deleteAnswer")
	@ResponseBody
	public Object deleteAnswer(String[] id, HttpServletRequest request, HttpServletResponse response) {
		if (iInterviewanswerService.deleteBatchIds(Arrays.asList(id))) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/recommend")
	@RequiresPermissions("/interview/interviewquestion/recommend")
	@ResponseBody
	public Object recommend(String id, String iqid, HttpServletRequest request, HttpServletResponse response) throws Exception {
		if (iInterviewanswerService.updateRecommend(iqid, id)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

}
