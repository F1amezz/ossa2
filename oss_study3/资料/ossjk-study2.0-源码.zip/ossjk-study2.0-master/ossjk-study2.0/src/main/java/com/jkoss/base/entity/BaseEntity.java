package com.jkoss.base.entity;

import java.io.Serializable;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.enums.FieldFill;

import io.swagger.annotations.ApiModelProperty;

/**
 * 
 * 
 * 
 * @Author chair
 * @Version 1.0, 2019年6月1日
 * @See
 * @Since com.jkoss.base.entity
 * @Description: TODO
 */
public class BaseEntity<T extends Model> extends Model<T> {
	/**
	 * id
	 */
	// @ApiModelProperty(value = "id", name = "id")
	@TableId("id")
	protected String id;

	/**
	 * 创建时间
	 */
	// @ApiModelProperty(value = "创建时间", name = "create_time", hidden = true)
	@TableField(value = "create_time", fill = FieldFill.INSERT)
	protected String createTime;
	/**
	 * 创建人
	 */
	// @ApiModelProperty(value = "创建人", name = "creator", hidden = true)
	@TableField(value = "creator", fill = FieldFill.INSERT)
	protected String creator;
	/**
	 * 修改时间
	 */
	// @ApiModelProperty(value = "修改时间", name = "modify_time", hidden = true)
	@TableField(value = "modify_time", fill = FieldFill.INSERT_UPDATE)
	protected String modifyTime;
	/**
	 * 修改人
	 */
	// @ApiModelProperty(value = "修改人", name = "modifier", hidden = true)
	@TableField(value = "modifier", fill = FieldFill.INSERT_UPDATE)
	protected String modifier;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(String modifyTime) {
		this.modifyTime = modifyTime;
	}

	public String getModifier() {
		return modifier;
	}

	public void setModifier(String modifier) {
		this.modifier = modifier;
	}

	@Override
	protected Serializable pkVal() {
		// TODO Auto-generated method stub
		return this.id;
	}

}
