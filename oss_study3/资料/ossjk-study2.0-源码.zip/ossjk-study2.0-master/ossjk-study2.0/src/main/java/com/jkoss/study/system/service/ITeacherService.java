package com.jkoss.study.system.service;

import java.util.List;

import com.baomidou.mybatisplus.service.IService;
import com.jkoss.study.system.entity.Teacher;

/**
 * 教师 服务类
 * 
 * @Author Jason
 * @Version 1.0, 2019-05-27
 * @See
 * @Since com.jkoss.study.system.service
 * @Description: TODO
 */
public interface ITeacherService extends IService<Teacher> {
	 List<Teacher> selectTeacherOnJob();
}
