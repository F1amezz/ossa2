package com.jkoss.study.educational.service;

import com.jkoss.study.educational.entity.Clazz;

import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.IService;

/**
 * 班级 服务类
 * 
 * @Author chair
 * @Version 1.0, 2019-06-05
 * @See
 * @Since com.jkoss.study.educational.service
 * @Description: TODO
 */
public interface IClazzService extends IService<Clazz> {

	Page selectVoPage(Page page, Wrapper wrapper);
	
	List< Clazz> selectClazzes10MthAgo();
	
}
