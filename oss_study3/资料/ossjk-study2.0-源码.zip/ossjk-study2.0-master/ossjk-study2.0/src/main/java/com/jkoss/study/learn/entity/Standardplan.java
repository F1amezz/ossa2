package com.jkoss.study.learn.entity;

import java.io.Serializable;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.jkoss.base.entity.BaseEntity;


/**
 * 考评计划
 * 
 * @Author chair
 * @Version 1.0, 2019-06-13
 * @See
 * @Since com.jkoss.study.learn.entity
 * @Description: TODO
 */
public class Standardplan extends BaseEntity<Standardplan> {

    private static final long serialVersionUID = 1L;

    @TableId("id")
    private String id;
    /**
     * 计划日期
     */
    @TableField("plantdate")
    private String plantdate;
    /**
     * 问题
     */
    @TableField("quest1")
    private String quest1;
    /**
     * 问题id
     */
    @TableField("quest2")
    private String quest2;
    /**
     * 问题id
     */
    @TableField("quest3")
    private String quest3;
    /**
     * 问题id
     */
    @TableField("quest4")
    private String quest4;
    /**
     * 问题id
     */
    @TableField("quest5")
    private String quest5;
    /**
     * 问题id
     */
    @TableField("quest6")
    private String quest6;
    /**
     * 状态 1-启用、2停用
     */
    @TableField("state")
    private Integer state;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPlantdate() {
        return plantdate;
    }

    public void setPlantdate(String plantdate) {
        this.plantdate = plantdate;
    }

    public String getQuest1() {
        return quest1;
    }

    public void setQuest1(String quest1) {
        this.quest1 = quest1;
    }

    public String getQuest2() {
        return quest2;
    }

    public void setQuest2(String quest2) {
        this.quest2 = quest2;
    }

    public String getQuest3() {
        return quest3;
    }

    public void setQuest3(String quest3) {
        this.quest3 = quest3;
    }

    public String getQuest4() {
        return quest4;
    }

    public void setQuest4(String quest4) {
        this.quest4 = quest4;
    }

    public String getQuest5() {
        return quest5;
    }

    public void setQuest5(String quest5) {
        this.quest5 = quest5;
    }

    public String getQuest6() {
        return quest6;
    }

    public void setQuest6(String quest6) {
        this.quest6 = quest6;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    @Override
    protected Serializable pkVal() {
        return this.id;
    }

    @Override
    public String toString() {
        return "Standardplan{" +
        ", id=" + id +
        ", plantdate=" + plantdate +
        ", quest1=" + quest1 +
        ", quest2=" + quest2 +
        ", quest3=" + quest3 +
        ", quest4=" + quest4 +
        ", quest5=" + quest5 +
        ", quest6=" + quest6 +
        ", state=" + state +
        "}";
    }
}
