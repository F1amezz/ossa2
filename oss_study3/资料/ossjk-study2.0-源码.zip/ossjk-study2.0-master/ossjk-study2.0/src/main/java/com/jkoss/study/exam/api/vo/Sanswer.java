package com.jkoss.study.exam.api.vo;

import java.util.List;

public class Sanswer {
	
	/**
	 * 试卷id
	 */
	private String   expid;
	private String	eid;
	/**
	 * 班级id
	 */
	private String cid;
	/**
	 * 答题内容对象字符串
	 */
	private String answer;
	
	public String getEid() {
		return eid;
	}
	public void setEid(String eid) {
		this.eid = eid;
	}
	public String getExpid() {
		return expid;
	}
	public void setExpid(String expid) {
		this.expid = expid;
	}
	public String getCid() {
		return cid;
	}
	public void setCid(String cid) {
		this.cid = cid;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}

	
	
	
	
	
	
}
