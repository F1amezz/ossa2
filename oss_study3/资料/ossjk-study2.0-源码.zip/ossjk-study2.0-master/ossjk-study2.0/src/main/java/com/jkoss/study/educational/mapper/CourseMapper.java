package com.jkoss.study.educational.mapper;

import com.jkoss.study.educational.entity.Course;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * 课程 Mapper 接口
 * 
 * @Author chair
 * @Version 1.0, 2019-06-04
 * @See
 * @Since com.jkoss.study.educational.mapper
 * @Description: TODO
 */
public interface CourseMapper extends BaseMapper<Course> {

}
