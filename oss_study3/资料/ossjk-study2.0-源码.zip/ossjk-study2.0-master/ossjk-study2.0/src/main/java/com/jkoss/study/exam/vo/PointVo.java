package com.jkoss.study.exam.vo;

import com.jkoss.study.exam.entity.Point;

public class PointVo extends Point {
	private String pname;
	private String gpname;
	private String gpid;

	public String getGpid() {
		return gpid;
	}

	public void setGpid(String gpid) {
		this.gpid = gpid;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public String getGpname() {
		return gpname;
	}

	public void setGpname(String gpname) {
		this.gpname = gpname;
	}
}
