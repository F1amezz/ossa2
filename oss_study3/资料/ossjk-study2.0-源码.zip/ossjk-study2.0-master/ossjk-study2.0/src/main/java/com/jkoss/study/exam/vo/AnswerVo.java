package com.jkoss.study.exam.vo;

import java.io.Serializable;

import com.baomidou.mybatisplus.annotations.TableField;
import com.jkoss.study.exam.entity.Answer;

/**
 * 答题表
 * 
 * @Author Jason
 * @Version 1.0, 2019-10-21
 * @See
 * @Since com.jkoss.study.exam.entity
 * @Description: TODO
 */
public class AnswerVo extends Answer {

	private String cname;
	private String sname;
	private String expname;

	private String exppassscore;
	private String expscore;

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public String getExpname() {
		return expname;
	}

	public void setExpname(String expname) {
		this.expname = expname;
	}

	public String getExppassscore() {
		return exppassscore;
	}

	public void setExppassscore(String exppassscore) {
		this.exppassscore = exppassscore;
	}

	public String getExpscore() {
		return expscore;
	}

	public void setExpscore(String expscore) {
		this.expscore = expscore;
	}

}
