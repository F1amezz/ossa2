package com.jkoss.study.educational.vo;

import java.util.Date;

import com.baomidou.mybatisplus.annotations.TableField;
import com.jkoss.study.educational.entity.Student;

import cn.afterturn.easypoi.excel.annotation.Excel;

public class StudentExcelVo {
	// 班级信息
	@Excel(name = "班名", orderNum = "0", width = 30)
	private String cname;
	@Excel(name = "预科时间", format = "yyyy/M/d HH:mm:ss", orderNum = "1", width = 30)
	private Date crdtm;
	@Excel(name = "开始时间", format = "yyyy/M/d HH:mm:ss", orderNum = "2", width = 30)
	private Date ccrtm;
	@Excel(name = "结束时间", format = "yyyy/M/d HH:mm:ss", orderNum = "3", width = 30)
	private Date cedtm;
	// 学生信息

	@Excel(name = "学校", orderNum = "4", width = 30)
	private String school;
	@Excel(name = "专业", orderNum = "5", width = 30)
	private String specialty;
	// @Excel(name = "sid", orderNum = "6", width = 30)
	// private String id;
	@Excel(name = "学生名", orderNum = "7", width = 30)
	private String name;
	@Excel(name = "性别", replace = { "男_1", "女_2" }, orderNum = "8", width = 30)
	private Integer sex;
	@Excel(name = "籍贯", orderNum = "9", width = 30)
	private String birthplace;
	@Excel(name = "手机", orderNum = "10", width = 30)
	private String phone;
	@Excel(name = "报到时间", format = "yyyy/M/d HH:mm:ss", orderNum = "11", width = 30)
	private Date rttm;
	@Excel(name = "紧急联系人关系", replace = { "父亲_1", "母亲_2", "姐妹_3", "兄弟_4", "亲戚_5", "朋友_6",
			"其他_7" }, orderNum = "12", width = 30)
	private Integer egrs;
	@Excel(name = "紧急联系人", orderNum = "13", width = 30)
	private String egct;
	@Excel(name = "现住址", orderNum = "14", width = 30)
	private String addr;
	@Excel(name = "上课时间", format = "yyyy/M/d HH:mm:ss", orderNum = "15", width = 30)
	private Date cltm;
	@Excel(name = "紧急联系人电话", orderNum = "16", width = 30)
	private String egph;
	@Excel(name = "头像", orderNum = "17", width = 30)
	private String img;
	@Excel(name = "分组", orderNum = "18", width = 30)
	private String groupno;
	@Excel(name = "身份证", orderNum = "19", width = 30)
	private String idcard;
	@Excel(name = "备注", orderNum = "20", width = 30)
	private String remk;

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getSchool() {
		return school;
	}

	public void setSchool(String school) {
		this.school = school;
	}

	public String getSpecialty() {
		return specialty;
	}

	public void setSpecialty(String specialty) {
		this.specialty = specialty;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getSex() {
		return sex;
	}

	public void setSex(Integer sex) {
		this.sex = sex;
	}

	public String getBirthplace() {
		return birthplace;
	}

	public void setBirthplace(String birthplace) {
		this.birthplace = birthplace;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public Date getRttm() {
		return rttm;
	}

	public void setRttm(Date rttm) {
		this.rttm = rttm;
	}

	public Integer getEgrs() {
		return egrs;
	}

	public void setEgrs(Integer egrs) {
		this.egrs = egrs;
	}

	public String getEgct() {
		return egct;
	}

	public void setEgct(String egct) {
		this.egct = egct;
	}

	public String getAddr() {
		return addr;
	}

	public void setAddr(String addr) {
		this.addr = addr;
	}

	public Date getCltm() {
		return cltm;
	}

	public void setCltm(Date cltm) {
		this.cltm = cltm;
	}

	public String getEgph() {
		return egph;
	}

	public void setEgph(String egph) {
		this.egph = egph;
	}

	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}

	public String getGroupno() {
		return groupno;
	}

	public void setGroupno(String groupno) {
		this.groupno = groupno;
	}

	public String getIdcard() {
		return idcard;
	}

	public void setIdcard(String idcard) {
		this.idcard = idcard;
	}

	public String getRemk() {
		return remk;
	}

	public void setRemk(String remk) {
		this.remk = remk;
	}

	public Date getCrdtm() {
		return crdtm;
	}

	public void setCrdtm(Date crdtm) {
		this.crdtm = crdtm;
	}

	public Date getCcrtm() {
		return ccrtm;
	}

	public void setCcrtm(Date ccrtm) {
		this.ccrtm = ccrtm;
	}

	public Date getCedtm() {
		return cedtm;
	}

	public void setCedtm(Date cedtm) {
		this.cedtm = cedtm;
	}

	@Override
	public String toString() {
		return "StudentExcelVo [cname=" + cname + ", crdtm=" + crdtm + ", ccrtm=" + ccrtm + ", cedtm=" + cedtm
				+ ", school=" + school + ", specialty=" + specialty + ", name=" + name + ", sex=" + sex
				+ ", birthplace=" + birthplace + ", phone=" + phone + ", rttm=" + rttm + ", egrs=" + egrs + ", egct="
				+ egct + ", addr=" + addr + ", cltm=" + cltm + ", egph=" + egph + ", img=" + img + ", groupno="
				+ groupno + ", idcard=" + idcard + ", remk=" + remk + "]";
	}

}
