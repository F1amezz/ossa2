package com.jkoss.study.system.service.impl;

import com.jkoss.common.util.CommonUtil;
import com.jkoss.study.system.entity.RolePermission;
import com.jkoss.study.system.mapper.RolePermissionMapper;
import com.jkoss.study.system.service.IRolePermissionService;
import com.baomidou.mybatisplus.mapper.Condition;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

/**
 * 角色权限 服务实现类
 * 
 * @Author Jason
 * @Version 1.0, 2019-05-28
 * @See
 * @Since com.jkoss.study.system.service.impl
 * @Description: TODO
 */
@Service
public class RolePermissionServiceImpl extends ServiceImpl<RolePermissionMapper, RolePermission>
		implements IRolePermissionService {
	@Override
	public List<String> selectPidByRid(String id) {
		return this.baseMapper.selectPidByRid(id);
	}

	@Override
	public boolean updatePermission(String id, String[] pid) {

		// 删除所有角色权限
		Wrapper wrapper = Condition.create().eq("rid", id);
		this.baseMapper.delete(wrapper);

		if (!CommonUtil.isBlank(pid)) {
			List<RolePermission> rolePermissions = new ArrayList();
			for (String pidStr : pid) {
				RolePermission rolePermission = new RolePermission();
				rolePermission.setRid(id);
				rolePermission.setPid(pidStr);
				// rolePermissionService.insert(rolePermission);
				rolePermissions.add(rolePermission);
			}
			return this.insertBatch(rolePermissions);
		} else {
			return true;
		}
	}

}
