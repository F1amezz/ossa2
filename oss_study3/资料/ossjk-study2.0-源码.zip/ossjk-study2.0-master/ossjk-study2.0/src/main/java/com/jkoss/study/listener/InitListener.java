package com.jkoss.study.listener;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.jkoss.common.util.CommonUtil;
import com.jkoss.study.constant.Constant;

@Component
public class InitListener implements ServletContextListener {

	@Value("${app.basePath}")
	private String basePath;
	@Value("${wx.appid}")
	private String appid;
	@Value("${wx.secret}")
	private String secret;

	@Override
	public void contextInitialized(ServletContextEvent sce) {
		sce.getServletContext().setAttribute(Constant.APPLICATION_WXAPPID_KEY, appid);
		sce.getServletContext().setAttribute(Constant.APPLICATION_WXSECRET_KEY, secret);
		if (CommonUtil.isBlank(basePath)) {
			sce.getServletContext().setAttribute(Constant.APPLICATION_BASEPATH_KEY, sce.getServletContext().getContextPath());
		} else {
			sce.getServletContext().setAttribute(Constant.APPLICATION_BASEPATH_KEY, basePath);
		}
	}
}
