package com.jkoss.study.exam.mapper;

import com.jkoss.study.exam.entity.Exam;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;

/**
 * Mapper 接口
 * 
 * @Author Jason
 * @Version 1.0, 2019-06-08
 * @See
 * @Since com.jkoss.study.exam.mapper
 * @Description: TODO
 */
public interface ExamMapper extends BaseMapper<Exam> {
	List selectVoPage(Page page, @Param("ew") Wrapper wrapper);

	List selectExamList(@Param("ew") Wrapper wrapper);
}
