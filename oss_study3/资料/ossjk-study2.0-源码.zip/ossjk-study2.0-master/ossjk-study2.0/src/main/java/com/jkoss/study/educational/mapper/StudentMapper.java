package com.jkoss.study.educational.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.jkoss.study.educational.entity.Student;
import com.jkoss.study.educational.vo.StudentVo;

/**
 * 学生 Mapper 接口
 * 
 * @Author chair
 * @Version 1.0, 2019-06-04
 * @See
 * @Since com.jkoss.study.educational.mapper
 * @Description: TODO
 */
public interface StudentMapper extends BaseMapper<Student> {

	List selectVoPage(Page page, @Param("ew") Wrapper wrapper);

	List selectVoExcel(@Param("ew") Wrapper wrapper);

	List<Student> selectNoCommitEvaluationByCidAndWritedate(@Param("cid") String cid,
			@Param("writedate") String writedate, @Param("sname") String sname);

	List<Student> selectNoCommitFeedbackByCidAndWritedate(@Param("cid") String cid,
			@Param("writedate") String writedate, @Param("sname") String sname);

	List<Student> selectNoCommitSelfevaluationByCidAndWeek(@Param("cid") String cid, @Param("week") String week,
			@Param("sname") String sname);

	StudentVo selectVo(@Param("ew") Wrapper wrapper);

}
