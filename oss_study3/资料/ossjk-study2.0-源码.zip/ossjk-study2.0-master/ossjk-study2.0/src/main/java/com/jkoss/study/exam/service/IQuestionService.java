package com.jkoss.study.exam.service;

import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.IService;
import com.jkoss.study.exam.entity.Question;
import com.jkoss.study.exam.vo.QusetionVo;

/**
 * ����� 服务类
 * 
 * @Author Jason
 * @Version 1.0, 2019-06-10
 * @See
 * @Since com.jkoss.study.exam.service
 * @Description: TODO
 */
public interface IQuestionService extends IService<Question> {
	Page selectVoPage(Page page, Wrapper wrapper);
	List<QusetionVo> selectVo(Wrapper wrapper);

}
