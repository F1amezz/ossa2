package com.jkoss.study.educational.service.impl;

import com.jkoss.study.educational.entity.Standarditem;
import com.jkoss.study.educational.mapper.StandarditemMapper;
import com.jkoss.study.educational.service.IStandarditemService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;


/**
 * 考评选项 服务实现类
 * 
 * @Author chair
 * @Version 1.0, 2019-06-06
 * @See
 * @Since com.jkoss.study.educational.service.impl
 * @Description: TODO
 */
@Service
public class StandarditemServiceImpl extends ServiceImpl<StandarditemMapper, Standarditem> implements IStandarditemService {

}
