package com.jkoss.study.educational.service.impl;

import com.jkoss.study.educational.entity.Clazz;
import com.jkoss.study.educational.mapper.ClazzMapper;
import com.jkoss.study.educational.service.IClazzService;
import com.baomidou.mybatisplus.mapper.SqlHelper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;

import java.util.List;

import org.springframework.stereotype.Service;

/**
 * 班级 服务实现类
 * 
 * @Author chair
 * @Version 1.0, 2019-06-05
 * @See
 * @Since com.jkoss.study.educational.service.impl
 * @Description: TODO
 */
@Service
public class ClazzServiceImpl extends ServiceImpl<ClazzMapper, Clazz> implements IClazzService {

	@Override
	public Page selectVoPage(Page page, Wrapper wrapper) {
		//把分页信息填充到条件
		SqlHelper.fillWrapper(page, wrapper);
		page.setRecords(baseMapper.selectVoPage(page, wrapper));
		return page;
	}

	@Override
	public List<Clazz> selectClazzes10MthAgo() {
		// TODO Auto-generated method stub
		return baseMapper.selectList10MthAgo();
	}

}
