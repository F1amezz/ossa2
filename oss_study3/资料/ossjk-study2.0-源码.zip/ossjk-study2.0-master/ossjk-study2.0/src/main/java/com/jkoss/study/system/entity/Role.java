package com.jkoss.study.system.entity;

import java.io.Serializable;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.jkoss.base.entity.BaseEntity;

/**
 * 角色
 * 
 * @Author Jason
 * @Version 1.0, 2019-05-28
 * @See
 * @Since com.jkoss.study.system.entity
 * @Description: TODO
 */
public class Role extends BaseEntity<Role> {

	private static final long serialVersionUID = 1L;

 
	/**
	 * 父id
	 */
	@TableField("pid")
	private String pid;
	/**
	 * 名称
	 */
	@TableField("name")
	private String name;
	/**
	 * 备注
	 */
	@TableField("remk")
	private String remk;
	 
	 

	public String getPid() {
		return pid;
	}

	public void setPid(String pid) {
		this.pid = pid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRemk() {
		return remk;
	}

	public void setRemk(String remk) {
		this.remk = remk;
	}
 

	@Override
	protected Serializable pkVal() {
		return this.id;
	}

	@Override
	public String toString() {
		return "Role{" + ", id=" + id + ", pid=" + pid + ", name=" + name + ", remk=" + remk + ", createTime="
				+ createTime + ", creator=" + creator + ", modifyTime=" + modifyTime + ", modifier=" + modifier + "}";
	}
}
