package com.jkoss.study.learn.service;

import com.jkoss.study.learn.entity.Standardplan;
import com.baomidou.mybatisplus.service.IService;

/**
 * 考评计划 服务类
 * 
 * @Author chair
 * @Version 1.0, 2019-06-13
 * @See
 * @Since com.jkoss.study.learn.service
 * @Description: TODO
 */
public interface IStandardplanService extends IService<Standardplan> {

	String selectMaxPlantDate();

}
