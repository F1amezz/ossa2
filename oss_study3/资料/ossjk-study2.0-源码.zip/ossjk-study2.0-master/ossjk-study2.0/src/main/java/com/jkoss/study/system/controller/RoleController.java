package com.jkoss.study.system.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.mapper.Condition;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.jkoss.base.controller.BaseController;
import com.jkoss.common.util.CommonUtil;
import com.jkoss.common.vo.DwzPageBean;
import com.jkoss.common.vo.ZtreeBean;
import com.jkoss.study.system.entity.Permission;
import com.jkoss.study.system.entity.Role;
import com.jkoss.study.system.service.IPermissionService;
import com.jkoss.study.system.service.IRolePermissionService;
import com.jkoss.study.system.service.IRoleService;

/**
 * 角色 前端控制器
 * 
 * @Author Jason
 * @Version 1.0, 2019-05-28
 * @See
 * @Since com.jkoss.study.system.controller
 * @Description: TODO
 */
@Controller
@RequestMapping("/system/role")
public class RoleController extends BaseController {

	@Autowired
	private IRoleService iRoleService;

	@Autowired
	private IRolePermissionService iRolePermissionService;

	@Autowired
	private IPermissionService iPermissionService;

	/**
	 * 列表
	 * 
	 * @param roleName
	 * @param dwzPageBean
	 * @param map
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/list")
	@RequiresPermissions("/system/role/list")
	public String list(String roleName, DwzPageBean dwzPageBean, ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		dwzPageBean.getCountResultMap().put("roleName", roleName);
		Wrapper wrapper = Condition.create().like("name", roleName);
		// 字段排序
		if (!CommonUtil.isBlank(dwzPageBean.getOrderField()) && !CommonUtil.isBlank(dwzPageBean.getOrderDirection())) {
			wrapper.orderBy(dwzPageBean.getOrderField(), CommonUtil.isEquals(dwzPageBean.getOrderDirection(), "asc"));
		} else {
			wrapper.orderBy("create_time", false);
		}
		Page resultPage = iRoleService.selectPage(dwzPageBean.toPage(), wrapper);
		map.put("dwzPageBean", dwzPageBean.toDwzPageBean(resultPage));
		return "system/role/list";
	}

	/**
	 * 去新增
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/toInsert")
	@RequiresPermissions("/system/role/toInsert")
	public String toInsert(ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		return "system/role/edit";
	}

	@RequestMapping("/insert")
	@RequiresPermissions("/system/role/toInsert")
	@ResponseBody
	public Object insert(@Valid Role role, HttpServletRequest request, HttpServletResponse response) {
		if (iRoleService.insert(role)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}

	}

	/**
	 * 去修改
	 * 
	 * @param id
	 * @param map
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/toUpdate")
	@RequiresPermissions("/system/role/toUpdate")
	public String toUpdate(String id, ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		map.put("record", iRoleService.selectById(id));
		return "system/role/edit";
	}

	/**
	 * 修改
	 * 
	 * @param role
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/update")
	@RequiresPermissions("/system/role/toUpdate")
	@ResponseBody
	public Object update(@Valid Role role, HttpServletRequest request, HttpServletResponse response) {
		if (iRoleService.updateById(role)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	/**
	 * 删除
	 * 
	 * @param id
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/delete")
	@RequiresPermissions("/system/role/delete")
	@ResponseBody
	public Object delete(String[] id, HttpServletRequest request, HttpServletResponse response) {
		if (iRoleService.deleteBatchIds(Arrays.asList(id))) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	/**
	 * 去权限
	 * 
	 * @param id
	 * @param map
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/toUpdatePermission")
	@RequiresPermissions("/system/role/toUpdatePermission")
	public String toUpdatePermission(String id, ModelMap map, HttpServletRequest request, HttpServletResponse response) throws Exception {
		// 把要权限的角色ID传递到页面去
		map.put("id", id);
		// 查询该角色得权限
		List<String> pids = iRolePermissionService.selectPidByRid(id);
		// 查询所有权限
		Wrapper wrapper = Condition.create().orderBy("level", true).orderBy("sort", true);
		List<Permission> permissions = iPermissionService.selectList(wrapper);
		// 把查询回来的实体转成ZtreeBean
		if (!CommonUtil.isBlank(permissions)) {
			List<ZtreeBean> ztreeBeans = new ArrayList();
			for (Permission permission : permissions) {
				ZtreeBean ztreeBean = new ZtreeBean();
				ztreeBean.setId(permission.getId() + "");
				ztreeBean.setIsParent(CommonUtil.isBlank(permission.getPid()));
				ztreeBean.setName(permission.getName());
				ztreeBean.setPId(permission.getPid());
				ztreeBean.setOpen(true);
				// 匹配该权限是否已经选中
				ztreeBean.setChecked(pids.contains(permission.getId()));
				ztreeBeans.add(ztreeBean);
			}
			map.put("ztreeBeans", JSON.toJSONString(ztreeBeans));
		} else {
			map.put("ztreeBeans", "[]");
		}

		return "system/role/updatePermission";
	}

	/**
	 * 授权
	 * 
	 * @param id
	 * @param pid
	 * @param map
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/updatePermission")
	@RequiresPermissions("/system/role/toUpdatePermission")
	@ResponseBody
	public Object updateTpPermission(String id, String[] pid, ModelMap map, HttpServletRequest request, HttpServletResponse response) throws Exception {
		if (iRolePermissionService.updatePermission(id, pid)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}
}
