package com.jkoss.study.exam.api.pc;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.mapper.Condition;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.jkoss.base.controller.BaseController;
import com.jkoss.common.util.CommonUtil;
import com.jkoss.common.util.CryptoUtils;
import com.jkoss.common.util.JwtTokenUtil;
import com.jkoss.study.config.wxlogin.WxLoginConfig;
import com.jkoss.study.config.wxlogin.WxLoginVo;
import com.jkoss.study.educational.entity.Student;
import com.jkoss.study.educational.service.IStudentService;
import com.jkoss.study.educational.vo.StudentVo;
import com.jkoss.study.system.entity.Teacher;
import com.jkoss.study.system.entity.Token;
import com.jkoss.study.system.service.ITokenService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

@Api(tags = "PC端登录API")
@RestController
@RequestMapping("/pc/user")
public class LoginPcController extends BaseController {

	@Autowired
	private IStudentService iStudentService;
	@Autowired
	protected ITokenService iTokenService;
	@Autowired
	protected JwtTokenUtil jwtTokenUtil;
	@Autowired
	private WxLoginConfig wxLoginConfig;

	@Value("${wx.pcRedirectURl}")
	private String pcRedirectURl;

	@ApiOperation("登录")
	@ApiImplicitParams({

			@ApiImplicitParam(name = "lname", value = "用户名", dataType = "String", example = "datou", required = true, paramType = "query"),
			@ApiImplicitParam(name = "pwd", value = "密码", dataType = "String", example = "123456", required = true, paramType = "query")

	})
	@PostMapping(value = "/login")
	@ResponseBody
	public Object pcLogin(@ApiIgnore Student student) {
		Wrapper wrapper = Condition.create();
		wrapper.eq("lname", student.getLname());
		String msg = "帐号不存在";
		// Student obj = iStudentService.selectOne(wrapper);

		StudentVo vo = iStudentService.selectVo(wrapper);

		if (!CommonUtil.isBlank(vo)) {
			if (vo.getPwd().equals(CryptoUtils.encodeMD5(student.getPwd()))) {
				Wrapper wrapper2 = Condition.create();
				wrapper2.eq("uid", vo.getId());
				iTokenService.delete(wrapper2);

				Token token2 = new Token();
				token2.setUid(vo.getId());
				String tokenStr = jwtTokenUtil.getToken(vo.getId(), JSON.toJSONString(vo));
				log.info(tokenStr);
				token2.setDuration(jwtTokenUtil.getTokenTimeOut(tokenStr));
				token2.setToken(tokenStr);
				iTokenService.insert(token2);

				Map map = CommonUtil.toMap(vo);
				map.put("token", tokenStr);
				return ajaxDone("200", "登录成功", map);
			} else {
				msg = "密码错误";
			}

		}
		return ajaxDone("300", msg);
	}

	@RequestMapping(value = "/pcWxlogin")
	@ResponseBody
	public Object pcWxlogin(String code, ModelMap map, HttpSession session) throws Exception {
		System.out.println("跳转ok，code=" + code);
		WxLoginVo wxLoginVo = wxLoginConfig.wxLogin(code);
		String tokenStr = null;
		if (!CommonUtil.isBlank(wxLoginVo.getUnionid())) {
			Wrapper wrapper = Condition.create().eq("s.wxuid", wxLoginVo.getUnionid());
			Student student = iStudentService.selectVo(wrapper);
			if (!CommonUtil.isBlank(student)) {
				Wrapper wrapper2 = Condition.create();
				wrapper2.eq("uid", student.getId());
				iTokenService.delete(wrapper2);

				Token token2 = new Token();
				token2.setUid(student.getId());
				tokenStr = jwtTokenUtil.getToken(student.getId(), JSON.toJSONString(student));
				token2.setDuration(jwtTokenUtil.getTokenTimeOut(tokenStr));
				token2.setToken(tokenStr);
				iTokenService.insert(token2);
			}
		}
		 return new ModelAndView(new RedirectView(pcRedirectURl + "?token=" +
		 tokenStr));
		 //return ajaxSuccess(tokenStr);
	}

	/**
	 * @return 获取用户信息
	 */
	@ApiOperation("获取用户信息")
	@GetMapping("/getInfo")
	@ResponseBody
	public Object getInfo(HttpServletRequest request) {
		String token = jwtTokenUtil.getPCToken(request);
		String userid = jwtTokenUtil.getUserId(token);
		Wrapper wrapper = Condition.create().eq("s.id", userid);
		Student student = iStudentService.selectVo(wrapper);
		return ajaxSuccess(student);
	}

}
