package com.jkoss.study.learn.mapper;

import com.jkoss.study.learn.entity.Standardplan;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * 考评计划 Mapper 接口
 * 
 * @Author chair
 * @Version 1.0, 2019-06-13
 * @See
 * @Since com.jkoss.study.learn.mapper
 * @Description: TODO
 */
public interface StandardplanMapper extends BaseMapper<Standardplan> {

	String selectMaxPlantDate();

}
