package com.jkoss.study.exam.service;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.IService;
import com.jkoss.study.exam.entity.Answer;
import com.jkoss.study.exam.vo.AnswerVo;
import com.jkoss.study.exam.api.vo.AnswerVo2;

/**
 * 答题表 服务类
 * 
 * @Author Jason
 * @Version 1.0, 2019-10-21
 * @See
 * @Since com.jkoss.study.exam.service
 * @Description: TODO
 */
public interface IAnswerService extends IService<Answer> {

	Page selectVoPage(Page page, Wrapper wrapper);

	AnswerVo selectVoByid(String id);

	List selectExpid(Wrapper wrapper);

	List selectTranscript(Wrapper wrapper);

	AnswerVo2 selectTranscriptById(String id);

	Page selectTranscriptVoPage(Page page, Wrapper wrapper);

}
