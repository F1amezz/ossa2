package com.jkoss.study.exam.api.pc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.baomidou.mybatisplus.mapper.Condition;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.jkoss.base.controller.BaseController;
import com.jkoss.common.util.CommonUtil;
import com.jkoss.common.util.JwtTokenUtil;
import com.jkoss.study.exam.service.IAnswerService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiKeyAuthDefinition;
import io.swagger.annotations.ApiKeyAuthDefinition.ApiKeyLocation;
import io.swagger.annotations.ApiOperation;

/**
 * 成绩单API
 * 
 * @author SIMOBAI
 * 
 *
 */

@Api(tags = "PC端成绩单API")
@RestController
@RequestMapping("/pc/api/transcript")
public class TranscriptPcController extends BaseController {

	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	@Autowired
	private IAnswerService iAnswerService;

	/**
	 * @return 获取成绩单列表API
	 */
	@ApiOperation("获取成绩单列表API,可查询全部、按月份、按日期查询")
	@ApiImplicitParam(name = "date", value = "查询时间：1-参数为空查询所有数据、2-参数（yyyy-MM）查询当月数据、3-参数（yyyy-MM-dd）查询当日数据", dataType = "String", example = "2019-09", paramType = "query")
	@GetMapping("/list")
	@ResponseBody
	public Object transcriptlist(Integer pageSize, Integer pageNum, String date) {

		if (CommonUtil.isBlank(pageSize)) {
			pageSize = 10;
		}
		if (CommonUtil.isBlank(pageNum)) {
			pageNum = 1;
		}
		Page page = new Page(pageNum, pageSize);

		Wrapper wrapper = Condition.create();
		if (!CommonUtil.isBlank(date)) {
			wrapper.like("a.create_time", date);
		}
		String token = getRequest().getHeader("token");
		String userid = jwtTokenUtil.getUserId(token);
		wrapper.eq("a.sid", userid).orderBy("a.create_time", false);
		return ajaxSuccess(iAnswerService.selectTranscriptVoPage(page, wrapper));
	}

	/**
	 * @return 获取成绩单API
	 */
	@ApiOperation("获取成绩单API,根据id查询成绩单")
	@ApiImplicitParam(name = "id", value = "答题卡id", required = true, dataType = "String", paramType = "query")
	@GetMapping("/transcriptById")
	@ResponseBody
	public Object transcriptById(String id) {
		return ajaxSuccess(iAnswerService.selectTranscriptById(id));
	}

}
