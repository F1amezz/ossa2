package com.jkoss.study.educational.vo;

import com.jkoss.study.educational.entity.TeacherClazz;

/**
 * 教师班级中间表Vo
 * 
 * 
 * @Author chair
 * @Version 1.0, 2019年8月21日
 * @See
 * @Since com.jkoss.study.educational.vo
 * @Description: TODO
 */
public class TeacherClazzVo extends TeacherClazz {

	private String tname;

	public String getTname() {
		return tname;
	}

	public void setTname(String tname) {
		this.tname = tname;
	}

	@Override
	public String toString() {
		return "TeacherClazzVo [tname=" + tname + "]";
	}

}
