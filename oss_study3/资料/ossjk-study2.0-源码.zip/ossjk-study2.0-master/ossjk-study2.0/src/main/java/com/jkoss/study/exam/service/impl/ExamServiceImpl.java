package com.jkoss.study.exam.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.mapper.SqlHelper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.jkoss.study.educational.mapper.ClazzMapper;
import com.jkoss.study.exam.entity.Exam;
import com.jkoss.study.exam.mapper.AnswerMapper;
import com.jkoss.study.exam.mapper.ExamMapper;
import com.jkoss.study.exam.service.IExamService;
import com.jkoss.study.exam.vo.ExamVo;

/**
 * 服务实现类
 * 
 * @Author Jason
 * @Version 1.0, 2019-06-08
 * @See
 * @Since com.jkoss.study.exam.service.impl
 * @Description: TODO
 */
@Service
public class ExamServiceImpl extends ServiceImpl<ExamMapper, Exam> implements IExamService {
	
	@Autowired
	private AnswerMapper answMapper ;
	@Autowired
	private ClazzMapper  clazzMapper ;
	
	@Override
	public Page selectVoPage(Page page, Wrapper wrapper) {
		// TODO Auto-generated method stub
		SqlHelper.fillWrapper(page, wrapper);
		List<ExamVo> vos = baseMapper.selectVoPage(page, wrapper);
		if(vos !=null)
		for (ExamVo examVo : vos) {
			Long cnt = answMapper.countAnswer(examVo.getId());
			if(cnt!=null) {
				examVo.setCnted(cnt);
			}else {
				examVo.setCnted(0L);
			}
		}
		page.setRecords(baseMapper.selectVoPage(page, wrapper));
		return page;
	}
	
	@Override
	public boolean insert(Exam exam) {
		//参加考试的人数
		Long cunt =clazzMapper.countStus(exam.getCid());
		if(cunt==null) {
			exam.setStucnt(0L);
		}else {
			exam.setStucnt(cunt);
		}
		return super.insert(exam);
	}

	@Override
	public List selectExamList(Wrapper wrapper) {
		// TODO Auto-generated method stub
		// SqlHelper.fillWrapper(page, wrapper);
		// page.setRecords(baseMapper.selectExamList( wrapper));
		return baseMapper.selectExamList(wrapper);
	}

}
