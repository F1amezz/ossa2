package com.jkoss.study.exam.service.impl;

import com.jkoss.study.exam.entity.Exampaper;
import com.jkoss.study.exam.mapper.ExampaperMapper;
import com.jkoss.study.exam.service.IExampaperService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;


/**
 *  服务实现类
 * 
 * @Author Jason
 * @Version 1.0, 2019-06-05
 * @See
 * @Since com.jkoss.study.exam.service.impl
 * @Description: TODO
 */
@Service
public class ExampaperServiceImpl extends ServiceImpl<ExampaperMapper, Exampaper> implements IExampaperService {

}
