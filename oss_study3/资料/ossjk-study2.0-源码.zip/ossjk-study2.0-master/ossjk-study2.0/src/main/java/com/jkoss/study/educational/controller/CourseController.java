package com.jkoss.study.educational.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.mapper.Condition;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.jkoss.base.controller.BaseController;
import com.jkoss.common.util.CommonUtil;
import com.jkoss.common.vo.DwzPageBean;
import com.jkoss.common.vo.ZtreeBean;
import com.jkoss.study.educational.entity.Course;
import com.jkoss.study.educational.service.ICourseService;
import com.jkoss.study.system.entity.Permission;

/**
 * 课程 前端控制器
 * 
 * @Author chair
 * @Version 1.0, 2019-06-04
 * @See
 * @Since com.jkoss.study.educational.controller
 * @Description: TODO
 */
@Controller
@RequestMapping("/educational/course")
public class CourseController extends BaseController {

	@Autowired
	private ICourseService iCourseService;

	@RequestMapping("/list")
	@RequiresPermissions("/educational/course/list")
	public String list(ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		// 从数据库查找数据
		Wrapper wrapper = Condition.create();
		wrapper.orderBy("level", true).orderBy("sort", true);
		List<Course> courses = iCourseService.selectList(wrapper);
		// 由于从数据库查找的数据与前端数据格式不匹配
		// 所以我们需要把为前端的数据格式建立一个vo类
		// 把我们从数据库得到的数据转为建立的vo类
		if (!CommonUtil.isBlank(courses)) {
			List<ZtreeBean> ztreeBeans = new ArrayList();
			for (Course course : courses) {
				// 把查询回来的实体转成ZtreeBean
				ZtreeBean ztreeBean = new ZtreeBean();
				ztreeBean.setId(course.getId() + "");
				ztreeBean.setIsParent(CommonUtil.isBlank(course.getPid()));
				ztreeBean.setName(course.getName());
				ztreeBean.setPId(course.getPid());
				ztreeBean.setOpen(true);
				ztreeBeans.add(ztreeBean);
			}
			map.put("ztreeBeans", JSON.toJSONString(ztreeBeans));
		} else {
			map.put("ztreeBeans", "[]");
		}
		return "educational/course/list";
	}

	@RequestMapping("/toInsert")
	@RequiresPermissions("/educational/course/toInsert")
	public String toInsert(String pid, ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		if (!CommonUtil.isBlank(pid)) {
			// 有PID的时候把父节点查询回来。带到前端
			map.put("parent", iCourseService.selectById(pid));
		}
		return "educational/course/edit";
	}

	@RequestMapping("/insert")
	@RequiresPermissions("/educational/course/toInsert")
	@ResponseBody
	public Object insert(@Valid Course course, HttpServletRequest request, HttpServletResponse response) {
		if (iCourseService.insert(course)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}

	}

	@RequestMapping("/toUpdate")
	@RequiresPermissions("/educational/course/toUpdate")
	public String toUpdate(String id, ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		Course course= iCourseService.selectById(id);
		map.put("record", iCourseService.selectById(id));
		if (!CommonUtil.isBlank(course.getPid())) {
			// 有PID的时候把父节点查询回来。带到前端
			map.put("parent", iCourseService.selectById(course.getPid()));
		}
		return "educational/course/edit";
	}

	@RequestMapping("/update")
	@RequiresPermissions("/educational/course/toUpdate")
	@ResponseBody
	public Object update(@Valid Course course, HttpServletRequest request, HttpServletResponse response) {
		if (iCourseService.updateById(course)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/delete")
	@RequiresPermissions("/educational/course/delete")
	@ResponseBody
	public Object delete(String[] id, HttpServletRequest request, HttpServletResponse response) {
		if (iCourseService.deleteBatchIds(Arrays.asList(id))) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

}
