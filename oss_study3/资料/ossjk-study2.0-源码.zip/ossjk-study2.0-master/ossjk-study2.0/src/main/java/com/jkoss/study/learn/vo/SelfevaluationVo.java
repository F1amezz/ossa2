package com.jkoss.study.learn.vo;

import com.jkoss.study.learn.entity.Selfevaluation;

/**
 * 自我评价Vo
 * 
 * @Author chair
 * @Version 1.0, 2019-07-12
 * @See
 * @Since com.jkoss.study.learn.entity
 * @Description: TODO
 */
public class SelfevaluationVo extends Selfevaluation {

	private String sname;
	private String cname;
	private String tname;
	private String qa1;
	private String qa2;
	private String qa3;

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getQa1() {
		return qa1;
	}

	public void setQa1(String qa1) {
		this.qa1 = qa1;
	}

	public String getQa2() {
		return qa2;
	}

	public void setQa2(String qa2) {
		this.qa2 = qa2;
	}

	public String getQa3() {
		return qa3;
	}

	public void setQa3(String qa3) {
		this.qa3 = qa3;
	}

	public String getTname() {
		return tname;
	}

	public void setTname(String tname) {
		this.tname = tname;
	}

	@Override
	public String toString() {
		return "SelfevaluationVo [sname=" + sname + ", cname=" + cname + ", tname=" + tname + ", qa1=" + qa1 + ", qa2=" + qa2 + ", qa3=" + qa3 + "]";
	}

}
