package com.jkoss.study.interview.mapper;

import com.jkoss.study.interview.entity.Post;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * 岗位 Mapper 接口
 * 
 * @Author chair
 * @Version 1.0, 2019-06-24
 * @See
 * @Since com.jkoss.study.interview.mapper
 * @Description: TODO
 */
public interface PostMapper extends BaseMapper<Post> {

}
