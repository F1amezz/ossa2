package com.jkoss.study.interview.service;

import com.jkoss.study.interview.entity.Enterprise;
import com.baomidou.mybatisplus.service.IService;

/**
 * 企业表 服务类
 * 
 * @Author chair
 * @Version 1.0, 2019-06-20
 * @See
 * @Since com.jkoss.study.interview.service
 * @Description: TODO
 */
public interface IEnterpriseService extends IService<Enterprise> {

	

}
