package com.jkoss.study.system.service;

import com.jkoss.study.system.entity.Permission;

import java.util.List;

import com.baomidou.mybatisplus.service.IService;

/**
 * 权限 服务类
 * 
 * @Author Jason
 * @Version 1.0, 2019-05-28
 * @See
 * @Since com.jkoss.study.system.service
 * @Description: TODO
 */
public interface IPermissionService extends IService<Permission> {

	List<Permission> selectByUid(String id);

}
