package com.jkoss.study.config.wxlogin;

public class WxLoginVo {
	private String accessToke;
	private String openid;
	private String unionid;

	public String getAccessToke() {
		return accessToke;
	}

	public void setAccessToke(String accessToke) {
		this.accessToke = accessToke;
	}

	public String getOpenid() {
		return openid;
	}

	public void setOpenid(String openid) {
		this.openid = openid;
	}

	public String getUnionid() {
		return unionid;
	}

	public void setUnionid(String unionid) {
		this.unionid = unionid;
	}

	@Override
	public String toString() {
		return "WxLoginVo [accessToke=" + accessToke + ", openid=" + openid + ", unionid=" + unionid + "]";
	}

}
