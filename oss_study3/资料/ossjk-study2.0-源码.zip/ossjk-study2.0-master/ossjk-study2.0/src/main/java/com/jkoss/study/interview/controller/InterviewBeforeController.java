package com.jkoss.study.interview.controller;

import java.util.Arrays;

import javax.security.auth.Subject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.apache.shiro.authz.annotation.RequiresRoles;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.baomidou.mybatisplus.mapper.Condition;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.jkoss.base.controller.BaseController;
import com.jkoss.common.util.CommonUtil;
import com.jkoss.common.vo.DwzPageBean;
import com.jkoss.study.constant.Constant;
import com.jkoss.study.educational.entity.Student;
import com.jkoss.study.educational.service.IClazzService;
import com.jkoss.study.interview.entity.Enterprise;
import com.jkoss.study.interview.entity.Interview;
import com.jkoss.study.interview.entity.Post;
import com.jkoss.study.interview.service.IEnterpriseService;
import com.jkoss.study.interview.service.IInterviewService;
import com.jkoss.study.interview.service.IPostService;

/**
 * 面试表 前端控制器
 * 
 * @Author Jason
 * @Version 1.0, 2019-08-11
 * @See
 * @Since com.jkoss.study.interview.controller
 * @Description: TODO
 */
@Controller
@RequestMapping("/interview/interviewbefore")
public class InterviewBeforeController extends BaseController {

	@Autowired
	private IInterviewService iInterviewService;
	@Autowired
	private IEnterpriseService iEnterpriseService;
	@Autowired
	private IPostService iPostService;
	@Autowired
	private IClazzService iClazzService;

	@RequestMapping("/list")
	@RequiresPermissions("/interview/interviewbefore/list")
	public String list(String cid, String sname, String interviewdate, String ename, DwzPageBean dwzPageBean, ModelMap map, HttpServletRequest request, HttpServletResponse response, HttpSession session) throws Exception {
		// 状态 1-准备、2-面试完成
		Wrapper wrapper = Condition.create().isWhere(true).eq("i.state", "1");
		if (!CommonUtil.isBlank(cid)) {
			// 根据班级搜索
			wrapper.isWhere(true);
			wrapper.eq("c.id", cid);
			dwzPageBean.getCountResultMap().put("cid", cid);
		}
		if (!CommonUtil.isBlank(sname)) {
			// 根据学生搜索
			wrapper.isWhere(true);
			wrapper.like("s.name", sname);
			dwzPageBean.getCountResultMap().put("sname", sname);
		}
		if (!CommonUtil.isBlank(ename)) {
			// 根据企业搜索
			wrapper.isWhere(true);
			wrapper.like("e.name", ename);
			dwzPageBean.getCountResultMap().put("ename", ename);
		}
		if (!CommonUtil.isBlank(interviewdate)) {
			// 根据学生搜索
			wrapper.isWhere(true);
			wrapper.like("interviewdate", interviewdate);
			dwzPageBean.getCountResultMap().put("interviewdate", interviewdate);
		}
		// 登录用户
		if (isStudent()) {
			// 学生登录
			Student student = (Student) session.getAttribute(Constant.SESSION_USER_KEY);
			wrapper.isWhere(true);
			wrapper.eq("i.sid", student.getId());
		}
		if (!CommonUtil.isBlank(dwzPageBean.getOrderField()) && !CommonUtil.isBlank(dwzPageBean.getOrderDirection())) {
			dwzPageBean.getCountResultMap().put("orderField", dwzPageBean.getOrderField());
			dwzPageBean.getCountResultMap().put("orderDirection", dwzPageBean.getOrderDirection());
			wrapper.orderBy(dwzPageBean.getOrderField(), CommonUtil.isEquals(dwzPageBean.getOrderDirection(), "asc"));
		} else {
			// 默认排序字段
			wrapper.orderBy("i.create_time", false);
		}
		Page resultPage = iInterviewService.selectVoPage(dwzPageBean.toPage(), wrapper);
		map.put("dwzPageBean", dwzPageBean.toDwzPageBean(resultPage));
		// 查询所有班级
		map.put("clazzs", iClazzService.selectList(null));
		// 回显企业信息
		map.put("enterprises", iEnterpriseService.selectList(null));
		return "interview/interviewbefore/list";
	}

	@RequestMapping("/toInsert")
	@RequiresPermissions("/interview/interviewbefore/toInsert")
	public String toInsert(ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		map.put("enterprises", iEnterpriseService.selectList(null));
		return "interview/interviewbefore/edit";
	}

	@RequestMapping("/insert")
	@RequiresPermissions("/interview/interviewbefore/toInsert")
	@ResponseBody
	public Object insert(@Valid Interview interview, HttpServletRequest request, HttpServletResponse response) {
		interview.setSid(getUserId());
		// 状态 1-准备、2-面试完成
		interview.setState(1);
		if (iInterviewService.insert(interview)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}

	}

	@RequestMapping("/toUpdate")
	@RequiresPermissions("/interview/interviewbefore/toUpdate")
	public String toUpdate(String id, ModelMap map, HttpServletRequest request, HttpServletResponse response) {

		Interview interview = iInterviewService.selectById(id);
		// 回显企业信息
		map.put("enterprises", iEnterpriseService.selectList(null));
		// 回显岗位信息
		Wrapper wrapper = Condition.create().eq("eid", interview.getEid());
		map.put("posts", iPostService.selectList(wrapper));
		map.put("record", interview);
		return "interview/interviewbefore/edit";
	}

	@RequestMapping("/update")
	@RequiresPermissions("/interview/interviewbefore/toUpdate")
	@ResponseBody
	public Object update(@Valid Interview interview, HttpServletRequest request, HttpServletResponse response) {
		if (iInterviewService.updateById(interview)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/delete")
	@RequiresPermissions("/interview/interviewbefore/delete")
	@ResponseBody
	public Object delete(String[] id, HttpServletRequest request, HttpServletResponse response) {
		if (iInterviewService.deleteBatchIds(Arrays.asList(id))) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/getPost")
	@ResponseBody
	public Object getPost(String id, ModelMap map) {
		Wrapper wrapper = Condition.create().eq("eid", id);
		return ajaxSuccess(iPostService.selectList(wrapper));
	}

}
