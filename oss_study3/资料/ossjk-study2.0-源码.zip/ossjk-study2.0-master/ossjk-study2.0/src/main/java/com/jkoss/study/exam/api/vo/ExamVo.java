package com.jkoss.study.exam.api.vo;

public class ExamVo {
	private int statusCode;
	private Object exam;
	private Object record;
	private Object subjects;
	private Object paperVo;

	private Object examlist;

	private Object subexam;

	public int getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

	public Object getExam() {
		return exam;
	}

	public void setExam(Object exam) {
		this.exam = exam;
	}

	public Object getRecord() {
		return record;
	}

	public void setRecord(Object record) {
		this.record = record;
	}

	public Object getSubjects() {
		return subjects;
	}

	public void setSubjects(Object subjects) {
		this.subjects = subjects;
	}

	public Object getPaperVo() {
		return paperVo;
	}

	public void setPaperVo(Object paperVo) {
		this.paperVo = paperVo;
	}

	public Object getExamlist() {
		return examlist;
	}

	public void setExamlist(Object examlist) {
		this.examlist = examlist;
	}

	public Object getSubexam() {
		return subexam;
	}

	public void setSubexam(Object subexam) {
		this.subexam = subexam;
	}

}
