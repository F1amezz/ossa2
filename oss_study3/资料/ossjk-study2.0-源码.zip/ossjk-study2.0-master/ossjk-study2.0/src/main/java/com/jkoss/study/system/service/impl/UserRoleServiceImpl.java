package com.jkoss.study.system.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.mapper.Condition;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.jkoss.common.util.CommonUtil;
import com.jkoss.study.educational.entity.Student;
import com.jkoss.study.educational.service.IStudentService;
import com.jkoss.study.system.entity.UserRole;
import com.jkoss.study.system.mapper.UserRoleMapper;
import com.jkoss.study.system.service.IUserRoleService;

/**
 * 用户角色 服务实现类
 * 
 * @Author Jason
 * @Version 1.0, 2019-05-28
 * @See
 * @Since com.jkoss.study.system.service.impl
 * @Description: TODO
 */
@Service
public class UserRoleServiceImpl extends ServiceImpl<UserRoleMapper, UserRole> implements IUserRoleService {
	@Autowired
	private IStudentService iStudentService;

	@Override
	public boolean updateRole(String id, String[] rid) {
		// 删除所有用户角色
		Wrapper wrapper = Condition.create().eq("uid", id);
		this.baseMapper.delete(wrapper);
		if (!CommonUtil.isBlank(rid)) {
			List<UserRole> rolePermissions = new ArrayList();
			for (String ridStr : rid) {
				UserRole tpEmployRole = new UserRole();
				tpEmployRole.setUid(id);
				tpEmployRole.setRid(ridStr);
				rolePermissions.add(tpEmployRole);
			}
			return this.insertBatch(rolePermissions);
		} else {
			return true;
		}
	}

	@Override
	public boolean updateStudentRoleByCid(String cid, String rid) {
		// 删除本班学生所有权限
		this.baseMapper.deleteStudentRoleByCid(cid);
		// 查找本班学生
		List<Student> students = iStudentService.selectList(Condition.create().eq("clzid", cid));
		if (!CommonUtil.isBlank(students)) {
			List<UserRole> userRoles = new ArrayList();
			for (Student student : students) {
				UserRole userRole = new UserRole();
				userRole.setUid(student.getId());
				userRole.setRid(rid);
				userRoles.add(userRole);
			}
			if (!CommonUtil.isBlank(userRoles)) {
				return this.insertBatch(userRoles);
			}
		}
		// 没有查找到学生返回空
		return true;

	}
}
