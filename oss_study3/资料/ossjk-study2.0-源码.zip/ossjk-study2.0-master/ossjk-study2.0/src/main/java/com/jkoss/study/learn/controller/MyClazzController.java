package com.jkoss.study.learn.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.baomidou.mybatisplus.mapper.Condition;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.jkoss.common.util.CommonUtil;
import com.jkoss.common.vo.DwzPageBean;
import com.jkoss.study.constant.Constant;
import com.jkoss.study.educational.entity.Student;
import com.jkoss.study.educational.service.IStudentService;

/**
 * 我的班級 前端控制器
 * 
 * @Author chair
 * @Version 1.0, 2019-06-05
 * @See
 * @Since com.jkoss.study.learn.controller
 * @Description: TODO
 */
@Controller
@RequestMapping("/learn/myclazz")
public class MyClazzController {
	@Autowired
	private IStudentService iStudentService;

	@RequestMapping("/list")
	@RequiresPermissions("/learn/myclazz/list")
	public String list(DwzPageBean dwzPageBean, HttpSession session, ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		Wrapper wrapper = Condition.create();
		// 拿到当前登录的学生
		Student student = (Student) session.getAttribute(Constant.SESSION_USER_KEY);
		wrapper.eq("clzid", student.getClzid());
		if (!CommonUtil.isBlank(dwzPageBean.getOrderField()) && !CommonUtil.isBlank(dwzPageBean.getOrderDirection())) {
			wrapper.orderBy(dwzPageBean.getOrderField(), CommonUtil.isEquals(dwzPageBean.getOrderDirection(), "asc"));
		} else {
			// 默认排序字段
			wrapper.orderBy("create_time", false);
		}
		Page resultPage = iStudentService.selectPage(dwzPageBean.toPage(), wrapper);
		map.put("dwzPageBean", dwzPageBean.toDwzPageBean(resultPage));
		return "learn/myclazz/list";
	}
}
