package com.jkoss.study.exam.api.pc;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.mapper.Condition;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.jkoss.base.controller.BaseController;
import com.jkoss.common.util.CommonUtil;
import com.jkoss.common.util.JwtTokenUtil;
import com.jkoss.study.exam.api.vo.AnswerVo;
import com.jkoss.study.exam.api.vo.ExamVo;
import com.jkoss.study.exam.api.vo.Sanswer;
import com.jkoss.study.exam.api.vo.SanswerVo;
import com.jkoss.study.exam.entity.Answer;
import com.jkoss.study.exam.entity.Exam;
import com.jkoss.study.exam.entity.Exampaper;
import com.jkoss.study.exam.entity.Question;
import com.jkoss.study.exam.service.IAnswerService;
import com.jkoss.study.exam.service.IExamService;
import com.jkoss.study.exam.service.IExampaperService;
import com.jkoss.study.exam.service.IPointService;
import com.jkoss.study.exam.service.IQuestionService;
import com.jkoss.study.exam.vo.PaperVo;
import com.jkoss.study.exam.vo.PaperVo.Content;
import com.jkoss.study.exam.vo.PaperVo.Content.Qcontent;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

/**
 * 日常考试API
 * 
 * @author SIMOBAI
 * 
 *
 */
@Api(tags = "PC端日常考试API")
@RestController
@RequestMapping("/pc/api/daily")
public class DailyExamPcController extends BaseController {
	@Autowired
	private IExamService iExamService;
	@Autowired
	private IPointService iPointService;
	@Autowired
	private IQuestionService iQuestionService;
	@Autowired
	private IExampaperService iExampaperService;
	@Autowired
	private IAnswerService iAnswerService;

	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	/**
	 * @return 获取试卷API
	 */
	@ApiOperation("获取试卷API")
	@ApiImplicitParam(name = "cid", value = "班级id", dataType = "String", example = "223e9da647254f0fb48a4bb736d94143", paramType = "query")
	@GetMapping("/list")
	@ResponseBody
	public Object dailylist2(@ApiIgnore HttpSession session, String cid, @ApiIgnore ModelMap map,
			@ApiIgnore HttpServletRequest request, @ApiIgnore HttpServletResponse response) throws ParseException {
		// 获取当前时间 格式为 yyyy-MM-dd HH:mm:ss.SSS
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.HOUR_OF_DAY, 23);
		cal.set(Calendar.MINUTE, 59);
		cal.set(Calendar.SECOND, 59);
		Wrapper wrapper = Condition.create();
		wrapper.eq("cid", cid);
		wrapper.between("start_time", CommonUtil.date(), CommonUtil.getDate(cal.getTime(), "yyyy-MM-dd HH:mm:ss"))
				.orderBy("create_time", true);
		Exam e = iExamService.selectOne(wrapper);
		// 获取当前时间
		Date newDate = new Date();

		if (!CommonUtil.isBlank(e)) {

			String token = getRequest().getHeader("token");
			String userid = jwtTokenUtil.getUserId(token);

			if (newDate.getTime() < CommonUtil.getDate(e.getStartTime(), "ISO6").getTime()) {
				return ajaxDone("300", "测试未开始");
			}
			// 判断是否已经过时
			else if (newDate.getTime() > CommonUtil.getDate(e.getEndTime(), "ISO6").getTime()) {
				return ajaxDone("300", "考试已经结束");
			} else if (!CommonUtil.isBlank(iAnswerService
					.selectOne(Condition.create().eq("expid", e.getExpid()).eq("sid", userid).between("create_time",
							CommonUtil.date(), CommonUtil.getDate(cal.getTime(), "yyyy-MM-dd HH:mm:ss"))))) {
				return ajaxDone("300", "你已提交试卷");
			} else {
				ExamVo Vo = new ExamVo();
				Vo.setExam(e);
				Vo.setStatusCode(200);
				return Vo;
			}
		} else {
			return ajaxDone("300", "当天没有测试");
		}

	}

	/**
	 * @return 获取试卷API
	 */
	@ApiOperation("获取试卷,知识点API")
	@ApiImplicitParam(name = "cid", value = "班级id", dataType = "String", example = "223e9da647254f0fb48a4bb736d94143", paramType = "query")
	@GetMapping("/dailyOne")
	@ResponseBody
	public Object dailyOne(@ApiIgnore HttpSession session, String cid, @ApiIgnore ModelMap map,
			@ApiIgnore HttpServletRequest request, @ApiIgnore HttpServletResponse response) throws ParseException {

		// 获取当前时间 格式为 yyyy-MM-dd HH:mm:ss.SSS
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.HOUR_OF_DAY, 23);
		cal.set(Calendar.MINUTE, 59);
		cal.set(Calendar.SECOND, 59);
		Wrapper wrapper = Condition.create();
		wrapper.eq("cid", cid);
		wrapper.between("start_time", CommonUtil.date(), CommonUtil.getDate(cal.getTime(), "yyyy-MM-dd HH:mm:ss"))
				.orderBy("create_time", true);
		Exam e = iExamService.selectOne(wrapper);

		// 获取当前时间
		Date newDate = new Date();
		if (!CommonUtil.isBlank(e)) {
			String token = getRequest().getHeader("token");
			String userid = jwtTokenUtil.getUserId(token);
			if (newDate.getTime() < CommonUtil.getDate(e.getStartTime(), "ISO6").getTime()) {
				return ajaxDone("300", "测试未开始");
			}
			// 判断是否已经过时
			else if (newDate.getTime() > CommonUtil.getDate(e.getEndTime(), "ISO6").getTime()) {
				return ajaxDone("300", "考试已经结束");
			} else if (!CommonUtil.isBlank(iAnswerService
					.selectOne(Condition.create().eq("expid", e.getExpid()).eq("sid", userid).between("create_time",
							CommonUtil.date(), CommonUtil.getDate(cal.getTime(), "yyyy-MM-dd HH:mm:ss"))))) {
				return ajaxDone("300", "你已提交试卷");
			}

			else {
				Exampaper exampaper = iExampaperService.selectById(e.getExpid());
				String content = exampaper.getContent();
				System.out.println(content);
				PaperVo paperVo = JSON.parseObject(content, PaperVo.class);
				Wrapper wrapper2 = Condition.create();
				if (!CommonUtil.isBlank(paperVo.getContents())) {
					List<String> zpids = new ArrayList<>();
					for (PaperVo.Content qcontent : paperVo.getContents()) {
						List<String> qids = qcontent.getQid();
						for (String qid : qids) {
							Question question = iQuestionService.selectById(qid);
							if (CommonUtil.isBlank(qcontent.getQcontent())) {
								// qcontents = new ArrayList();
								qcontent.setQcontent(new ArrayList());
							}
							if (CommonUtil.isBlank(qcontent.getAnswer())) {
								// qansers = new ArrayList();
								qcontent.setAnswer(new ArrayList());
							}
							System.out.println(question.getContent());

							qcontent.getQcontent().add(JSON.parseObject(question.getContent(), Qcontent.class));
							qcontent.getAnswer().add(question.getAnswer());
							zpids.add(question.getZpid());
						}
					}
					wrapper2.in("p1.id", zpids);
				}
				ExamVo Vo = new ExamVo();
				exampaper.setContent("");
				Vo.setExam(e);
				Vo.setRecord(exampaper);
				Vo.setSubjects(iPointService.selectAllLevelByPid(wrapper2));
				Vo.setPaperVo(paperVo);
				Vo.setStatusCode(200);
				return Vo;
			}
		} else {
			return ajaxDone("300", "当天没有测试");
		}

	}

	// 提交评分API
	@ApiOperation("提交评分API")
	@PostMapping(value = "/insert")
	@ResponseBody
	public Object dailySubmit(Sanswer sanswer, @ApiIgnore HttpServletRequest request,
			@ApiIgnore HttpServletResponse response) {
		System.out.println("提交评分API");
		try {
			List<SanswerVo> list = JSON.parseArray(sanswer.getAnswer(), SanswerVo.class);
			Exampaper exampaper = iExampaperService.selectById(sanswer.getExpid());
			String content = exampaper.getContent();
			PaperVo paperVo = JSON.parseObject(content, PaperVo.class);
			Wrapper wrapper2 = Condition.create();
			if (!CommonUtil.isBlank(paperVo.getContents())) {
				Calendar cal = Calendar.getInstance();
				cal.set(Calendar.HOUR_OF_DAY, 23);
				cal.set(Calendar.MINUTE, 59);
				cal.set(Calendar.SECOND, 59);

				String token = getRequest().getHeader("token");
				String userid = jwtTokenUtil.getUserId(token);
				if (!CommonUtil.isBlank(iAnswerService.selectOne(
						Condition.create().eq("expid", sanswer.getExpid()).eq("sid", userid).between("create_time",
								CommonUtil.date(), CommonUtil.getDate(cal.getTime(), "yyyy-MM-dd HH:mm:ss"))))) {
					return ajaxDone("300", "你已提交试卷");
				} else {
					List<String> zpids = new ArrayList<>();
					int index = 0;
					for (PaperVo.Content qcontent : paperVo.getContents()) {
						List<String> qids = qcontent.getQid();
						for (String qid : qids) {
							Question question = iQuestionService.selectById(qid);
							if (CommonUtil.isBlank(qcontent.getQcontent())) {
								qcontent.setQcontent(new ArrayList());
							}
							if (CommonUtil.isBlank(qcontent.getAnswer())) {
								qcontent.setAnswer(new ArrayList());
							}
							if (CommonUtil.isBlank(qcontent.getSanswer())) {
								qcontent.setSanswer(new ArrayList());
							}
//							Map map = JSON.parseObject(question.getContent(), Map.class);
//							map.put("analysis", question.getAnalysis() == null ? "" : question.getAnalysis());
//							qcontent.getQcontent().add(map);
//							qcontent.getAnswer().add(question.getAnswer());

							PaperVo.Content.Qcontent map = JSON.parseObject(question.getContent(), Qcontent.class);
							map.setAnalysis(question.getAnalysis() == null ? "" : question.getAnalysis());

							qcontent.getQcontent().add(map);
							qcontent.getAnswer().add(question.getAnswer());
							zpids.add(question.getZpid());

						}
						if (CommonUtil.isBlank(list) || CommonUtil.isBlank(list.get(index))) {
							qcontent.getSanswer().addAll(new ArrayList());
						} else {
							qcontent.getSanswer().addAll(list.get(index).getSanswer());
							qcontent.setType(list.get(index).getType());
						}

						// System.out.println(list.get(index).getSanswer());
						if (index < list.size() - 1) {
							index++;
						}
					}
					wrapper2.in("p1.id", zpids);
				}
			}

			Answer answer = new Answer();
			answer.setEid(sanswer.getEid());
			answer.setCid(sanswer.getCid());
			answer.setType(exampaper.getType());
			answer.setExpid(sanswer.getExpid());
			answer.setDuration(exampaper.getDuration());
			String token = getRequest().getHeader("token");
			String userid = jwtTokenUtil.getUserId(token);
			answer.setSid(userid);
			answer.setScore(countAnswer(paperVo));
//			System.out.println(" ===============》 " + JSON.toJSONString(paperVo.getContents()));
			answer.setAnswer(JSON.toJSONString(paperVo));
			answer.setCreateTime(CommonUtil.date6());
			// answer.setCreator(getUserId());

			if (iAnswerService.insert(answer)) {
				return ajaxDone("200", "提交成功", answer.getId());
			}
		} catch (Exception e) {
			e.printStackTrace();
			return ajaxDone("300", "提交失败");
		}

		return ajaxDone("300", "提交失败");

	}

	// 判断封装
	private Double countAnswer(PaperVo paperVo) {

		// 进行评分
		Double sum = 0d;
		Content ctt = null;
		// 分析题型
		for (int i = 0; i < paperVo.getTypes().size(); i++) {
			// 获取数量
			String type = paperVo.getTypes().get(i);
			for (int j = 0; j < Integer.parseInt(paperVo.getQnums().get(i)); j++) {
				ctt = paperVo.getContents().get(i);
				String answer = ctt.getAnswer().get(j).toString();
				Double qscore = new Double(paperVo.getContents().get(i).getQscore().get(j));

				if (ctt.getSscore() == null) {
					ctt.setSscore(new ArrayList());
				}

				if (!CommonUtil.isBlank(paperVo.getContents().get(i).getSanswer())) {

					if (!CommonUtil.isBlank(paperVo.getContents().get(i).getSanswer().get(j))) {
						String sanswers = paperVo.getContents().get(i).getSanswer().get(j).toString();
						switch (type) {

						case "1":
							if (answer.equals(sanswers)) {
								sum += qscore;
								ctt.getSscore().add(new BigDecimal(qscore + ""));
							} else {
								ctt.getSscore().add(new BigDecimal(0));
							}
							break;
						// 多选题评分
						case "2":
							String[] answer_array = answer.split(",");
							String[] sanswers_array = sanswers.split(",");
							int y = 0;
							for (int k = 0; k < answer_array.length; k++) {
								for (int k2 = 0; k2 < sanswers_array.length; k2++) {
									if (answer_array[k].equals(sanswers_array[k2])) {
										y++;
									}
								}
							}
							if (y == answer_array.length) {
								sum += qscore;
								ctt.getSscore().add(new BigDecimal(qscore + ""));
							} else {
								ctt.getSscore().add(new BigDecimal(0));
							}
							break;
						case "3": // 判斷

							if (answer.trim().equals(sanswers.trim())) {
								sum += qscore;
								ctt.getSscore().add(new BigDecimal(qscore + ""));
							} else {
								ctt.getSscore().add(new BigDecimal("0"));
							}

							break;
						default:
							// 主观题
							ctt.getSscore().add(new BigDecimal("0"));
							break;
						}
					} else {
						ctt.getSscore().add(new BigDecimal("0"));
					}
				} else {
					ctt.getSscore().add(new BigDecimal("0"));
				}
			}
		}
		// 根据题型，判断对应的答案
		return Double.parseDouble(CommonUtil.df.format(sum));
	}

	/**
	 * @param sanswer
	 * @param request
	 * @param response
	 * @return
	 */
	@ApiOperation("获取试卷,试卷内容API")
	@ApiImplicitParam(name = "cid", value = "班级id", dataType = "String", example = "223e9da647254f0fb48a4bb736d94143", paramType = "query")
	@GetMapping(value = "/listMark")
	@ResponseBody
	public Object dailyAnswer(String cid, @ApiIgnore HttpServletRequest request,
			@ApiIgnore HttpServletResponse response) {

		Wrapper wrapper = Condition.create();
		String token = getRequest().getHeader("token");
		String userid = jwtTokenUtil.getUserId(token);
		wrapper.eq("e.cid", cid);
		wrapper.eq("a.sid", userid);

		List<AnswerVo> vo = iAnswerService.selectExpid(wrapper);
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.HOUR_OF_DAY, 23);
		cal.set(Calendar.MINUTE, 59);
		cal.set(Calendar.SECOND, 59);

		Wrapper wrapper2 = Condition.create();
		wrapper2.eq("cid", cid);
		wrapper2.between("start_time", CommonUtil.date(), CommonUtil.getDate(cal.getTime(), "yyyy-MM-dd HH:mm:ss"));
		Exam e = iExamService.selectOne(wrapper2);

		ExamVo Vo = new ExamVo();
		if (!CommonUtil.isBlank(e)) {
			Exampaper exampaper = iExampaperService.selectById(e.getExpid());
			// String content = exampaper.getContent();
			exampaper.setContent("");
			Vo.setRecord(exampaper);
		} else {
			Vo.setRecord(null);
		}

		Vo.setExam(e);
		Vo.setExamlist(vo);

		Vo.setStatusCode(200);

		return Vo;

	}

	@ApiOperation("获取试卷,试卷内容API")
	@ApiImplicitParam(name = "cid", value = "班级id", dataType = "String", example = "223e9da647254f0fb48a4bb736d94143", paramType = "query")
	@GetMapping("/listByCid")
	@ResponseBody
	public Object dailylist3(@ApiIgnore HttpSession session, String cid, String expid, @ApiIgnore ModelMap map,
			@ApiIgnore HttpServletRequest request, @ApiIgnore HttpServletResponse response) throws ParseException {

		// 获取当前时间 格式为 yyyy-MM-dd HH:mm:ss.SSS
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.HOUR_OF_DAY, 23);
		cal.set(Calendar.MINUTE, 59);
		cal.set(Calendar.SECOND, 59);
		Wrapper wrapper = Condition.create();
		wrapper.eq("cid", cid);
		Exam e = iExamService.selectOne(wrapper);

		// 获取当前时间
		Date newDate = new Date();
		String token = getRequest().getHeader("token");
		String userid = jwtTokenUtil.getUserId(token);
		Wrapper wrapperAnswer = Condition.create();
		wrapperAnswer.eq("cid", cid).eq("expid", expid).eq("sid", userid);
		Answer answer = iAnswerService.selectOne(wrapperAnswer);
		Exampaper exampaper = iExampaperService.selectById(expid);
		String content = exampaper.getContent();
		Content content2 = null;
		if (!CommonUtil.isBlank(answer)) {
			content2 = JSON.parseObject(answer.getAnswer(), Content.class);
		}

		PaperVo paperVo = JSON.parseObject(content, PaperVo.class);
		Wrapper wrapper2 = Condition.create();
		if (!CommonUtil.isBlank(paperVo.getContents())) {
			List<String> zpids = new ArrayList<>();
			for (PaperVo.Content qcontent : paperVo.getContents()) {
				List<String> qids = qcontent.getQid();
				int index = 0;
				for (String qid : qids) {
					Question question = iQuestionService.selectById(qid);
					if (CommonUtil.isBlank(qcontent.getQcontent())) {
						// qcontents = new ArrayList();
						qcontent.setQcontent(new ArrayList());
					}
					if (CommonUtil.isBlank(qcontent.getAnswer())) {
						// qansers = new ArrayList();
						qcontent.setAnswer(new ArrayList());
					}
					if (CommonUtil.isBlank(qcontent.getSanswer())) {
						qcontent.setSanswer(new ArrayList());
					}

//					qcontent.getQcontent().add(JSON.parseObject(question.getContent(), Map.class));
//					qcontent.getSanswer().add(content2.getAnswer().get(index).toString());
					qcontent.getQcontent().add(JSON.parseObject(question.getContent(), Qcontent.class));
					qcontent.getSanswer().add(content2.getAnswer().get(index).toString());
					zpids.add(question.getZpid());
					if (index < content2.getAnswer().size() - 1) {
						index++;
					}
				}
			}
			wrapper2.in("p1.id", zpids);
		}
		ExamVo Vo = new ExamVo();
		exampaper.setContent("");
		Vo.setExam(e);
		Vo.setRecord(exampaper);
		Vo.setSubjects(iPointService.selectAllLevelByPid(wrapper2));
		Vo.setPaperVo(paperVo);
		Vo.setStatusCode(200);
		return Vo;

	}

	@ApiOperation("获取考试信息内容")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "cid", value = "班级id", dataType = "String", example = "85a8d5c702974af9bfd3acb0edc8ea48", required = true, paramType = "query"),
			@ApiImplicitParam(name = "date", value = "时间", dataType = "String", example = "yyyy-MM", paramType = "query") })
	@GetMapping("/examList")
	@ResponseBody
	public Object examList(String cid, String date) {
		Wrapper wrapper = Condition.create();
		if (CommonUtil.isBlank(cid)) {
			return ajaxError("班级id不能为空");
		}
		wrapper.eq("e.cid", cid);
		if (!CommonUtil.isBlank(date)) {
			wrapper.like("e.start_time", date);
		}
		return ajaxSuccess(iExamService.selectExamList(wrapper));
	}

}
