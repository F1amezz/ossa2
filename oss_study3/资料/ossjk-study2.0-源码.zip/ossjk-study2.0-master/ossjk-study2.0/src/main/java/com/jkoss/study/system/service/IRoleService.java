package com.jkoss.study.system.service;

import com.jkoss.study.system.entity.Role;

import java.util.List;

import com.baomidou.mybatisplus.service.IService;

/**
 * 角色 服务类
 * 
 * @Author Jason
 * @Version 1.0, 2019-05-28
 * @See
 * @Since com.jkoss.study.system.service
 * @Description: TODO
 */
public interface IRoleService extends IService<Role> {

	List<Role> selectListByUid(String id);

}
