package com.jkoss.study.system.entity;

import java.io.Serializable;
import java.util.Date;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.jkoss.base.entity.BaseEntity;

/**
 * 
 * 
 * @Author Jason
 * @Version 1.0, 2019-11-06
 * @See
 * @Since com.jkoss.examination.exam.entity
 * @Description: TODO
 */
public class Token extends BaseEntity<Token> {

	private static final long serialVersionUID = 1L;

	@TableId("id")
	private String id;
	/**
	 * 用户id
	 */
	@TableField("uid")
	private String uid;
	/**
	 * token
	 */
	@TableField("token")
	private String token;
	/**
	 * 时效
	 */
	@TableField("duration")
	private Date duration;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public Date getDuration() {
		return duration;
	}

	public void setDuration(Date duration) {
		this.duration = duration;
	}

	@Override
	protected Serializable pkVal() {
		return this.id;
	}

	@Override
	public String toString() {
		return "Token{" + ", id=" + id + ", uid=" + uid + ", token=" + token + ", duration=" + duration + ", modifier=" + modifier + "}";
	}
}
