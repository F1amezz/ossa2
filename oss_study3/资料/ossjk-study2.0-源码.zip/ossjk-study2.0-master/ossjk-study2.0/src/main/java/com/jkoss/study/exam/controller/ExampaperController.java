package com.jkoss.study.exam.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.mapper.Condition;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.jkoss.base.controller.BaseController;
import com.jkoss.common.util.CommonUtil;
import com.jkoss.common.vo.DwzPageBean;
import com.jkoss.common.vo.ZtreeBean;
import com.jkoss.study.exam.entity.Exampaper;
import com.jkoss.study.exam.entity.Question;
import com.jkoss.study.exam.service.IExampaperService;
import com.jkoss.study.exam.service.IPointService;
import com.jkoss.study.exam.service.IQuestionService;
import com.jkoss.study.exam.vo.PaperVo;
import com.jkoss.study.exam.vo.PaperVo.Content;
import com.jkoss.study.exam.vo.PaperVo.Content.Qcontent;
import com.jkoss.study.exam.vo.PointVo;
import com.jkoss.study.exam.vo.QusetionVo;

/**
 * 前端控制器
 * 
 * @Author Jason
 * @Version 1.0, 2019-06-05
 * @See
 * @Since com.jkoss.study.exam.controller
 * @Description: TODO
 */
@Controller
@RequestMapping("/exam/exampaper")
public class ExampaperController extends BaseController {

	@Autowired
	private IExampaperService iExampaperService;
	@Autowired
	private IPointService iPointService;
	@Autowired
	private IQuestionService iQuestionService;

	@RequestMapping("/list")
	@RequiresPermissions("/exam/exampaper/list")
	public String list(String name, String type, String tid, DwzPageBean dwzPageBean, ModelMap map,
			HttpServletRequest request, HttpServletResponse response) {
		dwzPageBean.getCountResultMap().put("name", name);
		dwzPageBean.getCountResultMap().put("type", type);
		dwzPageBean.getCountResultMap().put("tid", tid);
		Wrapper wrapper = Condition.create();
		if (!CommonUtil.isBlank(dwzPageBean.getOrderField()) && !CommonUtil.isBlank(dwzPageBean.getOrderDirection())) {
			dwzPageBean.getCountResultMap().put("orderField", dwzPageBean.getOrderField());
			dwzPageBean.getCountResultMap().put("orderDirection", dwzPageBean.getOrderDirection());
			wrapper.orderBy(dwzPageBean.getOrderField(), CommonUtil.isEquals(dwzPageBean.getOrderDirection(), "asc"));
		} else {
			// 默认排序字段
			wrapper.orderBy("create_time", false);
		}
		if (!CommonUtil.isBlank(name)) {
			wrapper.like("q.name", name);
		}
		if (!CommonUtil.isBlank(type)) {
			wrapper.like("q.type", type);
		}

		if (!CommonUtil.isEquals(tid, "0")) {
			if (!CommonUtil.isBlank(tid)) {
				wrapper.eq("q.creator", tid);
				request.getSession().setAttribute("tid", tid);
			} else {
				Object tidStore = request.getSession().getAttribute("tid");
				if (!CommonUtil.isBlank(tidStore) && !CommonUtil.isEquals(tidStore, "0")) {
					wrapper.eq("q.creator", tidStore.toString());
				}
			}
		}else {
			request.getSession().setAttribute("tid", tid);
		}

		Page resultPage = iExampaperService.selectPage(dwzPageBean.toPage(), wrapper);
		map.put("dwzPageBean", dwzPageBean.toDwzPageBean(resultPage));
		return "exam/exampaper/list";
	}

	@RequestMapping("/toInsert")
	@RequiresPermissions("/exam/exampaper/toInsert")
	public String toInsert(HttpServletRequest request, HttpServletResponse response) {
		return "exam/exampaper/insert1";
	}

	@RequestMapping("/insert1")
	@RequiresPermissions("/exam/exampaper/toInsert")
	@ResponseBody
	public Object insert1(@Valid Exampaper exampaper, String[] subjects, ModelMap map, HttpServletRequest request,
			HttpServletResponse response) {
		return ajaxSuccess();
	}

	@RequestMapping("/toInsert2")
	public String toInsert2(Exampaper exampaper, String[] subjects, ModelMap map, HttpServletRequest request,
			HttpServletResponse response) {
		map.put("exampaper", exampaper);
		map.put("exampaperJSON", JSON.toJSONString(exampaper));
//		map.put("subjects", subjects);
//		return "exam/exampaper/insert2";
		map.put("subjects", subjects);
		map.put("subjectsJSON", JSON.toJSONString(subjects));
		return "exam/exampaper/insert2";
	}

	@RequestMapping("/toInsert2Question")
	public String toInsert2Question(DwzPageBean dwzPageBean, String cpid, String mpid, String zpid, String[] subjects,
			String name, String type, ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		map.put("subjects", subjects);
		if (!CommonUtil.isBlank(subjects)) {
			Wrapper wrapper = Condition.create();
			wrapper.in("p3.id", subjects);

			if (!CommonUtil.isBlank(name)) {
				wrapper.like("q.name", name);
				map.put("name", name);
			}
			if (!CommonUtil.isBlank(type)) {
				wrapper.eq("q.type", type);
				map.put("type", type);
			}

			if (!CommonUtil.isBlank(cpid)) {
				wrapper.like("q.cpid", cpid);
				dwzPageBean.getCountResultMap().put("cpid", cpid);
			}
			if (!CommonUtil.isBlank(mpid)) {
				wrapper.like("q.mpid", mpid);
				dwzPageBean.getCountResultMap().put("mpid", mpid);
			}
			if (!CommonUtil.isBlank(zpid)) {
				wrapper.like("q.zpid", zpid);
				dwzPageBean.getCountResultMap().put("zpid", zpid);
			}

			Page resultPage = iQuestionService.selectVoPage(dwzPageBean.toPage(), wrapper);
			map.put("dwzPageBean", dwzPageBean.toDwzPageBean(resultPage));
//			map.put("questions", JSON.toJSONString(iQuestionService.selectVo(wrapper)));
		}
		Wrapper wrapper1 = Condition.create().eq("level", "1");
		map.put("cpnames", iPointService.selectList(wrapper1));
		Wrapper wrapper2 = Condition.create().eq("level", "2").like("pid", cpid);
		map.put("mpnames", iPointService.selectList(wrapper2));
		Wrapper wrapper3 = Condition.create().eq("level", "3").like("pid", mpid);
		map.put("zpnames", iPointService.selectList(wrapper3));
		return "exam/exampaper/insert2Question";
	}

	@RequestMapping("/insert2")
	@RequiresPermissions("/exam/exampaper/toInsert")
	@ResponseBody
	public Object insert2(@Valid Exampaper exampaper, String[] subjects, ModelMap map, HttpServletRequest request,
			HttpServletResponse response) {
		return ajaxSuccess();
	}

	/**
	 * 添加题目到购物车
	 * 
	 * @return
	 * @throws IllegalAccessException
	 * @throws InstantiationException
	 */
	@RequestMapping("/toCheckQuestionsCart")
	@RequiresPermissions("/exam/exampaper/toInsert")
	public Object toCheckQuestionsCart(DwzPageBean dwzPageBean, String[] id, String type, ModelMap map,
			HttpSession httpSession) throws InstantiationException, IllegalAccessException {

//		if (!CommonUtil.isBlank(id)) {
//			Wrapper wrapper = Condition.create();
//			wrapper.in("q.id", Arrays.asList(id));
//			Page resultPage = iQuestionService.selectVoPage(dwzPageBean.toPage(), wrapper);
//			map.put("dwzPageBean", dwzPageBean.toDwzPageBean(resultPage));
//			map.put("questions", JSON.toJSONString(iQuestionService.selectVo(wrapper)));
//		}
//
//		return "exam/exampaper/questionsCart";
		map.put("type", type);
		if (!CommonUtil.isBlank(id)) {
			Wrapper wrapper = Condition.create();
			wrapper.in("q.id", Arrays.asList(id));
			wrapper.eq("q.type", 1);
			List type1 = iQuestionService.selectVo(wrapper);
			map.put("type1", type1);

			Wrapper wrapper2 = Condition.create();
			wrapper2.in("q.id", Arrays.asList(id));
			wrapper2.eq("q.type", 2);
			List type2 = iQuestionService.selectVo(wrapper2);
			map.put("type2", type2);

			Wrapper wrapper3 = Condition.create();
			wrapper3.in("q.id", Arrays.asList(id));
			wrapper3.eq("q.type", 3);
			List type3 = iQuestionService.selectVo(wrapper3);
			map.put("type3", type3);

			Wrapper wrapper4 = Condition.create();
			wrapper4.in("q.id", Arrays.asList(id));
			wrapper4.eq("q.type", 4);
			List type4 = iQuestionService.selectVo(wrapper4);
			map.put("type4", type4);

			Wrapper wrapper5 = Condition.create();
			wrapper5.in("q.id", Arrays.asList(id));
			wrapper5.eq("q.type", 5);
			List type5 = iQuestionService.selectVo(wrapper5);
			map.put("type5", type5);

			Wrapper wrapper6 = Condition.create();
			wrapper6.in("q.id", Arrays.asList(id));
			wrapper6.eq("q.type", 6);
			List type6 = iQuestionService.selectVo(wrapper6);
			map.put("type6", type6);

			Wrapper wrapper7 = Condition.create();
			wrapper7.in("q.id", Arrays.asList(id));
			wrapper7.eq("q.type", 7);
			List type7 = iQuestionService.selectVo(wrapper7);
			map.put("type7", type7);

//			map.put("questions", JSON.toJSONString(iQuestionService.selectVo(wrapper7)));
		}
		return "exam/exampaper/questionsCart2";

	}

	@RequestMapping("/toInsert3")
	public String toInsert3(Exampaper exampaper, String[] subjects, String[] qid, ModelMap map,
			HttpServletRequest request, HttpServletResponse response) {
		if (!CommonUtil.isBlank(qid)) {
			List<Question> questions = iQuestionService.selectBatchIds(Arrays.asList(qid));
			map.put("questions", JSON.toJSONString(questions));
		}
		map.put("exampaper", exampaper);
		map.put("exampaperJSON", JSON.toJSONString(exampaper));
//		map.put("subjects", subjects);
//		return "exam/exampaper/insert2";
		map.put("subjects", subjects);
		return "exam/exampaper/insert3";
	}

	@RequestMapping("/insert3")
	@ResponseBody
	public Object insert3(String exampaperJSON, String content, ModelMap map, HttpServletRequest request,
			HttpServletResponse response) {
		Exampaper exampaper = JSON.parseObject(exampaperJSON, Exampaper.class);
		exampaper.setContent(content);
		if (iExampaperService.insert(exampaper)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/toSubject")
	public String toSubject(ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		// 查询所有课程
		List<PointVo> points = iPointService.selectAllLevelByPid(null);
		// 把查询回来的实体转成ZtreeBean
		if (!CommonUtil.isBlank(points)) {
			List<ZtreeBean> ztreeBeans = new ArrayList();
			for (PointVo point : points) {
				ZtreeBean ztreeBean = new ZtreeBean();
				ztreeBean.setId(point.getId() + "");
				ztreeBean.setIsParent(CommonUtil.isBlank(point.getPid()));
				ztreeBean.setName(point.getName());
				ztreeBean.setPId(point.getPid());
				ztreeBean.setOpen(true);
				ztreeBeans.add(ztreeBean);
				ztreeBean.setOther(point.getGpname() + "=>" + point.getPname() + "=>" + point.getName());

			}
			map.put("ztreeBeans", JSON.toJSONString(ztreeBeans));
		} else {
			map.put("ztreeBeans", "[]");
		}

		return "exam/exampaper/subject";
	}

	@RequestMapping("/toQuestion")
	public String toQuestion(DwzPageBean dwzPageBean, String name, String cpid, String mpid, String zpid,
			String[] subjects, String type, String num, ModelMap map, HttpServletRequest request,
			HttpServletResponse response) {
		if (!CommonUtil.isBlank(subjects)) {
			Wrapper wrapper = Condition.create();
			wrapper.eq("q.type", type);
			wrapper.in("p3.id", subjects);

			if (!CommonUtil.isBlank(name)) {
				wrapper.like("q.name", name);
				dwzPageBean.getCountResultMap().put("name", name);
			}
			if (!CommonUtil.isBlank(cpid)) {
				wrapper.like("q.cpid", cpid);
				dwzPageBean.getCountResultMap().put("cpid", cpid);
			}
			if (!CommonUtil.isBlank(mpid)) {
				wrapper.like("q.mpid", mpid);
				dwzPageBean.getCountResultMap().put("mpid", mpid);
			}
			if (!CommonUtil.isBlank(zpid)) {
				wrapper.like("q.zpid", zpid);
				dwzPageBean.getCountResultMap().put("zpid", zpid);
			}

			Page resultPage = iQuestionService.selectVoPage(dwzPageBean.toPage(), wrapper);
			map.put("dwzPageBean", dwzPageBean.toDwzPageBean(resultPage));

			List<QusetionVo> list = iQuestionService.selectVo(wrapper);
			System.out.println(list.size());
			for (QusetionVo qusetionVo : list) {
//				System.out.println(qusetionVo.getContent());
				Qcontent qcontent = JSON.parseObject(qusetionVo.getContent(), Qcontent.class);
				qusetionVo.setQcontent(qcontent);
//				qusetionVo.setContent(null);
			}
			map.put("questions", JSON.toJSONString(list));
			map.put("num", num);
			map.put("type", type);
			map.put("subjects", subjects);

			Wrapper wrapper1 = Condition.create().eq("level", "1");
			map.put("cpnames", iPointService.selectList(wrapper1));
			Wrapper wrapper2 = Condition.create().eq("level", "2").like("pid", cpid);
			map.put("mpnames", iPointService.selectList(wrapper2));
			Wrapper wrapper3 = Condition.create().eq("level", "3").like("pid", mpid);
			map.put("zpnames", iPointService.selectList(wrapper3));

		}
		return "exam/exampaper/question";
	}

	@RequestMapping("/listDetail")
	@RequiresPermissions("/exam/exampaper/listDetail")
	public String listDetail(String id, ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		Exampaper exampaper = iExampaperService.selectById(id);
		String content = exampaper.getContent();
		PaperVo paperVo = JSON.parseObject(content, PaperVo.class);
		Wrapper wrapper = Condition.create();
		if (!CommonUtil.isBlank(paperVo.getContents())) {
			List<String> zpids = new ArrayList<>();
			for (PaperVo.Content qcontent : paperVo.getContents()) {
				List<String> qids = qcontent.getQid();
				for (String qid : qids) {
					Question question = iQuestionService.selectById(qid);
					if (CommonUtil.isBlank(qcontent.getQcontent())) {
						// qcontents = new ArrayList();
						qcontent.setQcontent(new ArrayList());
					}
					if (CommonUtil.isBlank(qcontent.getAnswer())) {
						// qansers = new ArrayList();
						qcontent.setAnswer(new ArrayList());
					}
					qcontent.getQcontent().add(JSON.parseObject(question.getContent(), Qcontent.class));
					qcontent.getAnswer().add(question.getAnswer());
					zpids.add(question.getZpid());
				}
			}
			wrapper.in("p1.id", zpids);
		}
		map.put("record", exampaper);
		map.put("subjects", iPointService.selectAllLevelByPid(wrapper));
		map.put("paperVo", JSON.toJSONString(paperVo));
		return "exam/exampaper/listDetail";
	}

	@RequestMapping("/toUpdate")
	@RequiresPermissions("/exam/exampaper/toUpdate")
	public String toUpdate(String id, ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		Exampaper exampaper = iExampaperService.selectById(id);
		String content = exampaper.getContent();
		PaperVo paperVo = JSON.parseObject(content, PaperVo.class);
		Wrapper wrapper = Condition.create();
		if (!CommonUtil.isBlank(paperVo.getContents())) {
			List<String> zpids = new ArrayList<>();
			for (PaperVo.Content qcontent : paperVo.getContents()) {
				List<String> qids = qcontent.getQid();
				for (String qid : qids) {
					Question question = iQuestionService.selectById(qid);
					if (CommonUtil.isBlank(qcontent.getQcontent())) {
						// qcontents = new ArrayList();
						qcontent.setQcontent(new ArrayList());
					}
					if (CommonUtil.isBlank(qcontent.getAnswer())) {
						// qansers = new ArrayList();
						qcontent.setAnswer(new ArrayList());
					}
					qcontent.getQcontent().add(JSON.parseObject(question.getContent(), Qcontent.class));
					qcontent.getAnswer().add(question.getAnswer());
					zpids.add(question.getZpid());
				}
			}
			wrapper.in("p1.id", zpids);
		}
		map.put("record", exampaper);
		map.put("subjects", iPointService.selectAllLevelByPid(wrapper));
		map.put("paperVo", JSON.toJSONString(paperVo));
		return "exam/exampaper/update";
	}

	@RequestMapping("/update")
	@RequiresPermissions("/exam/exampaper/toUpdate")
	@ResponseBody
	public Object update(@Valid Exampaper exampaper, String content, HttpServletRequest request,
			HttpServletResponse response) {
		exampaper.setContent(content);
		if (iExampaperService.updateById(exampaper)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/delete")
	@RequiresPermissions("/exam/exampaper/delete")
	@ResponseBody
	public Object delete(String[] id, HttpServletRequest request, HttpServletResponse response) {
		if (iExampaperService.deleteBatchIds(Arrays.asList(id))) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/deleteQuestion")
	@RequiresPermissions("/exam/exampaper/toUpdate")
	@ResponseBody
	public Object deleteQuestion(ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		return ajaxSuccess();
	}
}
