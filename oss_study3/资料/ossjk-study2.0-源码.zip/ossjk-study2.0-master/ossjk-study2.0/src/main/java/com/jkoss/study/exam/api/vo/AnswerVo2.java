package com.jkoss.study.exam.api.vo;

import com.jkoss.study.exam.entity.Answer;

public class AnswerVo2 extends Answer {

	private String expname;

	private int expscore;

	private String exptype;
	private String expduration;
	private String exppassscore;

	public String getExpname() {
		return expname;
	}

	public void setExpname(String expname) {
		this.expname = expname;
	}

	public int getExpscore() {
		return expscore;
	}

	public void setExpscore(int expscore) {
		this.expscore = expscore;
	}

	public String getExptype() {
		return exptype;
	}

	public void setExptype(String exptype) {
		this.exptype = exptype;
	}

	public String getExpduration() {
		return expduration;
	}

	public void setExpduration(String expduration) {
		this.expduration = expduration;
	}

	public String getExppassscore() {
		return exppassscore;
	}

	public void setExppassscore(String exppassscore) {
		this.exppassscore = exppassscore;
	}

}
