package com.jkoss.study.exam.entity;

import java.io.Serializable;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.jkoss.base.entity.BaseEntity;

/**
 * 
 * 
 * @Author Jason
 * @Version 1.0, 2019-06-05
 * @See
 * @Since com.jkoss.study.exam.entity
 * @Description: TODO
 */
public class Exampaper extends BaseEntity<Exampaper> {

	private static final long serialVersionUID = 1L;

	/**
	 * id
	 */
	@TableId("id")
	private String id;
	@TableField("name")
	private String name;
	@TableField("duration")
	private Integer duration;
	@TableField("score")
	private Integer score;
	@TableField("pass_score")
	private Integer passScore;
	@TableField("type")
	private Integer type;
	@TableField("is_visible")
	private Integer isVisible;
	@TableField("content")
	private String content;
	/**
	 * ״̬ 1-
	 */
	@TableField("status")
	private Integer status;
	@TableField("mark")
	private String mark;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getDuration() {
		return duration;
	}

	public void setDuration(Integer duration) {
		this.duration = duration;
	}

	public Integer getScore() {
		return score;
	}

	public void setScore(Integer score) {
		this.score = score;
	}

	public Integer getPassScore() {
		return passScore;
	}

	public void setPassScore(Integer passScore) {
		this.passScore = passScore;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public Integer getIsVisible() {
		return isVisible;
	}

	public void setIsVisible(Integer isVisible) {
		this.isVisible = isVisible;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getMark() {
		return mark;
	}

	public void setMark(String mark) {
		this.mark = mark;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(String modifyTime) {
		this.modifyTime = modifyTime;
	}

	public String getModifier() {
		return modifier;
	}

	public void setModifier(String modifier) {
		this.modifier = modifier;
	}

	@Override
	protected Serializable pkVal() {
		return this.id;
	}

	@Override
	public String toString() {
		return "Exampaper{" + ", id=" + id + ", name=" + name + ", duration=" + duration + ", score=" + score + ", passScore=" + passScore + ", type=" + type + ", isVisible=" + isVisible + ", content=" + content + ", status=" + status + ", mark=" + mark + ", createTime=" + createTime + ", creator=" + creator + ", modifyTime=" + modifyTime + ", modifier=" + modifier + "}";
	}
}
