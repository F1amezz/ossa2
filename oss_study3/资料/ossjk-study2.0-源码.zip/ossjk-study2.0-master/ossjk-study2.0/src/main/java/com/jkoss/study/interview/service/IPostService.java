package com.jkoss.study.interview.service;

import com.jkoss.study.interview.entity.Post;
import com.baomidou.mybatisplus.service.IService;

/**
 * 岗位 服务类
 * 
 * @Author chair
 * @Version 1.0, 2019-06-24
 * @See
 * @Since com.jkoss.study.interview.service
 * @Description: TODO
 */
public interface IPostService extends IService<Post> {

}
