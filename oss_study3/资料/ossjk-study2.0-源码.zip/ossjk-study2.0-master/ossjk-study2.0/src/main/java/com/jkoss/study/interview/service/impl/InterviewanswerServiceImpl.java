package com.jkoss.study.interview.service.impl;

import com.jkoss.study.interview.entity.Interviewanswer;
import com.jkoss.study.interview.mapper.InterviewanswerMapper;
import com.jkoss.study.interview.service.IInterviewanswerService;
import com.baomidou.mybatisplus.mapper.Condition;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;

import java.util.List;

import org.springframework.stereotype.Service;

/**
 * 试题解答 服务实现类
 * 
 * @Author Jason
 * @Version 1.0, 2019-08-11
 * @See
 * @Since com.jkoss.study.interview.service.impl
 * @Description: TODO
 */
@Service
public class InterviewanswerServiceImpl extends ServiceImpl<InterviewanswerMapper, Interviewanswer> implements IInterviewanswerService {

	@Override
	public List selectVoList(Wrapper wrapper) {
		return baseMapper.selectVoList(wrapper);
	}

	@Override
	public boolean updateRecommend(String iqid, String id) throws Exception {
		Interviewanswer entity = new Interviewanswer();
		// 推荐 1-是、2-否
		entity.setRecommend(2);
		Wrapper wrapper = Condition.create().eq("iqid", iqid);
		baseMapper.update(entity, wrapper);
		Interviewanswer entity2 = new Interviewanswer();
		entity2.setId(id);
		entity2.setRecommend(1);
		if (baseMapper.updateById(entity2) <= 0) {
			throw new Exception("推荐失败");
		}
		return true;
	}
}
