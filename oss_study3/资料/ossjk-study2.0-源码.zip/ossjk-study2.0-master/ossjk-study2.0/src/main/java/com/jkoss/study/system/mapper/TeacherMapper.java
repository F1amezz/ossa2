package com.jkoss.study.system.mapper;

import com.jkoss.study.system.entity.Teacher;

import java.util.List;

import org.apache.ibatis.annotations.Select;

import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * 教师 Mapper 接口
 * 
 * @Author Jason
 * @Version 1.0, 2019-05-27
 * @See
 * @Since com.jkoss.study.system.mapper
 * @Description: TODO
 */
public interface TeacherMapper extends BaseMapper<Teacher> {
	//取得现有在岗的老师
	@Select("select t.* from user_role u , teacher t where u.uid = t.id and  u.rid='ea1c52a4352047eeaf50e0c10443cc57' and state=1")
	List<Teacher> selectOnJob();	
}
