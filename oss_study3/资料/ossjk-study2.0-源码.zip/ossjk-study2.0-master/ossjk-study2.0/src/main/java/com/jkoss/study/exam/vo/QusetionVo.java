package com.jkoss.study.exam.vo;

import com.baomidou.mybatisplus.annotations.TableField;
import com.jkoss.study.exam.entity.Question;
import com.jkoss.study.exam.vo.PaperVo.Content.Qcontent;

public class QusetionVo extends Question {
	private String cpname;
	private String mpname;
	private String zpname;

	private Qcontent qcontent;

	public Qcontent getQcontent() {
		return qcontent;
	}

	public void setQcontent(Qcontent qcontent) {
		this.qcontent = qcontent;
	}

	public String getCpname() {
		return cpname;
	}

	public void setCpname(String cpname) {
		this.cpname = cpname;
	}

	public String getMpname() {
		return mpname;
	}

	public void setMpname(String mpname) {
		this.mpname = mpname;
	}

	public String getZpname() {
		return zpname;
	}

	public void setZpname(String zpname) {
		this.zpname = zpname;
	}

}
