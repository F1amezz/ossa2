package com.jkoss.common.util;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import com.jkoss.study.constant.Constant;

import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Configuration
public class JwtTokenUtil {

	/**
	 * jwtSecret
	 */
	@Value("${jwt.secret}")
	private String jwtSecret;
	/**
	 * 时效
	 */
	@Value("${jwt.duration}")
	private Long duration;

	private Logger log = LoggerFactory.getLogger(JwtTokenUtil.class);

	public SecretKey generalKey() {
		String stringKey = jwtSecret;
		byte[] encodedKey = Base64.decodeBase64(stringKey);
		SecretKey key = new SecretKeySpec(encodedKey, 0, encodedKey.length, "AES");
		return key;
	}

	public String getToken(String id, String subject) {
		SignatureAlgorithm signatureAlgorithm = SignatureAlgorithm.HS256;
		long nowMillis = System.currentTimeMillis();
		Date now = new Date(nowMillis);
		SecretKey key = generalKey();
		// header Map
		Map<String, Object> header = new HashMap();
		header.put("alg", "HS256");
		header.put("typ", "JWT");
		JwtBuilder builder = Jwts.builder().setHeader(header).setId(UuidUtil.getUUID()).setIssuedAt(now)
				.setSubject(subject).claim("id", id).signWith(signatureAlgorithm, key);
		if (duration >= 0) {
			long expMillis = nowMillis + duration;
			Date exp = new Date(expMillis);
			builder.setExpiration(exp);
		}
		return builder.compact();
	}

	private Map getClaimsMap(String token) {
		if ("null".equals(token) || StringUtils.isBlank(token)) {
			return null;
		}
		try {
			Map<String, Object> jwtClaims = Jwts.parser().setSigningKey(generalKey()).parseClaimsJws(token).getBody();
			return jwtClaims;
		} catch (ExpiredJwtException e) {
			log.error("{}已过期", token);
		} catch (Exception e) {
			log.error("{}", e);
		}
		return null;
	}

	/**
	 * 获取token过期时间
	 * 
	 * @param token
	 * @return
	 * @throws Exception
	 */
	public Date getTokenTimeOut(String token) {
		// 解释token
		Map claims = getClaimsMap(token);
		if (CommonUtil.isBlank(claims)) {
			return null;
		}
		Object expObj = claims.get("exp");
		String exp = expObj.toString();
		// exp转换时间
		Long timestamp = Long.parseLong(exp) * 1000;
		Date expDate = new Date(timestamp);
		System.out.println(CommonUtil.date1(expDate));
		return expDate;
	}

	/**
	 * 获取当前用户id
	 * 
	 * @return
	 * @throws Exception
	 */
	public String getUserId(String token) {
		Map claims = getClaimsMap(token);
		if (CommonUtil.isBlank(claims)) {
			return null;
		}
		return (String) claims.get("id");
	}

	public String getJwtSecret() {
		return jwtSecret;
	}

	public void setJwtSecret(String jwtSecret) {
		this.jwtSecret = jwtSecret;
	}

	public Long getDuration() {
		return duration;
	}

	public void setDuration(Long duration) {
		this.duration = duration;
	}

	// 获取token
	public String getToken(HttpServletRequest request) {
		String token = request.getHeader(Constant.REQUEST_TOKEN_HEADER);
		if (CommonUtil.isBlank(token)) {
			token = request.getParameter(Constant.REQUEST_TOKEN_HEADER);
		}
		return token;
	}

	// 获取token
	public String getPCToken(HttpServletRequest request) {
		String token = request.getHeader(Constant.REQUEST_PC_TOKEN_HEADER);
		if (CommonUtil.isBlank(token)) {
			token = request.getParameter(Constant.REQUEST_PC_TOKEN_HEADER);
		}
		return token;
	}

	public static void main(String[] args) {
		String token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJqdGkiOiI4YWEzMTMwMDlkMDc0YjRhOTBmMzhiNzIxN2E2YTQxOSIsImlhdCI6MTU4NjM0ODMyNiwic3ViIjoie1wiYWRkclwiOlwi6buE5p2RXCIsXCJiaXJ0aFwiOlwiMjAxOS0xMi0wMVwiLFwiY2x0bVwiOlwiMjAxOS0xMi0wN1wiLFwiY2x6aWRcIjpcIjg1YThkNWM3MDI5NzRhZjliZmQzYWNiMGVkYzhlYTQ4XCIsXCJjbmFtZVwiOlwi5rWL6K-V5byA5rqQMeePrVwiLFwiY3JlYXRlVGltZVwiOlwiMjAxOS0xMi0wNyAyMzowNDoxN1wiLFwiY3JlYXRvclwiOlwiNDNcIixcImVncnNcIjoxLFwiaWRcIjpcIjQ4M2M2N2JhOTBiMzRmMjViNzRlZmY3ZDYzYjM1MDFmXCIsXCJpZGNhcmRcIjpcIjEyMzEzMTIzMjEzXCIsXCJsbmFtZVwiOlwiMTM4MDAxMzgwMDBcIixcIm1vZGlmeVRpbWVcIjpcIjIwMTktMTItMDcgMjM6MDQ6MTdcIixcIm5hbWVcIjpcIua1i-ivlei0puWPt1wiLFwicGhvbmVcIjpcIjEzODAwMTM4MDAwXCIsXCJwd2RcIjpcIjhkZGNmZjNhODBmNDE4OWNhMWM5ZDRkOTAyYzNjOTA5XCIsXCJydHRtXCI6XCIyMDE5LTEyLTA3XCIsXCJzY2hvb2xcIjpcIua1i-ivlVwiLFwic2V4XCI6MSxcInN0YXRlXCI6MSxcInd4dWlkXCI6XCJvM2FTUTVvbnRTVDdkNGx5M01JVV9teFRkVXR3XCJ9IiwiaWQiOiI0ODNjNjdiYTkwYjM0ZjI1Yjc0ZWZmN2Q2M2IzNTAxZiIsImV4cCI6MTU4NjM1NTUyNn0.hj5O6EhMBI1k6MvjiafHS_sEmoCGyEqm3a50zphfhyo";
		
	
	
	
	}

}
