package com.jkoss.study.interview.vo;

import com.jkoss.study.interview.entity.Interviewquestion;

/**
 * 面试题
 * 
 * @Author Jason
 * @Version 1.0, 2019-08-11
 * @See
 * @Since com.jkoss.study.interview.entity
 * @Description: TODO
 */
public class InterviewquestionVo extends Interviewquestion {
	private String iacontent;
	private Integer answertype;

	private String ename;
	private String pname;
	private String sname;

	private String sid;

	public String getSid() {
		return sid;
	}

	public void setSid(String sid) {
		this.sid = sid;
	}

	public String getIacontent() {
		return iacontent;
	}

	public void setIacontent(String iacontent) {
		this.iacontent = iacontent;
	}

	public Integer getAnswertype() {
		return answertype;
	}

	public void setAnswertype(Integer answertype) {
		this.answertype = answertype;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

}
