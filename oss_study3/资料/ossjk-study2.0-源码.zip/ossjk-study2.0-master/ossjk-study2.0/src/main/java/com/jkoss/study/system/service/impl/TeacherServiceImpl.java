package com.jkoss.study.system.service.impl;

import java.util.List;

import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.jkoss.study.system.entity.Teacher;
import com.jkoss.study.system.mapper.TeacherMapper;
import com.jkoss.study.system.service.ITeacherService;


/**
 * 教师 服务实现类
 * 
 * @Author Jason
 * @Version 1.0, 2019-05-27
 * @See
 * @Since com.jkoss.study.system.service.impl
 * @Description: TODO
 */
@Service
public class TeacherServiceImpl extends ServiceImpl<TeacherMapper, Teacher> implements ITeacherService {

	public List<Teacher> selectTeacherOnJob(){
		return baseMapper.selectOnJob();
	}
}
