package com.jkoss.study.interview.service;

import com.jkoss.study.interview.entity.Interviewanswer;
import com.jkoss.study.interview.entity.Interviewquestion;
import com.jkoss.study.interview.vo.InterviewquestionVo;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.IService;

/**
 * 面试题 服务类
 * 
 * @Author Jason
 * @Version 1.0, 2019-08-11
 * @See
 * @Since com.jkoss.study.interview.service
 * @Description: TODO
 */
public interface IInterviewquestionService extends IService<Interviewquestion> {

	boolean insert(Interviewquestion interviewquestion, Interviewanswer interviewanswer) throws Exception;

	boolean update(Interviewquestion interviewquestion, Interviewanswer interviewanswer) throws Exception;

	List selectVoList(Wrapper wrapper);

	Page selectVoPage(Page page, @Param("ew") Wrapper wrapper);

	InterviewquestionVo selectVoById(String id);
}
