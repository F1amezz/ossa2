package com.jkoss.study.config.mvc;

import javax.servlet.MultipartConfigElement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.MultipartConfigFactory;
import org.springframework.boot.web.servlet.ServletListenerRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.unit.DataSize;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.jkoss.study.constant.Constant;
import com.jkoss.study.interceptor.LoginInterceptor;
import com.jkoss.study.interceptor.PCLoginInterceptor;
import com.jkoss.study.listener.InitListener;

/**
 * MVC配置类
 * 
 * @Author chair
 * @Version 1.0, 2017年8月22日
 * @See
 * @Since com.jk.bestbaby.config
 * @Description: TODO
 */
@Configuration
public class MvcConfiguration implements WebMvcConfigurer {
	@Autowired
	private LoginInterceptor loginInterceptor;
	@Autowired
	private PCLoginInterceptor pcLoginInterceptor;

	/**
	 * 多媒体上传
	 * 
	 * @return
	 */
	@Bean
	public MultipartConfigElement multipartConfigElement() {
		MultipartConfigFactory factory = new MultipartConfigFactory();
		factory.setMaxFileSize(DataSize.ofBytes(1024L * 1024L * 1024L));
		return factory.createMultipartConfig();
	}

	/**
	 * 
	 * 自定义映射路径
	 */
	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		// registry.addResourceHandler("/myres/**").addResourceLocations("classpath:/myres/");
		registry.addResourceHandler(Constant.IMAGES_URL + "/**").addResourceLocations("file:" + Constant.IMAGES_PATH);
	}

	/**
	 * 添加拦截器
	 */
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(loginInterceptor).addPathPatterns("/api/daily/*").addPathPatterns("/api/transcript/*")
				.excludePathPatterns("/user/*", "/api/daily/submit");
		registry.addInterceptor(pcLoginInterceptor).addPathPatterns("/pc/api/index/*")
				.addPathPatterns("/pc/api/daily/*").addPathPatterns("/pc/api/transcript/*")
				.excludePathPatterns("/pc/user/*");

	}

	@Bean
	public ServletListenerRegistrationBean listenerRegist(@Autowired InitListener initListener) {
		ServletListenerRegistrationBean srb = new ServletListenerRegistrationBean();
		srb.setListener(initListener);
		return srb;
	}

//	@Bean
//	public CorsFilter corsFilter() {
//		CorsConfiguration config = new CorsConfiguration();
//		config.addAllowedOrigin("*");
//		config.setAllowCredentials(true);
//		config.addAllowedMethod("*");
//		config.addAllowedHeader("*");
//		config.setMaxAge(0L);
//		UrlBasedCorsConfigurationSource configSource = new UrlBasedCorsConfigurationSource();
//		configSource.registerCorsConfiguration("/**", config);
//		return new CorsFilter(configSource);
//	}

}
