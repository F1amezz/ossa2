package com.jkoss.study.interview.vo;

import java.io.Serializable;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.jkoss.study.interview.entity.Interview;

/**
 * 面试表
 * 
 * @Author Jason
 * @Version 1.0, 2019-08-11
 * @See
 * @Since com.jkoss.study.interview.entity
 * @Description: TODO
 */
public class InterviewVo extends Interview {

	private String ename;
	private String pname;
	private String sname;
	private String cname;

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	@Override
	public String toString() {
		return "InterviewVo [ename=" + ename + ", pname=" + pname + ", sname=" + sname + ", cname=" + cname + "]";
	}

}
