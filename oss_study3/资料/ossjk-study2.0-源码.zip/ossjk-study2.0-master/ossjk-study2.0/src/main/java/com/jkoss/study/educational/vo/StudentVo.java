package com.jkoss.study.educational.vo;

import com.jkoss.study.educational.entity.Student;

public class StudentVo extends Student {
	
	private String cname;

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	@Override
	public String toString() {
		return "StudentVo [cname=" + cname + "]";
	}

}
