package com.jkoss.study.exam.controller;

import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.baomidou.mybatisplus.mapper.Condition;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.jkoss.base.controller.BaseController;
import com.jkoss.common.util.CommonUtil;
import com.jkoss.common.vo.DwzPageBean;
import com.jkoss.study.educational.entity.Clazz;
import com.jkoss.study.educational.service.IClazzService;
import com.jkoss.study.exam.entity.Exam;
import com.jkoss.study.exam.service.IAnswerService;
import com.jkoss.study.exam.service.IExamService;
import com.jkoss.study.exam.service.IExampaperService;
import com.jkoss.study.system.entity.Teacher;

/**
 * 前端控制器
 * 
 * @Author Jason
 * @Version 1.0, 2019-06-08
 * @See
 * @Since com.jkoss.study.exam.controller
 * @Description: TODO
 */
@Controller
@RequestMapping("/exam/exam")
public class ExamController extends BaseController {
	@Autowired
	private IClazzService iClazzService;
	@Autowired
	private IExampaperService iExampaperService;
	@Autowired
	private IExamService iExamService;

	@Autowired
	private IAnswerService iAnswerService;

	@RequestMapping("/list")
	@RequiresPermissions("/exam/exam/list")
	public String list(String isFm, String cid, String tid, String expname, String exptype, DwzPageBean dwzPageBean,
			ModelMap map, HttpServletRequest request, HttpServletResponse response, HttpSession session) {

		Wrapper wrapper = Condition.create().isWhere(true);
		sessionEqStored(isFm, "c.id", "cid", cid, session, wrapper);
		Object tidStore = null;
		if (CommonUtil.isBlank(tid) || CommonUtil.isEquals(tid, "0")) {
			tidStore = request.getSession().getAttribute("tid");
		} else {
			request.getSession().setAttribute("tid", tid);
		}

		if ("0".equals(tid)) {
			request.getSession().setAttribute("tid", "0");
		} else {
			if (CommonUtil.isBlank(tid) && tidStore == null) {
				// 自己essionScope.user.name
				Teacher usr = (Teacher) request.getSession().getAttribute("user");
				tid = usr.getId();
				sessionEqStored("1", "e.creator", "tid", tid, request.getSession(), wrapper, true);
			} else if (tidStore != null && (!"0".equals(tidStore))) {
				sessionEqStored(isFm, "e.creator", "tid", tidStore.toString(), request.getSession(), wrapper, true);
			} else {
				if (!CommonUtil.isBlank(tid)) {
					sessionEqStored(isFm, "e.creator", "tid", tid, request.getSession(), wrapper, true);
				}
			}
		}

		if (!CommonUtil.isBlank(dwzPageBean.getOrderField()) && !CommonUtil.isBlank(dwzPageBean.getOrderDirection())) {
			dwzPageBean.getCountResultMap().put("orderField", dwzPageBean.getOrderField());
			dwzPageBean.getCountResultMap().put("orderDirection", dwzPageBean.getOrderDirection());
			wrapper.orderBy(dwzPageBean.getOrderField(), CommonUtil.isEquals(dwzPageBean.getOrderDirection(), "asc"));
		} else {
			// 默认排序字段
			wrapper.orderBy("exp.create_time", false);
		}
		if (!CommonUtil.isBlank(exptype)) {
			wrapper.eq("exp.type", exptype);
			dwzPageBean.getCountResultMap().put("exptype", exptype);
		}
		if (!CommonUtil.isBlank(cid)) {
			dwzPageBean.getCountResultMap().put("cid", cid);
			wrapper.eq("c.id", cid);
		}
		if (!CommonUtil.isBlank(expname)) {
			dwzPageBean.getCountResultMap().put("expname", expname);
			wrapper.like("exp.name", expname);
		}
		wrapper.groupBy("e.id");
		Page resultPage = iExamService.selectVoPage(dwzPageBean.toPage(), wrapper);
		map.put("dwzPageBean", dwzPageBean.toDwzPageBean(resultPage));

		// 班级
		Wrapper wrapper2 = Condition.create();
		List<Clazz> clazzs = iClazzService.selectList(wrapper2);
		map.put("clazzs", clazzs);

		return "exam/exam/list";
	}

	@RequestMapping("/toInsert")
	@RequiresPermissions("/exam/exam/toInsert")
	public String toInsert(ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		// 开班8个月以内的
		map.put("clazz", iClazzService.selectClazzes10MthAgo());
		Wrapper wrapper = Condition.create().eq("type", "1");
		map.put("exampaper", iExampaperService.selectList(wrapper));
		return "exam/exam/edit";
	}

	@RequestMapping("/insert")
	@RequiresPermissions("/exam/exam/toInsert")
	@ResponseBody
	public Object insert(@Valid Exam exam, HttpServletRequest request, HttpServletResponse response) {
		// 获取当前时间 格式为 yyyy-MM-dd HH:mm:ss.SSS
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.HOUR_OF_DAY, 23);
		cal.set(Calendar.MINUTE, 59);
		cal.set(Calendar.SECOND, 59);
		Wrapper wrapper = Condition.create();
		wrapper.eq("cid", exam.getCid());
		wrapper.between("start_time", CommonUtil.date(), CommonUtil.getDate(cal.getTime(), "yyyy-MM-dd HH:mm:ss"))
				.orderBy("create_time", true);
		Exam e = iExamService.selectOne(wrapper);
		if (!CommonUtil.isBlank(e)) {
			return ajaxError("该班今天已安排考试");
		}
		// 处理结束时间
		String starr[] = exam.getStartTime().split(" ");
		exam.setEndTime(starr[0] + " " + exam.getEndTime());

		if (iExamService.insert(exam)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}

	}

	@RequestMapping("/show")
	public String show(DwzPageBean dwzPageBean, String eid, HttpServletRequest request, HttpServletResponse response,
			HttpSession session, ModelMap map) {

		Wrapper wrapper = Condition.create();

		// session.setAttribute("cid", cid);

		wrapper.isWhere(true).eq("a.eid", eid).orderBy("create_time", false);
		map.put("eid", eid);
		Page page = dwzPageBean.toPage();
		page.setSize(100);
		Page resultPage = iAnswerService.selectVoPage(page, wrapper);
		map.put("dwzPageBean", dwzPageBean.toDwzPageBean(resultPage));
		// 班级
		Wrapper wrapper2 = Condition.create();
		List<Clazz> clazzs = iClazzService.selectList(wrapper2);
		map.put("clazzs", clazzs);

		return "exam/answer/list";

	}

	@RequestMapping("/toUpdate")
	@RequiresPermissions("/exam/exam/toUpdate")
	public String toUpdate(String id, ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		map.put("record", iExamService.selectById(id));
		map.put("clazz", iClazzService.selectList(null));
		map.put("exptype", iExampaperService.selectById(iExamService.selectById(id).getExpid()));
		Wrapper wrapper = Condition.create().eq("type",
				iExampaperService.selectById(iExamService.selectById(id).getExpid()).getType());
		map.put("exampaper", iExampaperService.selectList(wrapper));
		return "exam/exam/edit";
	}

	@RequestMapping("/update")
	@RequiresPermissions("/exam/exam/toUpdate")
	@ResponseBody
	public Object update(@Valid Exam exam, HttpServletRequest request, HttpServletResponse response) {
		if (iExamService.updateById(exam)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/delete")
	@RequiresPermissions("/exam/exam/delete")
	@ResponseBody
	public Object delete(String[] id, HttpServletRequest request, HttpServletResponse response) {
		if (iExamService.deleteBatchIds(Arrays.asList(id))) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/changeType")
	@RequiresPermissions("/exam/exam/list")
	@ResponseBody
	public Object changeType(String type, ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		Wrapper wrapper = Condition.create().eq("type", type);
		return iExampaperService.selectList(wrapper);
	}

}
