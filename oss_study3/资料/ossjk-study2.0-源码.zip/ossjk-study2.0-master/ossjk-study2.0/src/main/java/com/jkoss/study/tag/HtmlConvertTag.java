package com.jkoss.study.tag;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.jsp.JspContext;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.tagext.BodyTagSupport;
import javax.servlet.jsp.tagext.SimpleTagSupport;

/**
 * 处理js html文本
 * 
 * @Author chair
 * @Version 1.0, 2019-06-11
 * @See
 * @Since com.jkoss.study.learn.controller
 * @Description: TODO
 */
public class HtmlConvertTag extends BodyTagSupport {
	@Override
	public int doEndTag() throws JspException {
		BodyContent bodyContent = getBodyContent();
		try {
//			System.out.println(bodyContent.getString());
			String result = bodyContent.getString()
					.replaceAll("\\\\", "\\\\\\\\")
					.replaceAll("'", "\\\\'")
					.replaceAll("\"", "\\\\\"")
//					.replaceAll("\\\\n", "\\\\\\\\n")
//					.replaceAll("\\\\r", "\\\\\\\\r")
					.replaceAll("<", "&lt;")
					.replaceAll(">", "&gt;");

//			System.out.println(result);
			getBodyContent().getEnclosingWriter().write(result);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return EVAL_PAGE;
	}

}
