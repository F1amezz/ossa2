package com.jkoss.study.exam.service;

import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.jkoss.study.exam.entity.Point;
import com.jkoss.study.exam.vo.PointVo;

/**
 * ֪ʶ�� 服务类
 * 
 * @Author Jason
 * @Version 1.0, 2019-06-10
 * @See
 * @Since com.jkoss.study.exam.service
 * @Description: TODO
 */
public interface IPointService extends IService<Point> {
	List<PointVo> selectAllLevelByPid(Wrapper wrapper);
}
