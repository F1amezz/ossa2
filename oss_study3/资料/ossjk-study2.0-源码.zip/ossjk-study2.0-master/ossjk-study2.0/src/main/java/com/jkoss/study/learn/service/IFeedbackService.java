package com.jkoss.study.learn.service;

import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.IService;
import com.jkoss.study.learn.entity.Feedback;

/**
 * 反馈表 服务类
 * 
 * @Author chair
 * @Version 1.0, 2019-06-13
 * @See
 * @Since com.jkoss.study.learn.service
 * @Description: TODO
 */
public interface IFeedbackService extends IService<Feedback> {

	Page selectVoPage(Page page, Wrapper wrapper);

	List selectVo(Wrapper eq);

}
