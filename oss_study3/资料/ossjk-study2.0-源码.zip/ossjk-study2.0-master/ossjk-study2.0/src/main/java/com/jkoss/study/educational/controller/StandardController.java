package com.jkoss.study.educational.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.baomidou.mybatisplus.mapper.Condition;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.jkoss.base.controller.BaseController;
import com.jkoss.common.util.CommonUtil;
import com.jkoss.common.vo.DwzPageBean;
import com.jkoss.study.educational.entity.Standard;
import com.jkoss.study.educational.entity.Standarditem;
import com.jkoss.study.educational.service.IStandardService;
import com.jkoss.study.educational.service.IStandarditemService;
import com.jkoss.study.educational.vo.StandardVo;

/**
 * 老师考评题; InnoDB free: 11264 kB 前端控制器
 * 
 * @Author wuyu
 * @Version 1.0, 2019-06-05
 * @See
 * @Since com.jkoss.study.educational.controller
 * @Description: TODO
 */
@Controller
@RequestMapping("/educational/standard")
public class StandardController extends BaseController {

	@Autowired
	private IStandardService iStandardService;
	@Autowired
	private IStandarditemService iStandarditemService;

	@RequestMapping("/list")
	@RequiresPermissions("/educational/standard/list")
	public String list(String title, DwzPageBean dwzPageBean, ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		Wrapper wrapper = Condition.create().isWhere(true);
		if (!CommonUtil.isBlank(title)) {
			wrapper.like("title", title);
			dwzPageBean.getCountResultMap().put("title", title);
		}
		if (!CommonUtil.isBlank(dwzPageBean.getOrderField()) && !CommonUtil.isBlank(dwzPageBean.getOrderDirection())) {
			wrapper.orderBy(dwzPageBean.getOrderField(), CommonUtil.isEquals(dwzPageBean.getOrderDirection(), "asc"));
		} else {
			// 默认排序字段
			wrapper.orderBy("create_time", false);
		}
		Page resultPage = iStandardService.selectPage(dwzPageBean.toPage(), wrapper);
		map.put("dwzPageBean", dwzPageBean.toDwzPageBean(resultPage));
		return "educational/standard/list";
	}

	@RequestMapping("/toInsert")
	@RequiresPermissions("/educational/standard/toInsert")
	public String toInsert(HttpServletRequest request, HttpServletResponse response) {
		return "educational/standard/edit";
	}

	@RequestMapping("/insert")
	@RequiresPermissions("/educational/standard/toInsert")
	@ResponseBody
	public Object insert(@Valid StandardVo standardVo,  HttpServletRequest request, HttpServletResponse response) {
		// 默认禁用
		standardVo.setState(2);
		if (iStandardService.insertStandardVo(standardVo)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/toUpdate")
	@RequiresPermissions("/educational/standard/toUpdate")
	public String toUpdate(String id, ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		// 搜索题目
		map.put("record", iStandardService.selectById(id));
		map.put("items", iStandarditemService.selectList(Condition.create().eq("sid", id).orderBy("inde", true)));
		return "educational/standard/edit";
	}

	@RequestMapping("/update")
	@RequiresPermissions("/educational/standard/toUpdate")
	@ResponseBody
	public Object update(@Valid StandardVo standardVo, HttpServletRequest request, HttpServletResponse response) {
		if (iStandardService.updateStandardVoById(standardVo)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/delete")
	@RequiresPermissions("/educational/standard/delete")
	@ResponseBody
	public Object delete(String[] id, HttpServletRequest request, HttpServletResponse response) {
		if (iStandardService.deleteStandardVoById(Arrays.asList(id))) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/updateState")
	@RequiresPermissions("/educational/standard/updateState")
	@ResponseBody
	public Object updateState(String id, Integer state, ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		Standard entity = new Standard();
		entity.setState(state);
		Wrapper wrapper = Condition.create().eq("id", id);
		if (iStandardService.update(entity, wrapper)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

}
