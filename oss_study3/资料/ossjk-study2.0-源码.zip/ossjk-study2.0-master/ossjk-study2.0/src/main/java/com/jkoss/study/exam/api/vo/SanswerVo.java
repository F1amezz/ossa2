package com.jkoss.study.exam.api.vo;

import java.util.List;

public class SanswerVo {
	
	
	private String type;
	private List<String> sanswer;
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public List<String> getSanswer() {
		return sanswer;
	}
	public void setSanswer(List<String> sanswer) {
		this.sanswer = sanswer;
	}
	
  
}
