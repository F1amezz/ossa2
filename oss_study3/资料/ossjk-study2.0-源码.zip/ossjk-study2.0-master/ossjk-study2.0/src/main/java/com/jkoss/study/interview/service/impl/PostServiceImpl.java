package com.jkoss.study.interview.service.impl;

import com.jkoss.study.interview.entity.Post;
import com.jkoss.study.interview.mapper.PostMapper;
import com.jkoss.study.interview.service.IPostService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;


/**
 * 岗位 服务实现类
 * 
 * @Author chair
 * @Version 1.0, 2019-06-24
 * @See
 * @Since com.jkoss.study.interview.service.impl
 * @Description: TODO
 */
@Service
public class PostServiceImpl extends ServiceImpl<PostMapper, Post> implements IPostService {

}
