package com.jkoss.study.exam.api.pc;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.mapper.Condition;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.jkoss.base.controller.BaseController;
import com.jkoss.common.util.CommonUtil;
import com.jkoss.common.util.JwtTokenUtil;
import com.jkoss.study.educational.entity.Student;
import com.jkoss.study.educational.service.IStudentService;
import com.jkoss.study.exam.api.vo.AnswerVo;
import com.jkoss.study.exam.api.vo.ExamVo;
import com.jkoss.study.exam.api.vo.Sanswer;
import com.jkoss.study.exam.api.vo.SanswerVo;
import com.jkoss.study.exam.entity.Answer;
import com.jkoss.study.exam.entity.Exam;
import com.jkoss.study.exam.entity.Exampaper;
import com.jkoss.study.exam.entity.Question;
import com.jkoss.study.exam.service.IAnswerService;
import com.jkoss.study.exam.service.IExamService;
import com.jkoss.study.exam.service.IExampaperService;
import com.jkoss.study.exam.service.IPointService;
import com.jkoss.study.exam.service.IQuestionService;
import com.jkoss.study.exam.vo.PaperVo;
import com.jkoss.study.exam.vo.PaperVo.Content;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

/**
 * 日常考试API
 * 
 * @author SIMOBAI
 * 
 *
 */
@Api(tags = "PC端首页")
@RestController
@RequestMapping("/pc/api/index")
public class IndexPcController extends BaseController {
	@Autowired
	private IExamService iExamService;
	@Autowired
	private IAnswerService iAnswerService;
	@Autowired
	private IStudentService iStudentService;

	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	/**
	 * @return 获取试卷API
	 */
	@ApiOperation("获取总考试次数、参加考试次数API")
	@GetMapping("/getCount")
	@ResponseBody
	public Object getCount(@ApiIgnore HttpServletRequest request) {
		String studentid = jwtTokenUtil.getUserId(jwtTokenUtil.getPCToken(request));
		Student student = iStudentService.selectById(studentid);
		// 查询总考试次数
		Wrapper wrapper = Condition.create();
		wrapper.eq("cid", student.getClzid());
		int examCount = iExamService.selectCount(wrapper);
		// 查询参加考试次数
		Wrapper wrapper2 = Condition.create();
		wrapper2.eq("sid", student.getId());
		wrapper2.eq("cid", student.getClzid());
		int answerCount = iAnswerService.selectCount(wrapper2);

		Map map = new HashMap();
		map.put("examCount", examCount);// 总考试次数
		map.put("answerCount", answerCount);// 参加考试次数
		return ajaxSuccess(map);
	}

}
