package com.jkoss.study.interview.service.impl;

import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.mapper.SqlHelper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.jkoss.study.interview.entity.Interview;
import com.jkoss.study.interview.mapper.InterviewMapper;
import com.jkoss.study.interview.service.IInterviewService;

/**
 * 面试表 服务实现类
 * 
 * @Author Jason
 * @Version 1.0, 2019-08-11
 * @See
 * @Since com.jkoss.study.interview.service.impl
 * @Description: TODO
 */
@Service
public class InterviewServiceImpl extends ServiceImpl<InterviewMapper, Interview> implements IInterviewService {

	@Override
	public Page selectVoPage(Page page, Wrapper wrapper) {
		// 把分页信息填充到条件
		SqlHelper.fillWrapper(page, wrapper);
		page.setRecords(baseMapper.selectVoPage(page, wrapper));
		return page;
	}

}
