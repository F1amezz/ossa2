package com.jkoss.study.educational.service;

import com.jkoss.study.educational.entity.Standard;
import com.jkoss.study.educational.entity.Standarditem;
import com.jkoss.study.educational.vo.StandardVo;

import java.util.List;

import javax.validation.Valid;

import org.apache.ibatis.annotations.Param;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.IService;

/**
 * 老师考评题; InnoDB free: 11264 kB 服务类
 * 
 * @Author wuyu
 * @Version 1.0, 2019-06-05
 * @See
 * @Since com.jkoss.study.educational.service
 * @Description: TODO
 */
public interface IStandardService extends IService<Standard> {
	boolean insertStandardVo(StandardVo standardVo);

	boolean updateStandardVoById(StandardVo standardVo);

	boolean deleteStandardVoById(List<String> id);
}
