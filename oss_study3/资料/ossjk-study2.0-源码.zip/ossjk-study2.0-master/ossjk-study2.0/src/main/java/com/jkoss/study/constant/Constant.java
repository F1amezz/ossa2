package com.jkoss.study.constant;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * 常量类
 * 
 * @Author Chair
 * @Version 1.0, 2018年9月23日
 * @See
 * @Since com.jkoss.common.util
 * @Description: TODO
 */
@Component
public class Constant {

	public static final String APPLICATION_BASEPATH_KEY = "basepath";

	public static final String APPLICATION_WXAPPID_KEY = "wxappid";

	public static final String APPLICATION_WXSECRET_KEY = "wxsecret";

	public static final String STUDENT_ROLE_ID = "6c5edf450a484c7ebfd54e591d765b5f";

	public static final String SESSION_USER_KEY = "user";

	public static final String SESSION_USERID_KEY = "userid";

	public static final String SESSION_MENU_KEY = "menu";

	public static final String SESSION_URLS_KEY = "urls";

	public static final String SESSION_URLS_JSON = "urlsjson";

	public static final String SESSION_USERROLE_KEY = "role";

	public static final String DWZRESULT_STATUSCODE_SUCCESS = "200";

	public static final String DWZRESULT_STATUSCODE_ERROR = "300";

	public static final String DWZRESULT_STATUSCODE_TIMEOUT = "301";

	public static final String DWZRESULT_MESSAGE_SUCCESS = "操作成功";

	public static final String DWZRESULT_MESSAGE_ERROR = "操作失败";

	public static final String DWZRESULT_MESSAGE_TIMEOUT = "超时";

	public static final String DWZRESULT_CALLBACKTYPE_CLOSECURRENT = "closeCurrent";

	public static final String DWZRESULT_CALLBACKTYPE_FORWARD = "forward";
	/**
	 * token请求token
	 */
	public static final String REQUEST_TOKEN_HEADER = "userid";
	/**
	 * token请求token
	 */
	public static final String REQUEST_PC_TOKEN_HEADER = "token";
	/**
	 * 成功返回码
	 */
	public static final int RESULT_CODE_SUCCESS = 1000;
	/**
	 * 请求失败返回码
	 */
	public static final int RESULT_CODE_FAIL = 1001;
	/**
	 * 请求抛出异常返回码
	 */
	public static final int RESULT_CODE_EXCEPTION = 1002;
	/**
	 * 未登陆状态返回码
	 */
	public static final int RESULT_CODE_NOLOGIN = 1003;
	/**
	 * 无操作权限返回码
	 */
	public static final int RESULT_CODE_NOAUTH = 1004;
	/**
	 * userid可能在别的地方登录
	 */
	public static final int RESULT_CODE_USERID = 1005;
	/**
	 * noToken
	 */
	public static final int RESULT_CODE_NOTOKEN = 1006;
	/**
	 * refreshToekn
	 */
	public static final int RESULT_CODE_REFRESHTOEKN = 1007;
	/**
	 * tokenTimeOut
	 */
	public static final int RESULT_CODE_TOKENTIMEOUT = 1008;
	/**
	 * otherlogin
	 */
	public static final int RESULT_CODE_OTHERLOGIN = 1009;
	/**
	 * noToken
	 */
	public static final String RESULT_MSG_NOTOKEN = "noToken";
	/**
	 * refreshToekn
	 */
	public static final String RESULT_MSG_REFRESHTOEKN = "refreshToekn";
	/**
	 * tokenTimeOut
	 */
	public static final String RESULT_MSG_TOKENTIMEOUT = "tokenTimeOut";
	/**
	 * otherlogin
	 */
	public static final String RESULT_MSG_OTHERLOGIN = "otherlogin";
	/**
	 * 成功返回信息
	 */
	public static final String RESULT_MSG_SUCCESS = "操作成功";
	/**
	 * 成功返回信息
	 */
	public static final String RESULT_MSG_FAIL = "操作失败";
	/**
	 * 请求抛出异常返回信息
	 */
	public static final String RESULT_MSG_EXCEPTION = "请求报错！";
	/**
	 * 未登陆状态返回信息
	 */
	public static final String RESULT_MSG_NOLOGIN = "no login!";
	/**
	 * 无操作权限返回信息
	 */
	public static final String RESULT_MSG_NOAUTH = "no auth!";
	/**
	 * Token可能在别的地方登录
	 */
	public static final String RESULT_MSG_USERID = "Userid可能在别的地方登录!";

	public static String IMAGES_PATH;

	public static String IMAGES_URL;

	public static String getIMAGES_PATH() {
		return IMAGES_PATH;
	}

	@Value("${app.images-path}")
	public void setIMAGES_PATH(String iMAGES_PATH) {
		IMAGES_PATH = iMAGES_PATH;
	}

	public static String getIMAGES_URL() {
		return IMAGES_URL;
	}

	@Value("${app.images-url}")
	public void setIMAGES_URL(String iMAGES_URL) {
		IMAGES_URL = iMAGES_URL;
	}

}
