package com.jkoss.study.interview.service.impl;

import com.jkoss.study.interview.entity.Enterprise;
import com.jkoss.study.interview.mapper.EnterpriseMapper;
import com.jkoss.study.interview.service.IEnterpriseService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;


/**
 * 企业表 服务实现类
 * 
 * @Author chair
 * @Version 1.0, 2019-06-20
 * @See
 * @Since com.jkoss.study.interview.service.impl
 * @Description: TODO
 */
@Service
public class EnterpriseServiceImpl extends ServiceImpl<EnterpriseMapper, Enterprise> implements IEnterpriseService {

}
