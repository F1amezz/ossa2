package com.jkoss.study.educational.service.impl;

import com.jkoss.study.educational.entity.Course;
import com.jkoss.study.educational.mapper.CourseMapper;
import com.jkoss.study.educational.service.ICourseService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;


/**
 * 课程 服务实现类
 * 
 * @Author chair
 * @Version 1.0, 2019-06-04
 * @See
 * @Since com.jkoss.study.educational.service.impl
 * @Description: TODO
 */
@Service
public class CourseServiceImpl extends ServiceImpl<CourseMapper, Course> implements ICourseService {

}
