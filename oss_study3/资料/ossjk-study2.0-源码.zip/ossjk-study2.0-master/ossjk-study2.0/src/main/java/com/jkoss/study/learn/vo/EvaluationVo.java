package com.jkoss.study.learn.vo;

import java.io.Serializable;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.jkoss.base.entity.BaseEntity;
import com.jkoss.study.learn.entity.Evaluation;

/**
 * 总结
 * 
 * @Author chair
 * @Version 1.0, 2019-06-11
 * @See
 * @Since com.jkoss.study.learn.vo
 * @Description: TODO
 */
public class EvaluationVo extends Evaluation {
	private String sname;
	private String cname;
	private String tname;
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getTname() {
		return tname;
	}
	public void setTname(String tname) {
		this.tname = tname;
	}
	@Override
	public String toString() {
		return "EvaluationVo [sname=" + sname + ", cname=" + cname + ", tname=" + tname + "]";
	}

	 
}
