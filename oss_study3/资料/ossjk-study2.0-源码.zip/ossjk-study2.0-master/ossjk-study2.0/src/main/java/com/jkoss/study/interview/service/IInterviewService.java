package com.jkoss.study.interview.service;

import com.jkoss.study.interview.entity.Interview;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.IService;

/**
 * 面试表 服务类
 * 
 * @Author Jason
 * @Version 1.0, 2019-08-11
 * @See
 * @Since com.jkoss.study.interview.service
 * @Description: TODO
 */
public interface IInterviewService extends IService<Interview> {

	Page selectVoPage(Page page, Wrapper wrapper) throws Exception;
}
