package com.jkoss.study.exam.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.mapper.Condition;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.jkoss.base.controller.BaseController;
import com.jkoss.common.util.CommonUtil;
import com.jkoss.common.vo.DwzPageBean;
import com.jkoss.common.vo.ZtreeBean;
import com.jkoss.study.exam.entity.Point;
import com.jkoss.study.exam.service.IPointService;

/**
 * ֪ʶ�� 前端控制器
 * 
 * @Author Jason
 * @Version 1.0, 2019-06-10
 * @See
 * @Since com.jkoss.study.exam.controller
 * @Description: TODO
 */
@Controller
@RequestMapping("/exam/point")
public class PointController extends BaseController {

	@Autowired
	private IPointService iPointService;

	@RequestMapping("/list")
	@RequiresPermissions("/exam/point/list")
	public String list(DwzPageBean dwzPageBean, ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		// 构建排序条件
		Wrapper wrapper = Condition.create().orderBy("pid", true).orderBy("sort", true);
		List<Point> points = iPointService.selectList(wrapper);
		// 把查询回来的实体转成ZtreeBean
		if (!CommonUtil.isBlank(points)) {
			List<ZtreeBean> ztreeBeans = new ArrayList();
			for (Point point : points) {
				ZtreeBean ztreeBean = new ZtreeBean();
				ztreeBean.setId(point.getId() + "");
				ztreeBean.setIsParent(CommonUtil.isBlank(point.getPid()));
				ztreeBean.setName(point.getName());
				ztreeBean.setPId(point.getPid());
				ztreeBean.setOpen(true);
				ztreeBeans.add(ztreeBean);
			}
			map.put("ztreeBeans", JSON.toJSONString(ztreeBeans));
		} else {
			map.put("ztreeBeans", "[]");
		}

		return "exam/point/list";
	}

	@RequestMapping("/toInsert")
	@RequiresPermissions("/exam/point/toInsert")
	public String toInsert(String pid, ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		map.put("parent", iPointService.selectById(pid));
		return "exam/point/edit";
	}

	@RequestMapping("/insert")
	@RequiresPermissions("/exam/point/toInsert")
	@ResponseBody
	public Object insert(Point point, HttpServletRequest request, HttpServletResponse response) {
		if (iPointService.insert(point)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}

	}

	@RequestMapping("/toUpdate")
	@RequiresPermissions("/exam/point/toUpdate")
	public String toUpdate(String id, ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		// 查询知识点
		Point point = iPointService.selectById(id);
		map.put("record", point);
		map.put("parent", iPointService.selectById(point.getPid()));
		map.put("record", iPointService.selectById(id));
		return "exam/point/edit";
	}

	@RequestMapping("/update")
	@RequiresPermissions("/exam/point/toUpdate")
	@ResponseBody
	public Object update(Point point, HttpServletRequest request, HttpServletResponse response) {
		if (iPointService.updateById(point)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/delete")
	@RequiresPermissions("/exam/point/delete")
	@ResponseBody
	public Object delete(String[] id, HttpServletRequest request, HttpServletResponse response) {
		List<Point> list = new ArrayList<Point>();
		// 查询所有子集数据
		for (String string : id) {
			Point point = iPointService.selectById(string);
			if (!CommonUtil.isBlank(point)) {
				list.add(point);
			}
			list = getAllPoint(list, string);
		}
		// 修改为删除数据
		List dellist = new ArrayList();
		for (Point point : list) {
			dellist.add(point.getId());
		}
		if (iPointService.deleteBatchIds(dellist)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	// 递归获取所有子级节点
	public List getAllPoint(List<Point> list, String id) {
		Wrapper wrapper = Condition.create().eq("pid", id);
		List<Point> points = iPointService.selectList(wrapper);
		if (!CommonUtil.isBlank(points)) {
			list.addAll(points);
		}
		for (Point point : points) {
			getAllPoint(list, point.getId());
		}
		return list;
	}
}
