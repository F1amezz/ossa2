package com.jkoss.study.educational.mapper;

import com.jkoss.study.educational.entity.TeacherClazz;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * 教师班级中间表 Mapper 接口
 * 
 * @Author chair
 * @Version 1.0, 2019-06-10
 * @See
 * @Since com.jkoss.study.educational.mapper
 * @Description: TODO
 */
public interface TeacherClazzMapper extends BaseMapper<TeacherClazz> {

	int updateStateByCid(@Param("state") int state, @Param("cid") String cid);

	List selectVoByCid(@Param("cid") String cid);

}
