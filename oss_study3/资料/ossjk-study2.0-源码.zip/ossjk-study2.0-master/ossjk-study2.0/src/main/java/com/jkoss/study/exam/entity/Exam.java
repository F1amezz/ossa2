package com.jkoss.study.exam.entity;

import java.io.Serializable;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.jkoss.base.entity.BaseEntity;

/**
 * 
 * 
 * @Author Jason
 * @Version 1.0, 2019-06-08
 * @See
 * @Since com.jkoss.study.exam.entity
 * @Description: TODO
 */
public class Exam extends BaseEntity<Exam> {

	private static final long serialVersionUID = 1L;

	/**
	 * id
	 */
	@TableId("id")
	private String id;	
	@TableField("name")
	private String name;
	@TableField("cid")
	private String cid;
	@TableField("expid")
	private String expid;
	@TableField("start_time")
	private String startTime;
	@TableField("end_time")
	private String endTime;
	@TableField("stucnt")
	private Long stucnt;
	



	public Long getStucnt() {
		return stucnt;
	}

	public void setStucnt(Long stucnt) {
		this.stucnt = stucnt;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCid() {
		return cid;
	}

	public void setCid(String cid) {
		this.cid = cid;
	}

	public String getExpid() {
		return expid;
	}

	public void setExpid(String expid) {
		this.expid = expid;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(String modifyTime) {
		this.modifyTime = modifyTime;
	}

	public String getModifier() {
		return modifier;
	}

	public void setModifier(String modifier) {
		this.modifier = modifier;
	}

	@Override
	protected Serializable pkVal() {
		return this.id;
	}

	@Override
	public String toString() {
		return "Exam{" + ", id=" + id + ", cid=" + cid + ", expid=" + expid + ", startTime=" + startTime + ", endTime=" + endTime + ", createTime=" + createTime + ", creator=" + creator + ", modifyTime=" + modifyTime + ", modifier=" + modifier + "}";
	}
}
