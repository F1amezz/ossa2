package com.jkoss.study.learn.service.impl;

import com.jkoss.study.learn.entity.Feedback;
import com.jkoss.study.learn.mapper.FeedbackMapper;
import com.jkoss.study.learn.service.IFeedbackService;
import com.baomidou.mybatisplus.mapper.SqlHelper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;

import java.util.List;

import org.springframework.stereotype.Service;

/**
 * 反馈表 服务实现类
 * 
 * @Author chair
 * @Version 1.0, 2019-06-13
 * @See
 * @Since com.jkoss.study.learn.service.impl
 * @Description: TODO
 */
@Service
public class FeedbackServiceImpl extends ServiceImpl<FeedbackMapper, Feedback> implements IFeedbackService {

	@Override
	public Page selectVoPage(Page page, Wrapper wrapper) {
		// 把分页信息填充到条件
		SqlHelper.fillWrapper(page, wrapper);
		page.setRecords(baseMapper.selectVoPage(page, wrapper));
		return page;

	}

	@Override
	public List selectVo(Wrapper wrapper) {
		return baseMapper.selectVo(wrapper);
	}
}
