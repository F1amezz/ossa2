package com.jkoss.study.exam.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.jkoss.study.exam.entity.Point;
import com.jkoss.study.exam.vo.PointVo;

/**
 * ֪ʶ�� Mapper 接口
 * 
 * @Author Jason
 * @Version 1.0, 2019-06-10
 * @See
 * @Since com.jkoss.study.exam.mapper
 * @Description: TODO
 */
public interface PointMapper extends BaseMapper<Point> {
	List<PointVo> selectAllLevelByPid(@Param("ew") Wrapper wrapper);
}
