package com.jkoss.study.educational.service;

import com.jkoss.study.educational.entity.Course;
import com.baomidou.mybatisplus.service.IService;

/**
 * 课程 服务类
 * 
 * @Author chair
 * @Version 1.0, 2019-06-04
 * @See
 * @Since com.jkoss.study.educational.service
 * @Description: TODO
 */
public interface ICourseService extends IService<Course> {

}
