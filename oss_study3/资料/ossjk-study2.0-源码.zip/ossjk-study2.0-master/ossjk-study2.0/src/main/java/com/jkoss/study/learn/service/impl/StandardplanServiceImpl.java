package com.jkoss.study.learn.service.impl;

import com.jkoss.study.learn.entity.Standardplan;
import com.jkoss.study.learn.mapper.StandardplanMapper;
import com.jkoss.study.learn.service.IStandardplanService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;


/**
 * 考评计划 服务实现类
 * 
 * @Author chair
 * @Version 1.0, 2019-06-13
 * @See
 * @Since com.jkoss.study.learn.service.impl
 * @Description: TODO
 */
@Service
public class StandardplanServiceImpl extends ServiceImpl<StandardplanMapper, Standardplan> implements IStandardplanService {

	@Override
	public String selectMaxPlantDate() {
		 
		return baseMapper.selectMaxPlantDate();
	}

}
