package com.jkoss.study.learn.controller;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.baomidou.mybatisplus.mapper.Condition;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.jkoss.base.controller.BaseController;
import com.jkoss.common.util.CommonMethod;
import com.jkoss.common.util.CommonUtil;
import com.jkoss.common.vo.DwzPageBean;
import com.jkoss.study.constant.Constant;
import com.jkoss.study.educational.entity.Clazz;
import com.jkoss.study.educational.entity.Course;
import com.jkoss.study.educational.entity.Standard;
import com.jkoss.study.educational.entity.Standarditem;
import com.jkoss.study.educational.entity.Student;
import com.jkoss.study.educational.entity.TeacherClazz;
import com.jkoss.study.educational.service.IClazzService;
import com.jkoss.study.educational.service.ICourseService;
import com.jkoss.study.educational.service.IStandardService;
import com.jkoss.study.educational.service.IStandarditemService;
import com.jkoss.study.educational.service.IStudentService;
import com.jkoss.study.educational.service.ITeacherClazzService;
import com.jkoss.study.learn.entity.Evaluation;
import com.jkoss.study.learn.entity.Feedback;
import com.jkoss.study.learn.entity.Standardplan;
import com.jkoss.study.learn.service.IFeedbackService;
import com.jkoss.study.learn.service.IStandardplanService;
import com.jkoss.study.learn.vo.EvaluationVo;
import com.jkoss.study.learn.vo.FeedbackVo;

/**
 * 反馈表 前端控制器
 * 
 * @Author chair
 * @Version 1.0, 2019-06-13
 * @See
 * @Since com.jkoss.study.learn.controller
 * @Description: TODO
 */
@Controller
@RequestMapping("/learn/feedback")
public class FeedbackController extends BaseController {

	@Autowired
	private IFeedbackService iFeedbackService;
	@Autowired
	private IClazzService iClazzService;
	@Autowired
	private ICourseService iCourseService;
	@Autowired
	private IStandardplanService iStandardplanService;
	@Autowired
	private IStandardService iStandardService;
	@Autowired
	private IStandarditemService iStandarditemService;
	@Autowired
	private ITeacherClazzService iTeacherClazzService;
	@Autowired
	private IStudentService iStudentService;

	@RequestMapping("/list")
	@RequiresPermissions("/learn/feedback/list")
	public String list(String sname, String isFm, String cid, String writedate, String isread, DwzPageBean dwzPageBean,
			ModelMap map, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		Wrapper wrapper = Condition.create();

		sessionLikeStored(isFm, "s.name", "sname", sname, session, wrapper);
		sessionEqStored(isFm, "f.cid", "cid", cid, session, wrapper);
		sessionEqStored(isFm, "f.writedate", "writedate", writedate, session, wrapper);
		sessionEqStored(isFm, "f.isread", "isread", isread, session, wrapper);

		if (isStudent()) {
			// 学生
			// 新增的拿到学生信息
			String sid = (String) session.getAttribute(Constant.SESSION_USERID_KEY);
			// 学生只能查找自己的
			wrapper.isWhere(true);
			wrapper.eq("f.sid", sid);
		}
		if (!CommonUtil.isBlank(dwzPageBean.getOrderField()) && !CommonUtil.isBlank(dwzPageBean.getOrderDirection())) {
			wrapper.orderBy(dwzPageBean.getOrderField(), CommonUtil.isEquals(dwzPageBean.getOrderDirection(), "asc"));
		} else {
			// 默认排序字段
			wrapper.orderBy("create_time", false);
		}
		Page resultPage = iFeedbackService.selectVoPage(dwzPageBean.toPage(), wrapper);
		map.put("dwzPageBean", dwzPageBean.toDwzPageBean(resultPage));
		// 查询所有班级
		map.put("clazzs", iClazzService.selectList(null));
		return "learn/feedback/list";
	}

	@RequestMapping("/toInsert")
	@RequiresPermissions("/learn/feedback/toInsert")
	public String toInsert(ModelMap map, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) {
		// 拿到登录的学生
		Student student = (Student) session.getAttribute(Constant.SESSION_USER_KEY);
		// 查询班级类型
		Clazz clazz = iClazzService.selectById(student.getClzid());
		// 课程id
		// 拿到课程一级
		// 查询二级菜单
		Wrapper wrapper = Condition.create().eq("pid", clazz.getCid()).orderBy("sort", true);
		map.put("chapters", iCourseService.selectList(wrapper));
		// 查找当天反馈计划
		// 状态 1-启用、2停用
		Wrapper wrapper2 = Condition.create().eq("plantdate", CommonUtil.date()).eq("state", "1");
		Standardplan standardplan = iStandardplanService.selectOne(wrapper2);

		Map standardMap = new LinkedHashMap();
		// 查询反馈问题
		Standard standard1 = iStandardService.selectById(standardplan.getQuest1());
		// 通过问题id查找到问题子项
		Wrapper tmp = Condition.create().eq("sid", standard1.getId()).orderBy("inde", true);
		List<Standarditem> standarditems1 = iStandarditemService.selectList(tmp);
		standardMap.put(standard1, standarditems1);

		Standard standard2 = iStandardService.selectById(standardplan.getQuest2());
		tmp = Condition.create().eq("sid", standard2.getId()).orderBy("inde", true);
		List<Standarditem> standarditems2 = iStandarditemService.selectList(tmp);
		standardMap.put(standard2, standarditems2);

		Standard standard3 = iStandardService.selectById(standardplan.getQuest3());
		tmp = Condition.create().eq("sid", standard3.getId()).orderBy("inde", true);
		List<Standarditem> standarditems3 = iStandarditemService.selectList(tmp);
		standardMap.put(standard3, standarditems3);

		Standard standard4 = iStandardService.selectById(standardplan.getQuest4());
		tmp = Condition.create().eq("sid", standard4.getId()).orderBy("inde", true);
		List<Standarditem> standarditems4 = iStandarditemService.selectList(tmp);
		standardMap.put(standard4, standarditems4);

		Standard standard5 = iStandardService.selectById(standardplan.getQuest5());
		tmp = Condition.create().eq("sid", standard5.getId()).orderBy("inde", true);
		List<Standarditem> standarditems5 = iStandarditemService.selectList(tmp);
		standardMap.put(standard5, standarditems5);

		Standard standard6 = iStandardService.selectById(standardplan.getQuest6());
		tmp = Condition.create().eq("sid", standard6.getId()).orderBy("inde", true);
		List<Standarditem> standarditems6 = iStandarditemService.selectList(tmp);
		standardMap.put(standard6, standarditems6);

		map.put("standards", standardMap);

		return "learn/feedback/add";
	}

	@RequestMapping("/insert")
	@RequiresPermissions("/learn/feedback/toInsert")
	@ResponseBody
	public Object insert(@Valid Feedback feedback, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) {
		// 新增的拿到学生信息
		Student student = (Student) session.getAttribute(Constant.SESSION_USER_KEY);
		// 拿到填写日期
		String writedate = feedback.getWritedate();
		// 拿到当前学生id
		String sid = student.getId();
		Wrapper wrapper = Condition.create().eq("writedate", writedate).eq("sid", sid);
		if (!CommonUtil.isBlank(feedback.selectList(wrapper))) {
			return ajaxError("当天已经填写了");
		}
		// 学生id
		feedback.setSid(sid);
		// 班级id
		feedback.setCid(student.getClzid());
		// 已读 1-是、2否
		feedback.setIsread(2);
		// 拿到当前班级在教老师
		wrapper = Condition.create().eq("cid", student.getClzid()).eq("state", "1");
		TeacherClazz teacherClazz = iTeacherClazzService.selectOne(wrapper);
		feedback.setTid(teacherClazz.getTid());
		if (iFeedbackService.insert(feedback)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/toUpdate")
	@RequiresPermissions("/learn/feedback/toUpdate")
	public String toUpdate(String id, ModelMap map, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) {

		Feedback feedback = iFeedbackService.selectById(id);
		map.put("record", feedback);

		// 拿到记录的学生
		Student student = iStudentService.selectById(feedback.getSid());
		// 查询班级类型
		Clazz clazz = iClazzService.selectById(student.getClzid());
		// 课程id
		// 拿到课程一级
		// 查询二级课程列表
		Wrapper wrapper = Condition.create().eq("pid", clazz.getCid()).orderBy("sort", true);
		map.put("chapters", iCourseService.selectList(wrapper));
		// 查询三级课程的父课程
		Course course = iCourseService.selectById(feedback.getCrid());
		// 查询三级课程id拿到它父亲的id
		// 把父亲id放到request作用域
		map.put("chapterid", course.getPid());
		// 根据二级课程查询三级课程
		wrapper = Condition.create().eq("pid", course.getPid()).orderBy("sort", true);
		map.put("courses", iCourseService.selectList(wrapper));
		// 查找当天反馈计划
		// 状态 1-启用、2停用
		Wrapper wrapper2 = Condition.create().eq("plantdate", CommonUtil.date()).eq("state", "1");
		Standardplan standardplan = iStandardplanService.selectOne(wrapper2);

		Map standardMap = new LinkedHashMap();
		// 查询反馈问题
		Standard standard1 = iStandardService.selectById(standardplan.getQuest1());
		Wrapper tmp = Condition.create().eq("sid", standard1.getId()).orderBy("inde", true);
		List<Standarditem> standarditems1 = iStandarditemService.selectList(tmp);
		standardMap.put(standard1, standarditems1);

		Standard standard2 = iStandardService.selectById(standardplan.getQuest2());
		tmp = Condition.create().eq("sid", standard2.getId()).orderBy("inde", true);
		List<Standarditem> standarditems2 = iStandarditemService.selectList(tmp);
		standardMap.put(standard2, standarditems2);

		Standard standard3 = iStandardService.selectById(standardplan.getQuest3());
		tmp = Condition.create().eq("sid", standard3.getId()).orderBy("inde", true);
		List<Standarditem> standarditems3 = iStandarditemService.selectList(tmp);
		standardMap.put(standard3, standarditems3);

		Standard standard4 = iStandardService.selectById(standardplan.getQuest4());
		tmp = Condition.create().eq("sid", standard4.getId()).orderBy("inde", true);
		List<Standarditem> standarditems4 = iStandarditemService.selectList(tmp);
		standardMap.put(standard4, standarditems4);

		Standard standard5 = iStandardService.selectById(standardplan.getQuest5());
		tmp = Condition.create().eq("sid", standard5.getId()).orderBy("inde", true);
		List<Standarditem> standarditems5 = iStandarditemService.selectList(tmp);
		standardMap.put(standard5, standarditems5);

		Standard standard6 = iStandardService.selectById(standardplan.getQuest6());
		tmp = Condition.create().eq("sid", standard6.getId()).orderBy("inde", true);
		List<Standarditem> standarditems6 = iStandarditemService.selectList(tmp);
		standardMap.put(standard6, standarditems6);

		map.put("standards", standardMap);

		return "learn/feedback/edit";
	}

	@RequestMapping("/update")
	@RequiresPermissions("/learn/feedback/toUpdate")
	@ResponseBody
	public Object update(@Valid Feedback feedback, HttpServletRequest request, HttpServletResponse response) {
		if (iFeedbackService.updateById(feedback)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/delete")
	@RequiresPermissions("/learn/feedback/delete")
	@ResponseBody
	public Object delete(String[] id, HttpServletRequest request, HttpServletResponse response) {
		if (iFeedbackService.deleteBatchIds(Arrays.asList(id))) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/getCourse")
	@RequiresPermissions("/learn/feedback/toInsert")
	@ResponseBody
	public Object getCourse(String cid, HttpServletRequest request, HttpServletResponse response) {
		// 查询3级菜单
		Wrapper wrapper = Condition.create().eq("pid", cid).orderBy("sort", true);
		return ajaxSuccess(iCourseService.selectList(wrapper));
	}

	@RequestMapping("/toDetail")
	@RequiresPermissions("/learn/feedback/toDetail")
	public String toDetail(String id, String sname, String cid, String writedate, String isread, Integer index,
			String from, DwzPageBean dwzPageBean, ModelMap map, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) {
		Wrapper wrapper = Condition.create();
		if (!CommonUtil.isBlank(sname)) {
			// 根据学生搜索
			wrapper.isWhere(true);
			wrapper.like("s.name", sname);
			map.put("sname", sname);
		}
		if (!CommonUtil.isBlank(cid)) {
			// 根据班级搜索
			wrapper.isWhere(true);
			wrapper.eq("f.cid", cid);
			map.put("cid", cid);
		}
		if (!CommonUtil.isBlank(writedate)) {
			// 根据日期搜索
			wrapper.isWhere(true);
			wrapper.eq("f.writedate", writedate);
			map.put("writedate", writedate);
		}

		if (!CommonUtil.isBlank(isread)) {
			// 根据是否已读搜索
			wrapper.isWhere(true);
			wrapper.eq("f.isread", isread);
			map.put("isread", isread);
		}
		if (isStudent()) {
			// 学生
			// 新增的拿到学生信息
			String sid = (String) session.getAttribute(Constant.SESSION_USERID_KEY);
			// 学生只能查找自己的
			wrapper.isWhere(true);
			wrapper.eq("f.sid", sid);
		}

		if (!CommonUtil.isBlank(dwzPageBean.getOrderField()) && !CommonUtil.isBlank(dwzPageBean.getOrderDirection())) {
			wrapper.orderBy(dwzPageBean.getOrderField(), CommonUtil.isEquals(dwzPageBean.getOrderDirection(), "asc"));
		} else {
			// 默认排序字段
			wrapper.orderBy("create_time", false);
		}
		Page resultPage = iFeedbackService.selectVoPage(dwzPageBean.toPage(), wrapper);
		if (index > 0) {
			map.put("preRecord", ((FeedbackVo) resultPage.getRecords().get(index - 1)).getId());
			map.put("preIndex", index - 1);
		}
		if (index < (resultPage.getRecords().size() - 1)) {
			map.put("nextRecord", ((FeedbackVo) resultPage.getRecords().get(index + 1)).getId());
			map.put("nextIndex", index + 1);
		}

		map.put("index", index);

		Feedback feedback = iFeedbackService.selectById(id);
		map.put("record", iFeedbackService.selectVo(Condition.create().isWhere(true).eq("f.id", id)).get(0));
		// map.put("record", feedback);
		// 拿到记录的学生
		Student student = iStudentService.selectById(feedback.getSid());
		// 查询班级类型
		Clazz clazz = iClazzService.selectById(student.getClzid());
		// 课程id
		// 拿到课程一级
		// 查询二级课程列表
		wrapper = Condition.create().eq("pid", clazz.getCid()).orderBy("sort", true);
		map.put("chapters", iCourseService.selectList(wrapper));
		// 查询三级课程的父课程
		Course course = iCourseService.selectById(feedback.getCrid());
		// 查询三级课程id拿到它父亲的id
		// 把父亲id放到request作用域
		map.put("chapterid", course.getPid());
		// 根据二级课程查询三级课程
		wrapper = Condition.create().eq("pid", course.getPid()).orderBy("sort", true);
		map.put("courses", iCourseService.selectList(wrapper));
		// 查找当天反馈计划
		// 状态 1-启用、2停用
		Wrapper wrapper2 = Condition.create().eq("plantdate", CommonUtil.date()).eq("state", "1");
		Standardplan standardplan = iStandardplanService.selectOne(wrapper2);

		Map standardMap = new LinkedHashMap();
		// 查询反馈问题
		Standard standard1 = iStandardService.selectById(standardplan.getQuest1());
		Wrapper tmp = Condition.create().eq("sid", standard1.getId()).orderBy("inde", true);
		List<Standarditem> standarditems1 = iStandarditemService.selectList(tmp);
		standardMap.put(standard1, standarditems1);

		Standard standard2 = iStandardService.selectById(standardplan.getQuest2());
		tmp = Condition.create().eq("sid", standard2.getId()).orderBy("inde", true);
		List<Standarditem> standarditems2 = iStandarditemService.selectList(tmp);
		standardMap.put(standard2, standarditems2);

		Standard standard3 = iStandardService.selectById(standardplan.getQuest3());
		tmp = Condition.create().eq("sid", standard3.getId()).orderBy("inde", true);
		List<Standarditem> standarditems3 = iStandarditemService.selectList(tmp);
		standardMap.put(standard3, standarditems3);

		Standard standard4 = iStandardService.selectById(standardplan.getQuest4());
		tmp = Condition.create().eq("sid", standard4.getId()).orderBy("inde", true);
		List<Standarditem> standarditems4 = iStandarditemService.selectList(tmp);
		standardMap.put(standard4, standarditems4);

		Standard standard5 = iStandardService.selectById(standardplan.getQuest5());
		tmp = Condition.create().eq("sid", standard5.getId()).orderBy("inde", true);
		List<Standarditem> standarditems5 = iStandarditemService.selectList(tmp);
		standardMap.put(standard5, standarditems5);

		Standard standard6 = iStandardService.selectById(standardplan.getQuest6());
		tmp = Condition.create().eq("sid", standard6.getId()).orderBy("inde", true);
		List<Standarditem> standarditems6 = iStandarditemService.selectList(tmp);
		standardMap.put(standard6, standarditems6);

		map.put("standards", standardMap);
		if (isTeacher()) {
			if (feedback.getIsread() == 2) {
				// 查看的时候更新查看人
				// 已读 1-是、2否
				feedback.setIsread(1);
				// 阅读人id
				feedback.setReader(session.getAttribute(Constant.SESSION_USERID_KEY).toString());
				// 阅读时间
				feedback.setReadtime(CommonUtil.date6());
				iFeedbackService.updateById(feedback);
			}
		}
		return "learn/feedback/detail";
	}

	@RequestMapping("/detail")
	@RequiresPermissions("/learn/feedback/toDetail")
	@ResponseBody
	public Object detail(HttpServletRequest request, HttpServletResponse response) {
		return ajaxSuccess();
	}

	@RequestMapping("/read")
	@RequiresPermissions("/learn/feedback/read")
	@ResponseBody
	public Object read(String id, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		Feedback feedback = iFeedbackService.selectById(id);
		if (feedback.getIsread() == 2) {
			// 查看的时候更新查看人
			// 已读 1-是、2否
			feedback.setIsread(1);
			// 阅读人id
			feedback.setReader(session.getAttribute(Constant.SESSION_USERID_KEY).toString());
			// 阅读时间
			feedback.setReadtime(CommonUtil.date6());
			if (iFeedbackService.updateById(feedback)) {
				return ajaxSuccess();
			} else {
				return ajaxError();
			}
		}
		return ajaxSuccess();
	}

	@RequestMapping("/toListNoCommit")
	@RequiresPermissions("/learn/feedback/toListNoCommit")
	public String toListNoCommit(String cid, String writedate, String sname, ModelMap map, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) {
		if (CommonUtil.isBlank(writedate)) {
			writedate = (String) session.getAttribute("writedate");
		} else {
			session.setAttribute("writedate", writedate);
		}
		if (CommonUtil.isBlank(cid)) {
			cid = (String) session.getAttribute("cid");
		} else {
			session.setAttribute("cid", cid);
		}
		if (CommonUtil.isBlank(sname)) {
			sname = (String) session.getAttribute("sname");
		} else {
			session.setAttribute("sname", sname);
		}
		if (!CommonUtil.isBlank(cid) && !CommonUtil.isBlank(writedate)) {
			// 查询条件
			map.put("students", iStudentService.selectNoCommitFeedbackByCidAndWritedate(cid, writedate, sname));
		}
		map.put("cid", cid);
		map.put("writedate", writedate);
		// 查询所有班级
		map.put("clazzs", iClazzService.selectList(null));
		return "learn/feedback/listNoCommit";
	}
}
