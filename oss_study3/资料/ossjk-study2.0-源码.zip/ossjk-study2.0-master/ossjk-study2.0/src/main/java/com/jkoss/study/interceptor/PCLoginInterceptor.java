package com.jkoss.study.interceptor;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.mapper.Condition;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.jkoss.base.controller.BaseController;
import com.jkoss.common.util.CommonUtil;
import com.jkoss.common.util.JwtTokenUtil;
import com.jkoss.common.vo.DwzResultBean;
import com.jkoss.study.constant.Constant;
import com.jkoss.study.educational.entity.Student;
import com.jkoss.study.educational.service.IStudentService;
import com.jkoss.study.system.entity.Token;
import com.jkoss.study.system.service.ITokenService;

@Component
public class PCLoginInterceptor implements HandlerInterceptor {
	public Logger log = LoggerFactory.getLogger(PCLoginInterceptor.class);

	@Autowired
	private ITokenService iTokenService;
	@Autowired
	private JwtTokenUtil jwtTokenUtil;
	@Autowired
	private IStudentService iStudentService;

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		String token = jwtTokenUtil.getPCToken(request);
		log.info(token);
		// token不为空
		if (!CommonUtil.isBlank(token)) {
			Wrapper wrapper = Condition.create().eq("token", token);
			Token tokenObject = iTokenService.selectOne(wrapper);

			if (CommonUtil.isBlank(tokenObject)) {
				// 数据库没有找到
				PrintWriter printWriter = response.getWriter();
				DwzResultBean bean = new DwzResultBean();
				bean.setStatusCode(Constant.RESULT_CODE_NOTOKEN + "");
				bean.setMessage(Constant.RESULT_MSG_NOTOKEN);
				printWriter.append(JSON.toJSONString(bean));
				return false;
			} else {
				if (CommonUtil.isEquals(token, tokenObject.getToken())) {
					if (CommonUtil.compareTo(tokenObject.getDuration(), CommonUtil.getDate()) >= 1) {
						// 当前时间大于token时间
						if (CommonUtil.diff(tokenObject.getDuration(), CommonUtil.getDate(), "MINUTES") <= 9) {
							// 刷新token
							PrintWriter printWriter = response.getWriter();
							DwzResultBean bean = new DwzResultBean();
							bean.setStatusCode(Constant.RESULT_CODE_REFRESHTOEKN + "");
							bean.setMessage(Constant.RESULT_MSG_REFRESHTOEKN);
							String userid = jwtTokenUtil.getUserId(token);
							Wrapper wrapper2 = Condition.create();
							wrapper2.and("uid", userid);
							iTokenService.delete(wrapper2);
							Token token2 = new Token();
							token2.setUid(userid);
							Student vo = iStudentService.selectById(userid);
							String tokenStr = jwtTokenUtil.getToken(userid, JSON.toJSONString(vo));
							token2.setDuration(jwtTokenUtil.getTokenTimeOut(tokenStr));
							token2.setToken(tokenStr);
							iTokenService.insert(token2);

							bean.setContent(tokenStr);
							printWriter.append(JSON.toJSONString(bean));
							return false;
						} else {
							// 拦截通过
							return true;
						}
					} else {
						// token超时
						PrintWriter printWriter = response.getWriter();
						DwzResultBean bean = new DwzResultBean();
						bean.setStatusCode(Constant.RESULT_CODE_TOKENTIMEOUT + "");
						bean.setMessage(Constant.RESULT_MSG_TOKENTIMEOUT);
						printWriter.append(JSON.toJSONString(bean));
						return false;
					}
				} else {
					PrintWriter printWriter = response.getWriter();
					DwzResultBean bean = new DwzResultBean();
					bean.setStatusCode(Constant.RESULT_CODE_OTHERLOGIN + "");
					bean.setMessage(Constant.RESULT_MSG_OTHERLOGIN);
					printWriter.append(JSON.toJSONString(bean));
					return false;
				}
			}
		} else {
			PrintWriter printWriter = response.getWriter();
			DwzResultBean bean = new DwzResultBean();
			bean.setStatusCode(Constant.RESULT_CODE_OTHERLOGIN + "");
			bean.setMessage(Constant.RESULT_MSG_OTHERLOGIN);
			printWriter.append(JSON.toJSONString(bean));
			return false;
		}
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		HandlerInterceptor.super.postHandle(request, response, handler, modelAndView);
	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		HandlerInterceptor.super.afterCompletion(request, response, handler, ex);
	}

}
