package com.jkoss.study.system.service.impl;

import com.jkoss.study.system.entity.Role;
import com.jkoss.study.system.mapper.RoleMapper;
import com.jkoss.study.system.service.IRoleService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;

import java.util.List;

import org.springframework.stereotype.Service;


/**
 * 角色 服务实现类
 * 
 * @Author Jason
 * @Version 1.0, 2019-05-28
 * @See
 * @Since com.jkoss.study.system.service.impl
 * @Description: TODO
 */
@Service
public class RoleServiceImpl extends ServiceImpl<RoleMapper, Role> implements IRoleService {

	@Override
	public List<Role> selectListByUid(String id) {
		return baseMapper.selectListByUid(id);
	}

}
