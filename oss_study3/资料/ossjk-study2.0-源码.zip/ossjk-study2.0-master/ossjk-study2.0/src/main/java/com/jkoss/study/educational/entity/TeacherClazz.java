package com.jkoss.study.educational.entity;

import java.io.Serializable;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.jkoss.base.entity.BaseEntity;

/**
 * 教师班级中间表
 * 
 * @Author chair
 * @Version 1.0, 2019-06-10
 * @See
 * @Since com.jkoss.study.educational.entity
 * @Description: TODO
 */
@TableName("teacher_clazz")
public class TeacherClazz extends BaseEntity<TeacherClazz> {

	private static final long serialVersionUID = 1L;

	@TableId("id")
	private String id;
	/**
	 * 教师id
	 */
	@TableField("tid")
	private String tid;
	/**
	 * 班级id
	 */
	@TableField("cid")
	private String cid;
	/**
	 * 状态：1-在教、2-历史
	 */
	@TableField("state")
	private Integer state;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTid() {
		return tid;
	}

	public void setTid(String tid) {
		this.tid = tid;
	}

	public String getCid() {
		return cid;
	}

	public void setCid(String cid) {
		this.cid = cid;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	@Override
	protected Serializable pkVal() {
		return this.id;
	}

	@Override
	public String toString() {
		return "TeacherClazz{" + ", id=" + id + ", tid=" + tid + ", cid=" + cid + ", state=" + state + "}";
	}
}
