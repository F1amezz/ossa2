package com.jkoss.study.interview.controller;

import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.baomidou.mybatisplus.mapper.Condition;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.jkoss.base.controller.BaseController;
import com.jkoss.common.util.CommonUtil;
import com.jkoss.common.vo.DwzPageBean;
import com.jkoss.study.constant.Constant;
import com.jkoss.study.educational.entity.Student;
import com.jkoss.study.educational.service.IClazzService;
import com.jkoss.study.educational.service.IStudentService;
import com.jkoss.study.interview.entity.Interview;
import com.jkoss.study.interview.entity.Interviewanswer;
import com.jkoss.study.interview.entity.Interviewquestion;
import com.jkoss.study.interview.service.IEnterpriseService;
import com.jkoss.study.interview.service.IInterviewService;
import com.jkoss.study.interview.service.IInterviewanswerService;
import com.jkoss.study.interview.service.IInterviewquestionService;
import com.jkoss.study.interview.service.IPostService;

/**
 * 面试表 前端控制器
 * 
 * @Author Jason
 * @Version 1.0, 2019-08-11
 * @See
 * @Since com.jkoss.study.interview.controller
 * @Description: TODO
 */
@Controller
@RequestMapping("/interview/interviewafter")
public class InterviewAfterController extends BaseController {

	@Autowired
	private IInterviewService iInterviewService;
	@Autowired
	private IEnterpriseService iEnterpriseService;
	@Autowired
	private IPostService iPostService;

	@Autowired
	private IInterviewquestionService iInterviewquestionService;

	@Autowired
	private IInterviewanswerService iInterviewanswerService;

	@Autowired
	private IStudentService iStudentService;

	@Autowired
	private IClazzService iClazzService;

	@RequestMapping("/list")
	@RequiresPermissions("/interview/interviewafter/list")
	public String list(String cid, String sname, String ename, String interviewdate, DwzPageBean dwzPageBean, ModelMap map, HttpSession session, HttpServletRequest request, HttpServletResponse response) throws Exception {
		Wrapper wrapper = Condition.create();

		if (!CommonUtil.isBlank(cid)) {
			// 根据班级搜索
			wrapper.isWhere(true);
			wrapper.eq("c.id", cid);
			dwzPageBean.getCountResultMap().put("cid", cid);
		}
		if (!CommonUtil.isBlank(sname)) {
			// 根据学生搜索
			wrapper.isWhere(true);
			wrapper.like("s.name", sname);
			dwzPageBean.getCountResultMap().put("sname", sname);
		}
		if (!CommonUtil.isBlank(ename)) {
			// 根据企业搜索
			wrapper.isWhere(true);
			wrapper.like("e.name", ename);
			dwzPageBean.getCountResultMap().put("ename", ename);
		}
		if (!CommonUtil.isBlank(interviewdate)) {
			// 根据学生搜索
			wrapper.isWhere(true);
			wrapper.like("interviewdate", interviewdate);
			dwzPageBean.getCountResultMap().put("interviewdate", interviewdate);
		}

		if (isStudent()) {
			// 学生登录
			Student student = (Student) session.getAttribute(Constant.SESSION_USER_KEY);
			wrapper.isWhere(true);
			wrapper.eq("i.sid", student.getId());
		}
		if (!CommonUtil.isBlank(dwzPageBean.getOrderField()) && !CommonUtil.isBlank(dwzPageBean.getOrderDirection())) {
			dwzPageBean.getCountResultMap().put("orderField", dwzPageBean.getOrderField());
			dwzPageBean.getCountResultMap().put("orderDirection", dwzPageBean.getOrderDirection());
			wrapper.orderBy(dwzPageBean.getOrderField(), CommonUtil.isEquals(dwzPageBean.getOrderDirection(), "asc"));
		} else {
			// 默认排序字段
			// wrapper.orderBy("create_time", false);
		}
		Page resultPage = iInterviewService.selectVoPage(dwzPageBean.toPage(), wrapper);
		map.put("dwzPageBean", dwzPageBean.toDwzPageBean(resultPage));
		// 查询所有班级
		map.put("clazzs", iClazzService.selectList(null));
		return "interview/interviewafter/list";
	}

	@RequestMapping("/delete")
	@RequiresPermissions("/interview/interviewafter/delete")
	@ResponseBody
	public Object delete(String[] id, HttpServletRequest request, HttpServletResponse response) {
		if (iInterviewService.deleteBatchIds(Arrays.asList(id))) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/toUpdate")
	@RequiresPermissions("/interview/interviewafter/toUpdate")
	public String toUpdate(String id, String ischeck, ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		// 面试信息
		Interview interview = iInterviewService.selectById(id);
		map.put("record", interview);
		// 面试题信息
		Wrapper wrapper = Condition.create().eq("eid", interview.getEid()).eq("pid", interview.getPid());//.eq("initiator", interview.getSid());
		map.put("questions", iInterviewquestionService.selectList(wrapper));

		if (!CommonUtil.isBlank(ischeck)) {
			map.put("ischeck", ischeck);
			return "interview/interviewafter/check";
		} else {
			return "interview/interviewafter/edit";
		}
	}

	@RequestMapping("/update")
	@RequiresPermissions("/interview/interviewafter/toUpdate")
	@ResponseBody
	public Object update(@Valid Interview interview, HttpServletRequest request, HttpServletResponse response) {
		// 面试完成
		interview.setState(2);
		if (iInterviewService.updateById(interview)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/offer")
	@RequiresPermissions("/interview/interviewafter/offer")
	@ResponseBody
	public Object offer(@Valid Interview interview, HttpServletRequest request, HttpServletResponse response) {
		// 面试结果 1-通过、2-不通过
		interview.setResult(1);
		if (iInterviewService.updateById(interview)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/toInsertQuestion")
	@RequiresPermissions("/interview/interviewafter/toInsertQuestion")
	public String toInsertQuestion(String eid, String pid, String iid, String ischeck, ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		map.put("eid", eid);
		map.put("pid", pid);
		map.put("iid", iid);
		map.put("ischeck", ischeck);
		return "interview/interviewafter/editQuestion";
	}

	@RequestMapping("/insertQuestion")
	@RequiresPermissions("/interview/interviewafter/toInsertQuestion")
	@ResponseBody
	public Object insertQuestion(String eid, String pid, String question, String answer, Integer type, String remk, HttpServletRequest request, HttpServletResponse response) throws Exception {

		// 面试题
		Interviewquestion interviewquestion = new Interviewquestion();
		interviewquestion.setContent(question);
		interviewquestion.setEid(eid);
		interviewquestion.setPid(pid);
		interviewquestion.setInitiator(getUserId());
		interviewquestion.setRemk(remk);
		// 状态 1-私有、2-共享
		interviewquestion.setType(type);

		// 答案
		Interviewanswer interviewanswer = new Interviewanswer();
		// 答案内容
		interviewanswer.setContent(answer);
		// 回答人类型 1-老师、-2学生
		if (!CommonUtil.isBlank(iStudentService.selectById(getUserId()))) {
			interviewanswer.setAnswertype(2);
		} else {
			interviewanswer.setAnswertype(1);
		}
		// 面试题id
		interviewanswer.setIqid(interviewquestion.getId());
		// 备注
		interviewanswer.setRemk(remk);
		// 状态 1-私有、2-共享
		interviewanswer.setType(type);
		// 回答人id
		interviewanswer.setInitiator(getUserId());

		if (iInterviewquestionService.insert(interviewquestion, interviewanswer)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/toUpdateQuestion")
	@RequiresPermissions("/interview/interviewafter/toUpdateQuestion")
	public String toUpdateQuestion(String id, String eid, String pid, String iid, ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		map.put("eid", eid);
		map.put("pid", pid);
		map.put("iid", iid);
		Interviewquestion interviewquestion = iInterviewquestionService.selectById(id);
		map.put("record", interviewquestion);
		Wrapper wrapper = Condition.create().eq("iqid", interviewquestion.getId());
		map.put("answer", iInterviewanswerService.selectOne(wrapper));
		return "interview/interviewafter/editQuestion";
	}

	@RequestMapping("/updateQuestion")
	@RequiresPermissions("/interview/interviewafter/toUpdateQuestion")
	@ResponseBody
	public Object updateQuestion(String questionid, String answerid, String eid, String pid, String question, String answer, Integer type, String remk, HttpServletRequest request, HttpServletResponse response) throws Exception {

		// 面试题
		Interviewquestion interviewquestion = new Interviewquestion();
		interviewquestion.setContent(question);
		interviewquestion.setEid(eid);
		interviewquestion.setPid(pid);
		interviewquestion.setInitiator(getUserId());
		interviewquestion.setRemk(remk);
		interviewquestion.setType(type);
		interviewquestion.setId(questionid);

		// 答案
		Interviewanswer interviewanswer = new Interviewanswer();
		// 答案内容
		interviewanswer.setContent(answer);
		// 回答人类型 1-老师、-2学生
		if (!CommonUtil.isBlank(iStudentService.selectById(getUserId()))) {
			interviewanswer.setAnswertype(2);
		} else {
			interviewanswer.setAnswertype(1);
		}
		// 面试题id
		interviewanswer.setIqid(interviewquestion.getId());
		// 备注
		interviewanswer.setRemk(remk);
		// 状态 1-私有、2-共享
		interviewanswer.setType(type);
		// 回答人id
		interviewanswer.setInitiator(getUserId());
		interviewanswer.setId(answerid);

		if (iInterviewquestionService.update(interviewquestion, interviewanswer)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/deleteQuestion")
	@RequiresPermissions("/interview/interviewafter/deleteQuestion")
	@ResponseBody
	public Object deleteQuestion(String[] id, HttpServletRequest request, HttpServletResponse response) {
		if (iInterviewquestionService.deleteBatchIds(Arrays.asList(id))) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/listAnswer")
	@RequiresPermissions("/interview/interviewafter/listAnswer")
	public String listAnswer(String iqid, ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		Wrapper wrapper = Condition.create().isWhere(true).eq("iqid", iqid);
		List<Interviewanswer> interviewanswers = iInterviewanswerService.selectVoList(wrapper);
		map.put("interviewanswers", interviewanswers);
		return "interview/interviewafter/listAnswer";
	}

}
