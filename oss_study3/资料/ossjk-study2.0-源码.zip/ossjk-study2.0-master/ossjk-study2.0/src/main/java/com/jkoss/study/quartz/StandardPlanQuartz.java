package com.jkoss.study.quartz;

import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.baomidou.mybatisplus.mapper.Condition;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.jkoss.common.util.CommonUtil;
import com.jkoss.study.educational.entity.Standard;
import com.jkoss.study.educational.service.IStandardService;
import com.jkoss.study.learn.entity.Standardplan;
import com.jkoss.study.learn.service.IStandardplanService;

@Component
public class StandardPlanQuartz {

	private Logger logger = LoggerFactory.getLogger(StandardPlanQuartz.class);
	@Autowired
	private IStandardService iStandardService;
	@Autowired
	private IStandardplanService iStandardplanService;

	@Scheduled(cron = "0 0 */1 * * ?")
	public void doSomething() throws Exception {
		logger.info("考核计划定时器开始");
		// 查找已经生成最大计划时间
		String plantDateStr = iStandardplanService.selectMaxPlantDate();
		// 生成最大计划时间
		Date plantDate = CommonUtil.getDate(plantDateStr, "@ISO");
		// 获取当前日期
		Date current = CommonUtil.getDate(new Date(), "@ISO");
		// 生成最大计划时间小于当前日期
		if (CommonUtil.compareTo(plantDate, current) < 0) {
			if (!isSameWeek(plantDate, current)) {
				// 获取
				Calendar todayCal = Calendar.getInstance();
				// 把之前的记录都失效了
				Standardplan entity = new Standardplan();
				// 状态 1-启用、2停用
				entity.setState(2);
				iStandardplanService.update(entity, null);
				// 类型 1-固定、2-随机、3-每周一次
				Wrapper wrapper = Condition.create().eq("type", "2").eq("state", "1").orderBy("create_time", true);
				List<Standard> randomStandards = iStandardService.selectList(wrapper);
				Wrapper wrapper1 = Condition.create().eq("type", "1").eq("state", "1").orderBy("create_time", true);
				List<Standard> fixedStandards = iStandardService.selectList(wrapper1);
				if (!CommonUtil.isBlank(randomStandards) && !CommonUtil.isBlank(fixedStandards)) {
					logger.info("查找到" + randomStandards.size() + "条随机题目和" + fixedStandards.size() + "条固定题目");
					List<Standardplan> standardplans = new ArrayList();
					// 生成7条记录所有循环7次
					for (int i = 0; i < 7; i++) {
						// 新建计划对象
						Standardplan standardplan = new Standardplan();
						// 设置日期
						standardplan.setPlantdate(CommonUtil.date(CommonUtil.plus(getMoney(), i, "*DAYS")));
						// 生成3个不同的随机数
						Set<Integer> nums = new HashSet();
						while (nums.size() < 3) {
							Random random = new Random();
							nums.add(random.nextInt(randomStandards.size()));
						}
						// 设置随机题目
						int count = 1;
						for (Integer index : nums) {
							String sid = randomStandards.get(index).getId();
							switch (count) {
							case 1:
								standardplan.setQuest1(sid);
								break;
							case 2:
								standardplan.setQuest2(sid);
								break;
							case 3:
								standardplan.setQuest3(sid);
								break;
							default:
								break;
							}
							count++;
						}
						// 设置固定题目
						standardplan.setQuest4(fixedStandards.get(0).getId());
						standardplan.setQuest5(fixedStandards.get(1).getId());
						standardplan.setQuest6(fixedStandards.get(2).getId());
						// 状态 1-启用、2停用
						standardplan.setState(1);
						standardplans.add(standardplan);
					}
					// 插入7天计划到数据表
					iStandardplanService.insertBatch(standardplans);
					logger.info("7天计划已经完成。");
				} else {
					logger.info("没有找到考核题目。");
				}

			} else {
				logger.info("已经生成考核计划");
			}
		} else {
			logger.info("已经生成考核计划");
		}

	}

	public static Date getMoney() {
		Calendar calendar = Calendar.getInstance(Locale.CHINA);
		calendar.setTime(CommonUtil.getDate());
		calendar.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
		return calendar.getTime();

	}

	public static boolean isSameWeek(Date date, Date date1) {
		if (date == null) {
			return false;
		}
		// 0.先把Date类型的对象转换Calendar类型的对象
		Calendar todayCal = Calendar.getInstance(Locale.CHINA);
		Calendar dateCal = Calendar.getInstance(Locale.CHINA);

		todayCal.setTime(date1);
		dateCal.setTime(date);
		int dateWeek = dateCal.get(Calendar.WEEK_OF_YEAR);
		int todayWeek = todayCal.get(Calendar.WEEK_OF_YEAR);
		if (dateCal.get(Calendar.DAY_OF_WEEK) == 1) {
			// 周日算上周
			dateWeek = dateWeek - 1;
		}

		if (todayCal.get(Calendar.DAY_OF_WEEK) == 1) {
			// 周日算上周
			todayWeek = todayWeek - 1;
		}
		// 1.比较当前日期在年份中的周数是否相同
		if (dateWeek == todayWeek) {
			return true;
		} else {
			return false;
		}
	}

}
