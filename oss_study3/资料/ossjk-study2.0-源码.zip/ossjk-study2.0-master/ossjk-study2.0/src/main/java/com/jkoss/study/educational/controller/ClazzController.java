package com.jkoss.study.educational.controller;

import java.util.Arrays;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.baomidou.mybatisplus.mapper.Condition;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.jkoss.base.controller.BaseController;
import com.jkoss.common.util.CommonUtil;
import com.jkoss.common.util.CryptoUtils;
import com.jkoss.common.vo.DwzPageBean;
import com.jkoss.study.constant.Constant;
import com.jkoss.study.educational.entity.Clazz;
import com.jkoss.study.educational.entity.Student;
import com.jkoss.study.educational.service.IClazzService;
import com.jkoss.study.educational.service.ICourseService;
import com.jkoss.study.educational.service.IStudentService;
import com.jkoss.study.educational.service.ITeacherClazzService;
import com.jkoss.study.system.entity.Teacher;
import com.jkoss.study.system.service.IRoleService;
import com.jkoss.study.system.service.ITeacherService;
import com.jkoss.study.system.service.IUserRoleService;

/**
 * 班级 前端控制器
 * 
 * @Author chair
 * @Version 1.0, 2019-06-05
 * @See
 * @Since com.jkoss.study.educational.controller
 * @Description: TODO
 */
@Controller
@RequestMapping("/educational/clazz")
public class ClazzController extends BaseController {

	@Autowired
	private IClazzService iClazzService;
	@Autowired
	private ICourseService iCourseService;
	@Autowired
	private IStudentService iStudentService;
	@Autowired
	private ITeacherService iTeacherService;
	@Autowired
	private ITeacherClazzService iTeacherClazzService;
	@Autowired
	private IRoleService iRoleService;
	@Autowired
	private IUserRoleService iUserRoleService;

	@RequestMapping("/list")
	@RequiresPermissions("/educational/clazz/list")
	public String list(String name, String type, DwzPageBean dwzPageBean, ModelMap map, HttpServletRequest request,
			HttpServletResponse response) {
		Wrapper wrapper = Condition.create();
		if (!CommonUtil.isBlank(name)) {
			wrapper.isWhere(true);
			wrapper.like("c.name", name);
			dwzPageBean.getCountResultMap().put("name", name);
		}
		if (!CommonUtil.isBlank(type)) {
			wrapper.isWhere(true);
			wrapper.eq("c.type", type);
			dwzPageBean.getCountResultMap().put("type", type);
		}

		wrapper.groupBy("c.id");

		if (!CommonUtil.isBlank(dwzPageBean.getOrderField()) && !CommonUtil.isBlank(dwzPageBean.getOrderDirection())) {
			wrapper.orderBy(dwzPageBean.getOrderField(), CommonUtil.isEquals(dwzPageBean.getOrderDirection(), "asc"));
		} else {
			// 默认排序字段
			wrapper.orderBy("crtm", false);
		}
		Page resultPage = iClazzService.selectVoPage(dwzPageBean.toPage(), wrapper);
		map.put("dwzPageBean", dwzPageBean.toDwzPageBean(resultPage));
		return "educational/clazz/list";
	}

	@RequestMapping("/toInsert")
	@RequiresPermissions("/educational/clazz/toInsert")
	public String toInsert(ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		// 查找一级课程
		Wrapper wrapper = Condition.create().eq("level", 1).orderBy("sort", true);
		map.put("courses", iCourseService.selectList(wrapper));
		return "educational/clazz/edit";
	}

	@RequestMapping("/insert")
	@RequiresPermissions("/educational/clazz/toInsert")
	@ResponseBody
	public Object insert(@Valid Clazz clazz, HttpServletRequest request, HttpServletResponse response) {
		if (iClazzService.insert(clazz)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}

	}

	@RequestMapping("/toUpdate")
	@RequiresPermissions("/educational/clazz/toUpdate")
	public String toUpdate(String id, ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		// 查找一级课程
		Wrapper wrapper = Condition.create().eq("level", 1).orderBy("sort", true);
		map.put("courses", iCourseService.selectList(wrapper));
		map.put("record", iClazzService.selectById(id));
		return "educational/clazz/edit";
	}

	@RequestMapping("/update")
	@RequiresPermissions("/educational/clazz/toUpdate")
	@ResponseBody
	public Object update(@Valid Clazz clazz, HttpServletRequest request, HttpServletResponse response) {
		if (iClazzService.updateById(clazz)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/delete")
	@RequiresPermissions("/educational/clazz/delete")
	@ResponseBody
	public Object delete(String[] id, HttpServletRequest request, HttpServletResponse response) {
		if (iClazzService.deleteBatchIds(Arrays.asList(id))) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/toListStudent")
	@RequiresPermissions("/educational/clazz/toListStudent")
	public Object toListStudent(String id, ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		Wrapper wrapper = Condition.create().eq("clzid", id).orderBy("create_time", true);
		map.put("students", iStudentService.selectList(wrapper));
		return "educational/clazz/listStudent";
	}

	@RequestMapping("/updateTeacher")
	@RequiresPermissions("/educational/clazz/toUpdateTeacher")
	@ResponseBody
	public Object updateTeacher(String id, String tid, HttpServletRequest request, HttpServletResponse response) {
		if (iTeacherClazzService.updateTeacher(id, tid) > 0) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/toListClazzTeacher")
	@RequiresPermissions("/educational/clazz/toListClazzTeacher")
	public String toListTeacher(String id, ModelMap map, HttpServletRequest request, HttpServletResponse response) {
		// 把班级带到页面
		map.put("id", id);

		// 查找在教老师
		Wrapper wrapper2 = Condition.create().eq("state", "1").eq("cid", id);
		map.put("teacherClazz", iTeacherClazzService.selectOne(wrapper2));
		map.put("teachers", iTeacherClazzService.selectVoByCid(id));
		map.put("cid", id);
		return "educational/clazz/listTeacher";
	}

	@RequestMapping("/deleteClazzTeacher")
	@RequiresPermissions("/educational/clazz/deleteClazzTeacher")
	@ResponseBody
	public Object deleteClazzTeacher(String id, HttpServletRequest request, HttpServletResponse response) {
		if (iTeacherClazzService.deleteById(id)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/toUpdateStudentRole")
	@RequiresPermissions("/educational/clazz/toUpdateStudentRole")
	public String toUpdateStudentRole(String id, ModelMap map, HttpServletRequest request,
			HttpServletResponse response) {
		map.put("id", id);
		map.put("roles", iRoleService.selectList(Condition.create().orderBy("create_time", false)));
		return "educational/clazz/updateStudentRole";
	}

	@RequestMapping("/updateStudentRole")
	@RequiresPermissions("/educational/clazz/toUpdateStudentRole")
	@ResponseBody
	public Object updateStudentRole(String id, String rid, ModelMap map, HttpServletRequest request,
			HttpServletResponse response) {
		if (iUserRoleService.updateStudentRoleByCid(id, rid)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/updatePwd")
	@RequiresPermissions("/educational/clazz/toUpdate")
	@ResponseBody
	public Object updatePwd(String id, HttpServletRequest request, HttpServletResponse response) {
		Clazz clazz = iClazzService.selectById(id);
		Student entity = new Student();
		entity.setPwd(CryptoUtils.encodeMD5(clazz.getPwd()));
		Wrapper wrapper = Condition.create().eq("clzid", clazz.getId());
		if (iStudentService.update(entity, wrapper)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

}
