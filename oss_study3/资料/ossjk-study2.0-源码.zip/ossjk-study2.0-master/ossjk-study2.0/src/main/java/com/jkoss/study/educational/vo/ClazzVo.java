package com.jkoss.study.educational.vo;

import com.jkoss.study.educational.entity.Clazz;

public class ClazzVo extends Clazz {
	private String crname;
	private String tname;
	private Integer stuno;
	
	public Integer getStuno() {
		return stuno;
	}

	public void setStuno(Integer stuno) {
		this.stuno = stuno;
	}

	public String getCrname() {
		return crname;
	}

	public void setCrname(String crname) {
		this.crname = crname;
	}

	public String getTname() {
		return tname;
	}

	public void setTname(String tname) {
		this.tname = tname;
	}

	@Override
	public String toString() {
		return "ClazzVo [crname=" + crname + ", tname=" + tname + "]";
	}

}
