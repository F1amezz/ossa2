package com.jkoss.study.exam.controller;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.baomidou.mybatisplus.mapper.Condition;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.jkoss.base.controller.BaseController;
import com.jkoss.common.util.CommonUtil;
import com.jkoss.common.vo.DwzPageBean;
import com.jkoss.study.educational.entity.Clazz;
import com.jkoss.study.educational.service.IClazzService;
import com.jkoss.study.exam.entity.Answer;
import com.jkoss.study.exam.entity.Exampaper;
import com.jkoss.study.exam.entity.Question;
import com.jkoss.study.exam.service.IAnswerService;
import com.jkoss.study.exam.service.IExampaperService;
import com.jkoss.study.exam.service.IQuestionService;
import com.jkoss.study.exam.vo.PaperVo;
import com.jkoss.study.exam.vo.PaperVo.Content;

/**
 * 答题表 前端控制器
 * 
 * @Author Jason
 * @Version 1.0, 2019-10-21
 * @See
 * @Since com.jkoss.study.exam.controller
 * @Description: TODO
 */
@Controller
@RequestMapping("/exam/answer")
public class AnswerController extends BaseController {

	@Autowired
	private IAnswerService iAnswerService;

	@Autowired
	private IExampaperService iExampaperService;

	@Autowired
	private IClazzService iClazzService;
	@Autowired
	private IQuestionService iQuestionService;

	@RequestMapping("/list")
	@RequiresPermissions("/exam/answer/list")
	public String list(DwzPageBean dwzPageBean, String isFm, String sname, String cid, String writedate, ModelMap map,
			HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		Wrapper wrapper = Condition.create();

		sessionEqStored(isFm, "c.id", "cid", cid, session, wrapper);
		sessionLikeStored(isFm, "a.create_time", "writedate", writedate, session, wrapper);

		if (!CommonUtil.isBlank(sname)) {
			wrapper.isWhere(true);
			map.put("sname", sname);
			wrapper.like("s.name", sname);
		}
		if (!CommonUtil.isBlank(cid)) {
			wrapper.isWhere(true);
			map.put("cid", cid);
			wrapper.eq("a.cid", cid);
		}
		if (!CommonUtil.isBlank(dwzPageBean.getOrderField()) && !CommonUtil.isBlank(dwzPageBean.getOrderDirection())) {
			dwzPageBean.getCountResultMap().put("orderField", dwzPageBean.getOrderField());
			dwzPageBean.getCountResultMap().put("orderDirection", dwzPageBean.getOrderDirection());
			wrapper.orderBy(dwzPageBean.getOrderField(), CommonUtil.isEquals(dwzPageBean.getOrderDirection(), "asc"));
		} else {
			// 默认排序字段
			// wrapper.orderBy("create_time", false);
		}
		Page resultPage = iAnswerService.selectVoPage(dwzPageBean.toPage(), wrapper);
		// 班级
		Wrapper wrapper2 = Condition.create();
		List<Clazz> clazzs = iClazzService.selectList(wrapper2);
		map.put("clazzs", clazzs);

		map.put("dwzPageBean", dwzPageBean.toDwzPageBean(resultPage));
		return "exam/answer/list";
	}

	@RequestMapping("/check")
	@RequiresPermissions("/exam/answer/check")
	public String check(String aid, String expid, ModelMap map, HttpServletRequest request,
			HttpServletResponse response) {
		Exampaper exampaper = iExampaperService.selectById(expid);
		String content = exampaper.getContent();
		PaperVo paperVo = JSON.parseObject(content, PaperVo.class);
		Answer answer = iAnswerService.selectVoByid(aid);
//		List<Map> maps = JSON.parseArray(answer.getAnswer(), Map.class);
//		List contents = new ArrayList();
//		for (Map map2 : maps) {
//			Map content1 = new HashMap();
//			content1.put("answer", (List) map2.get("answer"));
//			content1.put("qcontent", (List) map2.get("qcontent"));
//			content1.put("qid", (List) map2.get("qid"));
//			content1.put("qscore", (List) map2.get("qscore"));
//			content1.put("sanswer", (List) map2.get("sanswer"));
//			content1.put("sscore", (List) map2.get("sscore"));
//			contents.add(content1);
//		}
//		// 最外层map
//		Map map2 = new HashMap();
//		map2.put("types", paperVo.getTypes());
//		map2.put("scores", paperVo.getScores());
//		map2.put("qnums", paperVo.getQnums());
//		map2.put("contents", contents);

		map.put("record", exampaper);
		map.put("answer", answer);
		map.put("paperVo", answer.getAnswer());
//		map.put("paperVo", JSON.toJSONString(map2));
//		answer.setAnswer(JSON.toJSONString(map2));
//		iAnswerService.updateById(answer);
		return "exam/answer/listDetail";
	}

	@RequestMapping("/delete")
	@RequiresPermissions("/exam/answer/delete")
	@ResponseBody
	public Object delete(String[] id, HttpServletRequest request, HttpServletResponse response) {
		if (iAnswerService.deleteBatchIds(Arrays.asList(id))) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}
	}

	@RequestMapping("/judge")
	@ResponseBody
	// @RequiresPermissions("/exam/answer/judge")
	public Object 判卷(String id, Double ss[], ModelMap map, HttpServletRequest request, HttpServletResponse response) {

		Answer answer = iAnswerService.selectVoByid(id);
		PaperVo paperVo = JSON.parseObject(answer.getAnswer(), PaperVo.class);
		List<Content> maps = paperVo.getContents();

		int no = 0;
		Double sum = 0d;
		for (Content mp : maps) {
			List<BigDecimal> sscore = mp.getSscore();
			for (int i = 0; i < sscore.size(); i++) {
				sum += ss[no];
				sscore.set(i, new BigDecimal(ss[no++]));
			}
			mp.setSscore(sscore);// ("sscore", sscore);
		}
		answer.setIsjudged(1); // 已判卷
		answer.setScore(Double.parseDouble(CommonUtil.df.format(sum)));
		answer.setAnswer(JSON.toJSONString(paperVo));

		if (iAnswerService.updateAllColumnById(answer)) {
			return ajaxSuccess();
		} else {
			return ajaxError();
		}

	}

	@RequestMapping("/updateJson")
	@ResponseBody
	public void updateJson() {

//		修改答案格式 

		List<Answer> answers = iAnswerService.selectList(null);
		for (Answer answer : answers) {
			String string = answer.getAnswer();

			try {
				PaperVo paperVo = JSON.parseObject(string, PaperVo.class);
			} catch (Exception e) {
				List<Content> contents = JSON.parseArray(string, PaperVo.Content.class);
				try {
					Exampaper exampaper = iExampaperService.selectById(answer.getExpid());
					PaperVo paperVo = JSON.parseObject(exampaper.getContent(), PaperVo.class);

					paperVo.setContents(contents);

					answer.setAnswer(JSON.toJSONString(paperVo));

					iAnswerService.updateById(answer);

				} catch (Exception e2) {
					log.error(answer.getExpid() + "试卷编号出现异常");
				}
			}

			 //有些数据没有sscore
		}

		// 修改题目格式
		Integer value[] = { 4, 5, 6, 7 };
		Wrapper wrapper = Condition.create().in("type", value);
		List<Question> list = iQuestionService.selectList(wrapper);
		for (Question question : list) {
			String string = question.getAnswer();
			if (question.getType() == 4) {

				try {
					// 正常格式
					List<String> list2 = JSON.parseArray(string, String.class);
				} catch (Exception e) {
					// 异常格式需要转换
					String[] strings = string.split(",");
					question.setAnswer(JSON.toJSONString(strings));
				}
			} else {
				try {
					// 正常格式
					JSON.parseObject(string, Map.class);
				} catch (Exception e) {
					// 异常格式需要转换
					// {"answer":"request.getSession().setAttribute(\"tid\",
					// tid);&lt;script&gt;123456&lt;/script&gt;\nrequest.getSession().setAttribute(\"tid\",
					// tid);&lt;script&gt;123456&lt;/script&gt;"}
					Map map = new HashMap();
					map.put("answer", string);
					question.setAnswer(JSON.toJSONString(map));
				}
			}
			iQuestionService.updateById(question);
		}

	}

}
