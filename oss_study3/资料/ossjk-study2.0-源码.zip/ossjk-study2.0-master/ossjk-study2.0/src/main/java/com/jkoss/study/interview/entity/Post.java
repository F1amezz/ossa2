package com.jkoss.study.interview.entity;

import java.io.Serializable;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.jkoss.base.entity.BaseEntity;

/**
 * 岗位
 * 
 * @Author chair
 * @Version 1.0, 2019-06-25
 * @See
 * @Since com.jkoss.study.interview.entity
 * @Description: TODO
 */
public class Post extends BaseEntity<Post> {

	private static final long serialVersionUID = 1L;

	/**
	 * id
	 */
	@TableId("id")
	private String id;
	/**
	 * 企业id
	 */
	@TableField("eid")
	private String eid;
	/**
	 * 姓名
	 */
	@TableField("name")
	private String name;
	/**
	 * 排序
	 */
	@TableField("inde")
	private Integer inde;
	/**
	 * 经验 1-实习、2-应届、3-半年、4-1年、5-1-2年、6-2-3年、7--4-5年、8-5年以上
	 */
	@TableField("experience")
	private Integer experience;
	/**
	 * 学历要求 1-无要求、2-高中、3-大专、4-本科、5-研究生
	 */
	@TableField("education")
	private String education;
	/**
	 * 招聘人数
	 */
	@TableField("nums")
	private Integer nums;
	/**
	 * 备注
	 */
	@TableField("remk")
	private String remk;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getEid() {
		return eid;
	}

	public void setEid(String eid) {
		this.eid = eid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getInde() {
		return inde;
	}

	public void setInde(Integer inde) {
		this.inde = inde;
	}

	public Integer getExperience() {
		return experience;
	}

	public void setExperience(Integer experience) {
		this.experience = experience;
	}

	public String getEducation() {
		return education;
	}

	public void setEducation(String education) {
		this.education = education;
	}

	public Integer getNums() {
		return nums;
	}

	public void setNums(Integer nums) {
		this.nums = nums;
	}

	public String getRemk() {
		return remk;
	}

	public void setRemk(String remk) {
		this.remk = remk;
	}

	@Override
	protected Serializable pkVal() {
		return this.id;
	}

	@Override
	public String toString() {
		return "Post{" + ", id=" + id + ", eid=" + eid + ", name=" + name + ", inde=" + inde + ", experience=" + experience + ", education=" + education + ", nums=" + nums + ", remk=" + remk + "}";
	}
}
