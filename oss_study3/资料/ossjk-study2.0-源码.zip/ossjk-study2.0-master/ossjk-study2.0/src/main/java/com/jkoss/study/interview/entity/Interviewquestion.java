package com.jkoss.study.interview.entity;

import java.io.Serializable;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.jkoss.base.entity.BaseEntity;

/**
 * 面试题
 * 
 * @Author Jason
 * @Version 1.0, 2019-08-11
 * @See
 * @Since com.jkoss.study.interview.entity
 * @Description: TODO
 */
public class Interviewquestion extends BaseEntity<Interviewquestion> {

	private static final long serialVersionUID = 1L;

	/**
	 * id
	 */
	@TableId("id")
	private String id;
	/**
	 * 企业id
	 */
	@TableField("eid")
	private String eid;
	/**
	 * 岗位id
	 */
	@TableField("pid")
	private String pid;
	/**
	 * 收集人id
	 */
	@TableField("initiator")
	private String initiator;
	@TableField("content")
	private String content;
	/**
	 * 状态 1-私有、2-共享
	 */
	@TableField("type")
	private Integer type;
	/**
	 * 备注
	 */
	@TableField("remk")
	private String remk;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getEid() {
		return eid;
	}

	public void setEid(String eid) {
		this.eid = eid;
	}

	public String getPid() {
		return pid;
	}

	public void setPid(String pid) {
		this.pid = pid;
	}

	public String getInitiator() {
		return initiator;
	}

	public void setInitiator(String initiator) {
		this.initiator = initiator;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public String getRemk() {
		return remk;
	}

	public void setRemk(String remk) {
		this.remk = remk;
	}

	@Override
	protected Serializable pkVal() {
		return this.id;
	}

	@Override
	public String toString() {
		return "Interviewquestion{" + ", id=" + id + ", eid=" + eid + ", pid=" + pid + ", initiator=" + initiator
				+ ", content=" + content + ", type=" + type + ", remk=" + remk + ", createTime=" + createTime
				+ ", creator=" + creator + ", modifyTime=" + modifyTime + ", modifier=" + modifier + "}";
	}
}
