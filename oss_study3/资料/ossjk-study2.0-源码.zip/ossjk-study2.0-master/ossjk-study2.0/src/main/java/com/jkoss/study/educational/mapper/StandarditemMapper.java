package com.jkoss.study.educational.mapper;

import com.jkoss.study.educational.entity.Standarditem;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * 考评选项 Mapper 接口
 * 
 * @Author chair
 * @Version 1.0, 2019-06-06
 * @See
 * @Since com.jkoss.study.educational.mapper
 * @Description: TODO
 */
public interface StandarditemMapper extends BaseMapper<Standarditem> {

}
