package com.jkoss.study.educational.service.impl;

import com.jkoss.study.educational.entity.TeacherClazz;
import com.jkoss.study.educational.mapper.TeacherClazzMapper;
import com.jkoss.study.educational.service.ITeacherClazzService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;

import java.util.List;

import org.springframework.stereotype.Service;

/**
 * 教师班级中间表 服务实现类
 * 
 * @Author chair
 * @Version 1.0, 2019-06-10
 * @See
 * @Since com.jkoss.study.educational.service.impl
 * @Description: TODO
 */
@Service
public class TeacherClazzServiceImpl extends ServiceImpl<TeacherClazzMapper, TeacherClazz> implements ITeacherClazzService {

	@Override
	public int updateTeacher(String id, String tid) {
		// 把以前该班级的老师更新为历史
		baseMapper.updateStateByCid(2, id);
		TeacherClazz teacherClazz = new TeacherClazz();
		teacherClazz.setCid(id);
		teacherClazz.setTid(tid);
		// 状态：1-在教、2-历史
		teacherClazz.setState(1);
		return baseMapper.insert(teacherClazz);
	}

	@Override
	public List selectVoByCid(String cid) {
		return baseMapper.selectVoByCid(cid);
	}

}
