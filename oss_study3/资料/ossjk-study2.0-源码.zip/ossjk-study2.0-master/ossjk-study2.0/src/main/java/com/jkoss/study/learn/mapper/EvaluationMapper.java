package com.jkoss.study.learn.mapper;

import com.jkoss.study.learn.entity.Evaluation;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;

/**
 * 总结 Mapper 接口
 * 
 * @Author chair
 * @Version 1.0, 2019-06-11
 * @See
 * @Since com.jkoss.study.learn.mapper
 * @Description: TODO
 */
public interface EvaluationMapper extends BaseMapper<Evaluation> {

	List selectVoPage(Page page, @Param("ew")Wrapper wrapper);

	List selectVo( @Param("ew")Wrapper wrapper);
}
