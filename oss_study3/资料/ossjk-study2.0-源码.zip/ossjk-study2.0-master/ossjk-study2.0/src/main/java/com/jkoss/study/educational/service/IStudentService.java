package com.jkoss.study.educational.service;

import com.jkoss.study.educational.entity.Student;
import com.jkoss.study.educational.vo.StudentExcelVo;
import com.jkoss.study.educational.vo.StudentVo;

import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.IService;

/**
 * 学生 服务类
 * 
 * @Author chair
 * @Version 1.0, 2019-06-04
 * @See
 * @Since com.jkoss.study.educational.service
 * @Description: TODO
 */
public interface IStudentService extends IService<Student> {

	Page selecVotPage(Page page, Wrapper wrapper);

	List<Student> selectNoCommitEvaluationByCidAndWritedate(String cid, String writedate, String sname);

	List<Student> selectNoCommitFeedbackByCidAndWritedate(String cid, String writedate, String sname);

	List<Student> selectNoCommitSelfevaluationByCidAndWeek(String cid, String week, String sname);

	boolean insertImportExcel(List<StudentExcelVo> studentExcelVos);

	StudentVo selectVo(Wrapper wrapper);

	List selectVoExcel(Wrapper wrapper);

}
