package com.jkoss.study.system.mapper;

import com.jkoss.study.system.entity.UserRole;

import org.apache.ibatis.annotations.Param;

import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * 用户角色 Mapper 接口
 * 
 * @Author Jason
 * @Version 1.0, 2019-05-27
 * @See
 * @Since com.jkoss.study.system.mapper
 * @Description: TODO
 */
public interface UserRoleMapper extends BaseMapper<UserRole> {

	int deleteStudentRoleByCid(@Param("cid")String cid);

}
