package com.jkoss.study.educational.service;

import com.jkoss.study.educational.entity.Standarditem;
import com.baomidou.mybatisplus.service.IService;

/**
 * 考评选项 服务类
 * 
 * @Author chair
 * @Version 1.0, 2019-06-06
 * @See
 * @Since com.jkoss.study.educational.service
 * @Description: TODO
 */
public interface IStandarditemService extends IService<Standarditem> {

}
