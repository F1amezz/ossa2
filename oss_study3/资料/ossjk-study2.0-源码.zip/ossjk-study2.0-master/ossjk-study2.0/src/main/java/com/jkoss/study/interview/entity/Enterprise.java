package com.jkoss.study.interview.entity;

import java.io.Serializable;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.jkoss.base.entity.BaseEntity;

/**
 * 企业表
 * 
 * @Author chair
 * @Version 1.0, 2019-06-24
 * @See
 * @Since com.jkoss.study.interview.entity
 * @Description: TODO
 */
public class Enterprise extends BaseEntity<Enterprise> {

	private static final long serialVersionUID = 1L;

	/**
	 * id
	 */
	@TableId("id")
	private String id;
	/**
	 * 姓名
	 */
	@TableField("name")
	private String name;
	/**
	 * 地址
	 */
	@TableField("adress")
	private String adress;
	/**
	 * 电话
	 */
	@TableField("phone")
	private String phone;
	/**
	 * 来源类型 1-学生、2-公司
	 */
	@TableField("type")
	private Integer type;
	/**
	 * 联系人
	 */
	@TableField("contact")
	private String contact;
	/**
	 * 联系人电话
	 */
	@TableField("contactphone")
	private String contactphone;
	/**
	 * 地址
	 */
	@TableField("site")
	private String site;
	/**
	 * 规模 1-20人以下、2-20-50人、3-50-150人、4-150-500人、5-500-1000人、6-1000-5000人、7-5000人以上
	 * 
	 */
	@TableField("scale")
	private Integer scale;
	/**
	 * 备注
	 */
	@TableField("remk")
	private String remk;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAdress() {
		return adress;
	}

	public void setAdress(String adress) {
		this.adress = adress;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getContactphone() {
		return contactphone;
	}

	public void setContactphone(String contactphone) {
		this.contactphone = contactphone;
	}

	public String getSite() {
		return site;
	}

	public void setSite(String site) {
		this.site = site;
	}

	public Integer getScale() {
		return scale;
	}

	public void setScale(Integer scale) {
		this.scale = scale;
	}

	public String getRemk() {
		return remk;
	}

	public void setRemk(String remk) {
		this.remk = remk;
	}

	@Override
	protected Serializable pkVal() {
		return this.id;
	}

	@Override
	public String toString() {
		return "Enterprise{" + ", id=" + id + ", name=" + name + ", adress=" + adress + ", phone=" + phone + ", type=" + type + ", contact=" + contact + ", contactphone=" + contactphone + ", site=" + site + ", scale=" + scale + ", remk=" + remk + "}";
	}
}
