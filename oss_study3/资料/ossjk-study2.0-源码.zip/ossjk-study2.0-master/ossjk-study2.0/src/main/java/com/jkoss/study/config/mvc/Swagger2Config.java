package com.jkoss.study.config.mvc;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.github.xiaoymin.knife4j.spring.annotations.EnableKnife4j;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Parameter;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
@EnableKnife4j
public class Swagger2Config {

	@Bean
	public Docket createMobilApi() {
		// 添加head参数start
		ParameterBuilder tokenPar = new ParameterBuilder();
		List<Parameter> pars = new ArrayList<Parameter>();
		tokenPar.name("uid").description("令牌").modelRef(new ModelRef("string")).parameterType("header").required(false)
				.build();
		pars.add(tokenPar.build());
		// 添加head参数end
		// return new
		// Docket(DocumentationType.SWAGGER_2).apiInfo(apiInfo()).select().apis(RequestHandlerSelectors.basePackage("com.jkoss.study.exam.api")).paths(PathSelectors.any()).build().globalOperationParameters(pars);

		Set<String> set = new HashSet<String>();
		set.add("http");
		set.add("https");
		return new Docket(DocumentationType.SWAGGER_2).protocols(set)
//				.host("s2.ossjk.com")
				.host("127.0.0.1:18098").groupName("手机端管理接口").select()
				.apis(RequestHandlerSelectors.basePackage("com.jkoss.study.exam.api.mobile")).paths(PathSelectors.any())
				.build().globalOperationParameters(pars).apiInfo(apiInfo("学习系统", "学习系统-手机端api接口文档", "1.0"));
	}

	@Bean
	public Docket createPcApi() {
		// 添加head参数start
		ParameterBuilder tokenPar = new ParameterBuilder();
		List<Parameter> pars = new ArrayList<Parameter>();
		tokenPar.name("token").description("令牌").modelRef(new ModelRef("string")).parameterType("header")
				.required(false).build();
		pars.add(tokenPar.build());
		// 添加head参数end
		// return new
		// Docket(DocumentationType.SWAGGER_2).apiInfo(apiInfo()).select().apis(RequestHandlerSelectors.basePackage("com.jkoss.study.exam.api")).paths(PathSelectors.any()).build().globalOperationParameters(pars);

		Set<String> set = new HashSet<String>();
		set.add("http");
		set.add("https");
		return new Docket(DocumentationType.SWAGGER_2).protocols(set)
//				.host("s2.ossjk.com")
				.host("127.0.0.1:18098").groupName("PC端管理接口").select()
				.apis(RequestHandlerSelectors.basePackage("com.jkoss.study.exam.api.pc")).paths(PathSelectors.any())
				.build().globalOperationParameters(pars).apiInfo(apiInfo("学习系统", "学习系统-PC端api接口文档", "1.0"));
	}

	private ApiInfo apiInfo(String title, String description, String version) {
		return new ApiInfoBuilder().title(title).description(description).version(version).build();
	}

}