package com.jkoss.study.interview.entity;

import java.io.Serializable;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.jkoss.base.entity.BaseEntity;

/**
 * 试题解答
 * 
 * @Author Jason
 * @Version 1.0, 2019-08-11
 * @See
 * @Since com.jkoss.study.interview.entity
 * @Description: TODO
 */
public class Interviewanswer extends BaseEntity<Interviewanswer> {

	private static final long serialVersionUID = 1L;

	/**
	 * id
	 */
	@TableId("id")
	private String id;
	/**
	 * 面试题id
	 */
	@TableField("iqid")
	private String iqid;
	/**
	 * 回答人id
	 */
	@TableField("initiator")
	private String initiator;
	@TableField("content")
	private String content;
	/**
	 * 状态 1-私有、2-共享
	 */
	@TableField("type")
	private Integer type;
	/**
	 * 回答人类型 1-老师、-2学生
	 */
	@TableField("answertype")
	private Integer answertype;
	/**
	 * 推荐 1-是、2-否
	 */
	@TableField("recommend")
	private Integer recommend;
	/**
	 * 备注
	 */
	@TableField("remk")
	private String remk;

	public String getIqid() {
		return iqid;
	}

	public void setIqid(String iqid) {
		this.iqid = iqid;
	}

	public String getInitiator() {
		return initiator;
	}

	public void setInitiator(String initiator) {
		this.initiator = initiator;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public Integer getAnswertype() {
		return answertype;
	}

	public void setAnswertype(Integer answertype) {
		this.answertype = answertype;
	}

	public Integer getRecommend() {
		return recommend;
	}

	public void setRecommend(Integer recommend) {
		this.recommend = recommend;
	}

	public String getRemk() {
		return remk;
	}

	public void setRemk(String remk) {
		this.remk = remk;
	}

	@Override
	protected Serializable pkVal() {
		return this.id;
	}

	@Override
	public String toString() {
		return "Interviewanswer{" + ", id=" + id + ", iqid=" + iqid + ", initiator=" + initiator + ", content="
				+ content + ", type=" + type + ", answertype=" + answertype + ", recommend=" + recommend + ", remk="
				+ remk + ", createTime=" + createTime + ", creator=" + creator + ", modifyTime=" + modifyTime
				+ ", modifier=" + modifier + "}";
	}
}
