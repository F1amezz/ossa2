package com.jkoss.study.learn.service.impl;

import com.jkoss.study.learn.entity.Selfevaluation;
import com.jkoss.study.learn.mapper.SelfevaluationMapper;
import com.jkoss.study.learn.service.ISelfevaluationService;
import com.baomidou.mybatisplus.mapper.SqlHelper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;

import java.util.List;

import org.springframework.stereotype.Service;

/**
 * 自我评价 服务实现类
 * 
 * @Author chair
 * @Version 1.0, 2019-06-28
 * @See
 * @Since com.jkoss.study.learn.service.impl
 * @Description: TODO
 */
@Service
public class SelfevaluationServiceImpl extends ServiceImpl<SelfevaluationMapper, Selfevaluation> implements ISelfevaluationService {

	@Override
	public Page selectVoPage(Page page, Wrapper wrapper) {
		// 把分页信息填充到条件
		SqlHelper.fillWrapper(page, wrapper);
		page.setRecords(baseMapper.selectVoPage(page, wrapper));
		return page;
	}

	@Override
	public List selectVo(Wrapper eq) {
		return baseMapper.selectVo(eq);
	}

}
