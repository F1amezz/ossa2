package com.jkoss.study.exam.entity;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.jkoss.base.entity.BaseEntity;

import java.io.Serializable;
import java.math.BigDecimal;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.activerecord.Model;

/**
 * 答题表
 * 
 * @Author Jason
 * @Version 1.0, 2019-10-21
 * @See
 * @Since com.jkoss.study.exam.entity
 * @Description: TODO
 */
public class Answer extends BaseEntity<Answer> {

	private static final long serialVersionUID = 1L;

	@TableField("eid")
	private String eid;
	@TableField("cid")
	private String cid;
	/**
	 * 考试人id
	 */
	@TableField("sid")
	private String sid;
	/**
	 * 类型 1-小考、2-考试
	 */
	@TableField("type")
	private Integer type;
	/**
	 * 考试时间（分钟）
	 */
	@TableField("duration")
	private Integer duration;

	@TableField("isjudged")
	private Integer isjudged;
	/**
	 * 得分
	 */
	@TableField("score")
	private Double score;
	@TableField("answer")
	private String answer;
	/**
	 * 试卷id
	 */
	@TableField("expid")
	private String expid;

	public String getEid() {
		return eid;
	}

	public void setEid(String eid) {
		this.eid = eid;
	}

	public String getCid() {
		return cid;
	}

	public void setCid(String cid) {
		this.cid = cid;
	}

	public String getSid() {
		return sid;
	}

	public void setSid(String sid) {
		this.sid = sid;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public Integer getDuration() {
		return duration;
	}

	public void setDuration(Integer duration) {
		this.duration = duration;
	}

	public Double getScore() {
		return score;
	}

	public void setScore(Double score) {
		this.score = score;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public String getExpid() {
		return expid;
	}

	public void setExpid(String expid) {
		this.expid = expid;
	}

	@Override
	protected Serializable pkVal() {
		return this.id;
	}

	public Integer getIsjudged() {
		return isjudged;
	}

	public void setIsjudged(Integer isjudged) {
		this.isjudged = isjudged;
	}

	@Override
	public String toString() {
		return "Answer{" + ", id=" + id + ", eid=" + eid + ", cid=" + cid + ", sid=" + sid + ", type=" + type
				+ ", duration=" + duration + ", score=" + score + ", isjudged= "+isjudged + ", answer=" + answer + ", expid=" + expid
				+ ", modifier=" + modifier + "}";
	}
}
