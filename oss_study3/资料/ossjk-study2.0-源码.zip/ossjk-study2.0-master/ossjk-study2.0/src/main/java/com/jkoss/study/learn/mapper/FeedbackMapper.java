package com.jkoss.study.learn.mapper;

import com.jkoss.study.learn.entity.Feedback;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;

/**
 * 反馈表 Mapper 接口
 * 
 * @Author chair
 * @Version 1.0, 2019-06-13
 * @See
 * @Since com.jkoss.study.learn.mapper
 * @Description: TODO
 */
public interface FeedbackMapper extends BaseMapper<Feedback> {

	List selectVoPage(Page page, @Param("ew") Wrapper wrapper);

	List selectVo(@Param("ew") Wrapper wrapper);

}
