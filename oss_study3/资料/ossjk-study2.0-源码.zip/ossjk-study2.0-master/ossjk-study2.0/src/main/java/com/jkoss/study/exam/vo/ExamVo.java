package com.jkoss.study.exam.vo;

import com.jkoss.study.exam.entity.Exam;

public class ExamVo extends Exam {
	
	private String cid;
	private String cname;
	private String expid;
	private String expname;
	private String exptype;
 
	private String expduration;
	private String expscore;
	private String exppassscore;
	private Long cnted;   //已交卷
	private Long juded;   //已批改
 
	public String getCid() {
		return cid;
	}

	public void setCid(String cid) {
		this.cid = cid;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getExpid() {
		return expid;
	}

	public void setExpid(String expid) {
		this.expid = expid;
	}

	public String getExpname() {
		return expname;
	}

	public void setExpname(String expname) {
		this.expname = expname;
	}

	public String getExptype() {
		return exptype;
	}

	public void setExptype(String exptype) {
		this.exptype = exptype;
	}

	public String getExpduration() {
		return expduration;
	}

	public void setExpduration(String expduration) {
		this.expduration = expduration;
	}

	public String getExpscore() {
		return expscore;
	}

	public void setExpscore(String expscore) {
		this.expscore = expscore;
	}

	public String getExppassscore() {
		return exppassscore;
	}

	public void setExppassscore(String exppassscore) {
		this.exppassscore = exppassscore;
	}

	public Long getCnted() {
		return cnted;
	}

	public void setCnted(Long cnted) {
		this.cnted = cnted;
	}

	public Long getJuded() {
		return juded;
	}

	public void setJuded(Long juded) {
		this.juded = juded;
	}

}
