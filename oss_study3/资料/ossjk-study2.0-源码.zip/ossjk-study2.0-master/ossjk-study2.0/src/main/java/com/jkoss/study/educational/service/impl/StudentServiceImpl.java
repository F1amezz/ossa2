package com.jkoss.study.educational.service.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.mapper.Condition;
import com.baomidou.mybatisplus.mapper.SqlHelper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.jkoss.common.util.CommonUtil;
import com.jkoss.common.util.CryptoUtils;
import com.jkoss.study.constant.Constant;
import com.jkoss.study.educational.entity.Clazz;
import com.jkoss.study.educational.entity.Student;
import com.jkoss.study.educational.mapper.StudentMapper;
import com.jkoss.study.educational.service.IClazzService;
import com.jkoss.study.educational.service.IStudentService;
import com.jkoss.study.educational.vo.StudentExcelVo;
import com.jkoss.study.educational.vo.StudentVo;
import com.jkoss.study.system.entity.UserRole;
import com.jkoss.study.system.mapper.UserRoleMapper;
import com.jkoss.study.system.service.IUserRoleService;

/**
 * 学生 服务实现类
 * 
 * @Author chair
 * @Version 1.0, 2019-06-04
 * @See
 * @Since com.jkoss.study.educational.service.impl
 * @Description: TODO
 */
@Service
public class StudentServiceImpl extends ServiceImpl<StudentMapper, Student> implements IStudentService {
	@Autowired
	private UserRoleMapper userRoleMapper;
	@Autowired
	private IClazzService iClazzService;
	@Autowired
	private IUserRoleService iUserRoleService;

	@Override
	public Page selecVotPage(Page page, Wrapper wrapper) {
		// 把分页信息填充到条件
		SqlHelper.fillWrapper(page, wrapper);
		page.setRecords(baseMapper.selectVoPage(page, wrapper));
		return page;
	}

	public boolean insert(Student student) {
		// 新增完student
		int result = baseMapper.insert(student);
		// 默认给student赋值角 色
		UserRole userRole = new UserRole();
		userRole.setUid(student.getId());
		userRole.setRid(Constant.STUDENT_ROLE_ID);
		// 新增到角色表
		userRoleMapper.insert(userRole);
		return retBool(result);
	}

	@Override
	public List<Student> selectNoCommitEvaluationByCidAndWritedate(String cid, String writedate, String sname) {

		return this.baseMapper.selectNoCommitEvaluationByCidAndWritedate(cid, writedate, sname);
	}

	@Override
	public List<Student> selectNoCommitFeedbackByCidAndWritedate(String cid, String writedate, String sname) {
		return this.baseMapper.selectNoCommitFeedbackByCidAndWritedate(cid, writedate, sname);
	}

	@Override
	public List<Student> selectNoCommitSelfevaluationByCidAndWeek(String cid, String week, String sname) {
		return this.baseMapper.selectNoCommitSelfevaluationByCidAndWeek(cid, week, sname);
	}

	@Override
	public boolean insertImportExcel(List<StudentExcelVo> studentExcelVos) {

		Map<String, Clazz> clazzMap = new HashMap<String, Clazz>();
		Map<String, Student> studentMap = new HashMap<String, Student>();

		if (!CommonUtil.isBlank(studentExcelVos)) {
			for (StudentExcelVo studentExcelVo : studentExcelVos) {
				// 去除班级名称为空的数据,班级名称为空跳过本次循环
				if (CommonUtil.isBlank(studentExcelVo.getCname())) {
					continue;
				}
				Map map = CommonUtil.toMap(studentExcelVo);
				Clazz clazz = CommonUtil.toBean(Clazz.class, map);
				clazz.setId(null);
				clazz.setRemk(null);
				clazz.setPwd("88888888");// 给班级设置默认密码8个8
				clazz.setName(studentExcelVo.getCname().toUpperCase().trim());
				clazz.setEdtm(CommonUtil.date6(studentExcelVo.getCedtm()));
				clazz.setRdtm(CommonUtil.date6(studentExcelVo.getCrdtm()));
				clazz.setCrtm(CommonUtil.date6(studentExcelVo.getCcrtm()));
				if (!CommonUtil.isBlank(clazz.getName())) {
					// 利用班级名称去重
					// 班级名称转为小写
					clazzMap.put(clazz.getName(), clazz);
				}

				Student student = CommonUtil.toBean(Student.class, map);
				if (!CommonUtil.isBlank(student.getId())) {
					student.setId("1000" + student.getId().trim());
				}
				student.setState(1);
				student.setRttm(CommonUtil.date6(studentExcelVo.getRttm()));
				student.setCltm(CommonUtil.date6(studentExcelVo.getCltm()));
				student.setClzid(clazz.getName());// 借助clzid设置班级名称，等待班级数据设置到数据库，再把班级id设置回来
				student.setPhone(student.getPhone().trim());
				student.setName(student.getName().trim());

				student.setLname(student.getPhone());// 手机号码为登录密码
				student.setPwd(CryptoUtils.encodeMD5(clazz.getPwd()));// 设置默认密码

				if (!CommonUtil.isBlank(student.getPhone())) {
					studentMap.put(student.getPhone(), student);// 利用学生号码去重
				}
			}
			// 查询数据库数据是否存在去重数据库重复数据
			Wrapper wrapper = Condition.create().in("name", clazzMap.keySet());
			List<Clazz> clazzs2 = iClazzService.selectList(wrapper);
			for (Clazz clazz : clazzs2) {
				// 过滤班级名称转为小写
				clazzMap.remove(clazz.getName().toUpperCase().trim());
			}
			// 班级去除重复数据最后结果
			Collection<Clazz> clazzs = clazzMap.values();
			// 导入班级
			List<Clazz> list = new ArrayList<Clazz>();
			list.addAll(clazzs);
			if (!CommonUtil.isBlank(list)) {
				iClazzService.insertBatch(list);
			}
			// 学生去重相同电话
			Wrapper wrapper2 = Condition.create().in("phone", studentMap.keySet());
			List<Student> students2 = this.selectList(wrapper2);
			for (Student student : students2) {
				studentMap.remove(student.getPhone());
			}
			// 去除重复数据最后结果
			Collection<Student> students = studentMap.values();// 去除电话号码相同

			// 有id就去除id重复，没有id就直接添加数据
			List<Student> list2 = new ArrayList<Student>();
			Map<String, Student> studentMap2 = new HashMap<String, Student>();// id不为空的数据内容
			for (Student student : students) {
				if (CommonUtil.isBlank(student.getId())) {
					// id为空直接添加数据
					list2.add(student);
				} else {
					// id不为空去除重复数据
					studentMap2.put(student.getId(), student);
				}
			}
			// 查询数据库中所有学生去重复
			if (CommonUtil.isBlank(studentMap2)) {
				List<Student> students3 = this.selectList(null);
				for (Student student : students3) {
					studentMap2.remove(student.getId());
				}
			}
			Collection<Student> students4 = studentMap2.values();// 去除id相同
			list2.addAll(students4);// 所有的学生数据，没有电话重复的、没有id的、没有id重复的数据
			// 查询所有班级
			List<Clazz> clazzs3 = iClazzService.selectList(null);
			// 修改学生关联班级id
			Map<String, String> clazzAll = new HashMap<String, String>();
			for (Clazz clazz : clazzs3) {
				clazzAll.put(clazz.getName().toUpperCase().trim(), clazz.getId());
			}

			List<UserRole> userRoles = new ArrayList();

			for (Student student : list2) {
				// 设置学生班级id
				student.setClzid(clazzAll.get(student.getClzid()));
				// 设置学生权限
				UserRole entity = new UserRole();
				entity.setUid(student.getId());
				// 学生权限
				entity.setRid("6c5edf450a484c7ebfd54e591d765b5f");
				userRoles.add(entity);
			}
			iUserRoleService.insertBatch(userRoles);

			// 导入学生
			// List<Student> list3 = new ArrayList<Student>();
			// list3.addAll(students4);
			// list3.addAll(students);
			if (!CommonUtil.isBlank(list2)) {
				this.insertBatch(list2);
			}
		}
		return true;
	}

	@Override
	public List selectVoExcel(Wrapper wrapper) {
		return baseMapper.selectVoExcel(wrapper);
	}

	@Override
	public StudentVo selectVo(Wrapper wrapper) {
		return baseMapper.selectVo(wrapper);
	}
}
