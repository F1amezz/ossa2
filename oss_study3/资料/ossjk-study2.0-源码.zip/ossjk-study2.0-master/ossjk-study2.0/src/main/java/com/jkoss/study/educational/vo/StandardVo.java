package com.jkoss.study.educational.vo;

import java.util.List;

import com.jkoss.study.educational.entity.Standard;
import com.jkoss.study.educational.entity.Standarditem;

public class StandardVo extends Standard{
	
	private List<Standarditem> items;

	public List<Standarditem> getItems() {
		return items;
	}

	public void setItems(List<Standarditem> items) {
		this.items = items;
	}

	@Override
	public String toString() {
		return "StandardVo [items=" + items + "]";
	}
	
	
}
