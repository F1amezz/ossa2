package com.jkoss.study.exam.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.mapper.SqlHelper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.jkoss.study.exam.api.vo.AnswerVo2;
import com.jkoss.study.exam.entity.Answer;
import com.jkoss.study.exam.mapper.AnswerMapper;
import com.jkoss.study.exam.service.IAnswerService;
import com.jkoss.study.exam.vo.AnswerVo;
import com.jkoss.study.exam.vo.ExamVo;

/**
 * 答题表 服务实现类
 * 
 * @Author Jason
 * @Version 1.0, 2019-10-21
 * @See
 * @Since com.jkoss.study.exam.service.impl
 * @Description: TODO
 */
@Service
public class AnswerServiceImpl extends ServiceImpl<AnswerMapper, Answer> implements IAnswerService {
	@Override
	public Page selectVoPage(Page page, Wrapper wrapper) {
		// TODO Auto-generated method stub
		SqlHelper.fillWrapper(page, wrapper);

		page.setRecords(baseMapper.selectVoPage(page, wrapper));
		return page;
	}

	@Override
	public AnswerVo selectVoByid(String id) {
		return baseMapper.selectVoByid(id);
	}

	@Override
	public List<AnswerVo> selectExpid(Wrapper wrapper) {
		return baseMapper.selectExpid(wrapper);
	}

	@Override
	public List<AnswerVo2> selectTranscript(Wrapper wrapper) {
		return baseMapper.selectTranscript(wrapper);
	}

	@Override
	public AnswerVo2 selectTranscriptById(String id) {
		return baseMapper.selectTranscriptById(id);
	}

	@Override
	public Page selectTranscriptVoPage(Page page, Wrapper wrapper) {
		// TODO Auto-generated method stub
//		SqlHelper.fillWrapper(page, wrapper);
		page.setRecords(baseMapper.selectTranscriptVoPage(page, wrapper));
		return page;
	}

}
