package com.jkoss.study.system.service.impl;

import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.jkoss.study.system.entity.Token;
import com.jkoss.study.system.mapper.TokenMapper;
import com.jkoss.study.system.service.ITokenService;

/**
 * 服务实现类
 * 
 * @Author Jason
 * @Version 1.0, 2019-11-06
 * @See
 * @Since com.jkoss.examination.system.service.impl
 * @Description: TODO
 */
@Service
public class TokenServiceImpl extends ServiceImpl<TokenMapper, Token> implements ITokenService {

}
