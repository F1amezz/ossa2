package com.jkoss.study.educational.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.jkoss.study.educational.entity.Clazz;

/**
 * 班级 Mapper 接口
 * 
 * @Author chair
 * @Version 1.0, 2019-06-05
 * @See
 * @Since com.jkoss.study.educational.mapper
 * @Description: TODO
 */
public interface ClazzMapper extends BaseMapper<Clazz> {

	List selectVoPage(Page page, @Param("ew") Wrapper wrapper);
	
	@Select("select count(id) from student where clzid=#{clzid}")
	Long countStus(@Param("clzid")String clzid);
	
	@Select("select * from clazz where crtm>DATE_ADD(current_date,interval -10 month) order by crtm desc")
	List< Clazz> selectList10MthAgo( );
	
	
	
}
