package com.jkoss.study.config.shiro;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.Filter;

import org.apache.shiro.mgt.SecurityManager;
import org.apache.shiro.session.mgt.SessionManager;
import org.apache.shiro.session.mgt.eis.MemorySessionDAO;
import org.apache.shiro.spring.LifecycleBeanPostProcessor;
import org.apache.shiro.spring.security.interceptor.AuthorizationAttributeSourceAdvisor;
import org.apache.shiro.spring.web.ShiroFilterFactoryBean;
import org.apache.shiro.web.mgt.DefaultWebSecurityManager;
import org.apache.shiro.web.session.mgt.DefaultWebSessionManager;
import org.springframework.aop.framework.autoproxy.DefaultAdvisorAutoProxyCreator;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.jkoss.study.shiro.AuthRealm;

/**
 * Created by Lucare.Feng on 2017/3/6.
 */
@Configuration
public class ShiroConfiguration {

	@Bean("sessionManager")
	public SessionManager sessionManager(@Qualifier("sessionDAO") MemorySessionDAO sessionDAO) {
		DefaultWebSessionManager sessionManager = new DefaultWebSessionManager();
		sessionManager.setSessionValidationSchedulerEnabled(true);
		sessionManager.setSessionIdUrlRewritingEnabled(false);
		sessionManager.setSessionDAO(sessionDAO);
		sessionManager.setGlobalSessionTimeout(1000 * 60 * 60);// 毫秒
		// sessionManager.setSessionIdCookieEnabled(false);
		return sessionManager;
	}

	@Bean("securityManager")
	public SecurityManager securityManager(@Qualifier("authRealm") AuthRealm authRealm, SessionManager sessionManager) {
		DefaultWebSecurityManager securityManager = new DefaultWebSecurityManager();
		securityManager.setRealm(authRealm);
		securityManager.setSessionManager(sessionManager);
		return securityManager;
	}

	@Bean(name = "sessionDAO")
	public MemorySessionDAO getMemorySessionDAO() {
		return new MemorySessionDAO();
	}

	// 配置自定义的权限登录器
	@Bean(name = "authRealm")
	public AuthRealm authRealm() {
		AuthRealm authRealm = new AuthRealm();
		// 设置加密
		// authRealm.setCredentialsMatcher(matcher);
		return authRealm;
	}

	// // 配置自定义的密码比较器
	// @Bean(name = "credentialsMatcher")
	// public CredentialsMatcher credentialsMatcher() {
	// return new MyCredentialsMatcher();
	// }

	@Bean("shiroFilter")
	public ShiroFilterFactoryBean shirFilter(SecurityManager securityManager) {
		ShiroFilterFactoryBean shiroFilter = new ShiroFilterFactoryBean();
		shiroFilter.setSecurityManager(securityManager);
		// 配置登录的url和登录成功的url
		shiroFilter.setLoginUrl("/toLogin");
		shiroFilter.setSuccessUrl("/");
		// oauth过滤
		Map<String, Filter> filters = new HashMap<>();
		filters.put("cors", new CORSFilter());
//		filters.put("oauth2", new AuthFilter());
//		filters.put("custom", new ShiroUserFilter());
		shiroFilter.setFilters(filters);
		Map<String, String> filterMap = new LinkedHashMap<>();

		filterMap.put("/statics/**", "anon");
		filterMap.put("/login", "anon");
		filterMap.put("/wxlogin", "anon");
		filterMap.put("/toBind", "anon");
		filterMap.put("/bind", "anon");

		// 手机端接口开放权限
		filterMap.put("/user/**", "anon");
		filterMap.put("/api/daily/**", "anon");
		filterMap.put("/api/transcript/**", "anon");

		// PC端接口开放权限
		filterMap.put("/pc/user/**", "anon,cors");
		filterMap.put("/pc/api/index/**", "anon,cors");
		filterMap.put("/pc/api/daily/**", "anon,cors");
		filterMap.put("/pc/api/transcript/**", "anon,cors");
		// swagger权限
		filterMap.put("/swagger-ui.html", "anon");
		filterMap.put("/webjars/**", "anon");
		filterMap.put("/api/**", "anon");
		filterMap.put("/swagger-resources/**", "anon");
		filterMap.put("/v2/**", "anon");
		filterMap.put("/configuration/**", "anon");
		// Knife4j权限
		filterMap.put("/doc.html", "anon");

		filterMap.put("/**", "authc");
		shiroFilter.setFilterChainDefinitionMap(filterMap);
		return shiroFilter;
	}

	@Bean("lifecycleBeanPostProcessor")
	public LifecycleBeanPostProcessor lifecycleBeanPostProcessor() {
		return new LifecycleBeanPostProcessor();
	}

	@Bean
	public DefaultAdvisorAutoProxyCreator defaultAdvisorAutoProxyCreator() {
		DefaultAdvisorAutoProxyCreator proxyCreator = new DefaultAdvisorAutoProxyCreator();
		proxyCreator.setProxyTargetClass(true);
		return proxyCreator;
	}

	@Bean
	public AuthorizationAttributeSourceAdvisor authorizationAttributeSourceAdvisor(SecurityManager securityManager) {
		AuthorizationAttributeSourceAdvisor advisor = new AuthorizationAttributeSourceAdvisor();
		advisor.setSecurityManager(securityManager);
		return advisor;
	}

}
