package com.jkoss.study.interview.service.impl;

import java.io.Serializable;
import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.mapper.Condition;
import com.baomidou.mybatisplus.mapper.SqlHelper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.jkoss.study.interview.entity.Interviewanswer;
import com.jkoss.study.interview.entity.Interviewquestion;
import com.jkoss.study.interview.mapper.InterviewquestionMapper;
import com.jkoss.study.interview.service.IInterviewanswerService;
import com.jkoss.study.interview.service.IInterviewquestionService;
import com.jkoss.study.interview.vo.InterviewquestionVo;

/**
 * 面试题 服务实现类
 * 
 * @Author Jason
 * @Version 1.0, 2019-08-11
 * @See
 * @Since com.jkoss.study.interview.service.impl
 * @Description: TODO
 */
@Service
public class InterviewquestionServiceImpl extends ServiceImpl<InterviewquestionMapper, Interviewquestion>
		implements IInterviewquestionService {
	@Autowired
	private IInterviewanswerService iInterviewanswerService;

	@Override
	public boolean deleteBatchIds(List<? extends Serializable> idList) {
		Wrapper wrapper = Condition.create().in("iqid", idList);
		iInterviewanswerService.delete(wrapper);
		return super.deleteBatchIds(idList);
	}

	@Override
	public boolean update(Interviewquestion interviewquestion, Interviewanswer interviewanswer) throws Exception {
		if (!updateById(interviewquestion)) {
			throw new Exception("修改出错");
		}
		if (!iInterviewanswerService.updateById(interviewanswer)) {
			throw new Exception("修改出错");
		}
		return true;
	}

	@Override
	public boolean insert(Interviewquestion interviewquestion, Interviewanswer interviewanswer) throws Exception {
		// 保存问题，并且获取id
		if (!insert(interviewquestion)) {
			throw new Exception("修改出错");
		}
		// 面试题id
		interviewanswer.setIqid(interviewquestion.getId());
		// 保存答案
		if (!iInterviewanswerService.insert(interviewanswer)) {
			throw new Exception("修改出错");
		}
		return true;
	}

	@Override
	public List selectVoList(@Param("ew") Wrapper wrapper) {
		return baseMapper.selectVoList(wrapper);
	}

	@Override
	public Page selectVoPage(Page page, Wrapper wrapper) {
		// 把分页信息填充到条件
		SqlHelper.fillWrapper(page, wrapper);
		page.setRecords(baseMapper.selectVoPage(page, wrapper));
		return page;
	}

	@Override
	public InterviewquestionVo selectVoById(String id) {
		// TODO Auto-generated method stub
		return baseMapper.selectVoById(id);
	}

}
