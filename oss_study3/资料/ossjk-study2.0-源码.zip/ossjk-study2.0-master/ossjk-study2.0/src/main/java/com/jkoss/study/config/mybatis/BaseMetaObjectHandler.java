package com.jkoss.study.config.mybatis;

import java.math.BigDecimal;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.reflection.MetaObject;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.baomidou.mybatisplus.mapper.MetaObjectHandler;
import com.jkoss.common.util.CommonUtil;
import com.jkoss.study.constant.Constant;

/**
 * mybatisplus自定义填充公共字段 ,即没有传的字段自动填充
 * 1.创建MyMetaObjectHandler继承com.baomidou.mybatisplus.mapper.MetaObjectHandler;
 * 2.重写insertFill和updateFill方法
 * 3.在application.yml上添加mybatis-plus.global-config.meta-object-handler=com.jkoss.example.config.mybatis.MyMetaObjectHandler
 * 4.需要自定义填充公共字段 ,即没有传的字段自动填充的,在实体类的字段上添加@TableField(value = "idcard", fill =
 * FieldFill.INSERT_UPDATE)
 */
@Component
public class BaseMetaObjectHandler extends MetaObjectHandler {

	/**
	 * 新增填充
	 */
	@Override
	public void insertFill(MetaObject metaObject) {
		if (!CommonUtil.isBlank(RequestContextHolder.getRequestAttributes())) {
			HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
			HttpSession httpSession = request.getSession();
			// 创建人
			setFieldValByName("creator", httpSession.getAttribute(Constant.SESSION_USERID_KEY), metaObject);
			// 修改人
			setFieldValByName("modifier", httpSession.getAttribute(Constant.SESSION_USERID_KEY), metaObject);
		}

		setFieldValByName("createTime", CommonUtil.date6(), metaObject);
		setFieldValByName("modifyTime", CommonUtil.date6(), metaObject);
	}

	/**
	 * 更新填充
	 */
	@Override
	public void updateFill(MetaObject metaObject) {
		if (!CommonUtil.isBlank(RequestContextHolder.getRequestAttributes())) {
			HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
			HttpSession httpSession = request.getSession();
			// 修改人
			setFieldValByName("modifier", httpSession.getAttribute(Constant.SESSION_USERID_KEY), metaObject);
		}
		setFieldValByName("modifyTime", CommonUtil.date6(), metaObject);
	}

}