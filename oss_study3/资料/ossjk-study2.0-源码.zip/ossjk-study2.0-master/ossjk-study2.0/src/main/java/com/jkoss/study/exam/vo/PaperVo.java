package com.jkoss.study.exam.vo;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

public class PaperVo {
	// {"types":[1],"scores":["10"],"qnums":["5"],"contexts":[{"qid":["23","24","27","26","28"],"qscore":["2","2","2","2","2"]}]}
	private List<String> types;
	private List<String> scores;
	private List<String> qnums;
	private List<Content> contents;

	public List<String> getTypes() {
		return types;
	}

	public void setTypes(List<String> types) {
		this.types = types;
	}

	public List<String> getScores() {
		return scores;
	}

	public void setScores(List<String> scores) {
		this.scores = scores;
	}

	public List<String> getQnums() {
		return qnums;
	}

	public void setQnums(List<String> qnums) {
		this.qnums = qnums;
	}

	public List<Content> getContents() {
		return contents;
	}

	public void setContents(List<Content> contents) {
		this.contents = contents;
	}

	public static class Content {
		private String type;
		private List<String> qid;
		private List<String> qscore;
		private List<Qcontent> qcontent;
		private List<String> answer;
		private List<String> sanswer;
		private List<BigDecimal> sscore;

		public Content() {
			// TODO Auto-generated constructor stub
		}

		public static class Qcontent {
			private Map<String, String> choiceList;
			private String title;
			private String analysis;

			public Qcontent() {
				// TODO Auto-generated constructor stub
			}

			public Map<String, String> getChoiceList() {
				return choiceList;
			}

			public void setChoiceList(Map<String, String> choiceList) {
				this.choiceList = choiceList;
			}

			public String getTitle() {
				return title;
			}

			public void setTitle(String title) {
				this.title = title;
			}

			public String getAnalysis() {
				return analysis;
			}

			public void setAnalysis(String analysis) {
				this.analysis = analysis;
			}

			public void getQcontent() {
				// TODO Auto-generated method stub

			}

		}

		public List<BigDecimal> getSscore() {
			return sscore;
		}

		public void setSscore(List<BigDecimal> sscore) {
			this.sscore = sscore;
		}

		public String getType() {
			return type;
		}

		public void setType(String type) {
			this.type = type;
		}

		public List<String> getQid() {
			return qid;
		}

		public void setQid(List<String> qid) {
			this.qid = qid;
		}

		public List<String> getQscore() {
			return qscore;
		}

		public void setQscore(List<String> qscore) {
			this.qscore = qscore;
		}

		public List<Qcontent> getQcontent() {
			return qcontent;
		}

		public void setQcontent(List<Qcontent> qcontent) {
			this.qcontent = qcontent;
		}

		public List<String> getAnswer() {
			return answer;
		}

		public void setAnswer(List<String> answer) {
			this.answer = answer;
		}

		public List<String> getSanswer() {
			return sanswer;
		}

		public void setSanswer(List<String> sanswer) {
			this.sanswer = sanswer;
		}

	}
}
