package com.jkoss.study.educational.entity;

import java.io.Serializable;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.jkoss.base.entity.BaseEntity;

/**
 * 课程
 * 
 * @Author chair
 * @Version 1.0, 2019-07-09
 * @See
 * @Since com.jkoss.study.educational.entity
 * @Description: TODO
 */
public class Course extends BaseEntity<Course> {

	private static final long serialVersionUID = 1L;

	/**
	 * id
	 */
	@TableId("id")
	private String id;
	/**
	 * 父id
	 */
	@TableField("pid")
	private String pid;
	/**
	 * 名称
	 */
	@TableField("name")
	private String name;
	/**
	 * 等级
	 */
	@TableField("level")
	private Integer level;
	/**
	 * 排序
	 */
	@TableField("sort")
	private Integer sort;
	/**
	 * 授课天数
	 */
	@TableField("days")
	private Integer days;
	/**
	 * 备注
	 */
	@TableField("remk")
	private String remk;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPid() {
		return pid;
	}

	public void setPid(String pid) {
		this.pid = pid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getLevel() {
		return level;
	}

	public void setLevel(Integer level) {
		this.level = level;
	}

	public Integer getSort() {
		return sort;
	}

	public void setSort(Integer sort) {
		this.sort = sort;
	}

	public Integer getDays() {
		return days;
	}

	public void setDays(Integer days) {
		this.days = days;
	}

	public String getRemk() {
		return remk;
	}

	public void setRemk(String remk) {
		this.remk = remk;
	}

	@Override
	protected Serializable pkVal() {
		return this.id;
	}

	@Override
	public String toString() {
		return "Course{" + ", id=" + id + ", pid=" + pid + ", name=" + name + ", level=" + level + ", sort=" + sort + ", days=" + days + ", remk=" + remk + "}";
	}
}
