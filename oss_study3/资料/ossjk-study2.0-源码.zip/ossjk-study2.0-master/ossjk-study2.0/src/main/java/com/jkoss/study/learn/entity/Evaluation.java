package com.jkoss.study.learn.entity;

import java.io.Serializable;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.jkoss.base.entity.BaseEntity;

/**
 * 总结
 * 
 * @Author chair
 * @Version 1.0, 2019-06-11
 * @See
 * @Since com.jkoss.study.learn.entity
 * @Description: TODO
 */
public class Evaluation extends BaseEntity<Evaluation> {

	private static final long serialVersionUID = 1L;

	@TableId("id")
	private String id;
	/**
	 * 学生id
	 */
	@TableField("sid")
	private String sid;
	/**
	 * 班级 id
	 */
	@TableField("cid")
	private String cid;
	@TableField("title")
	private String title;
	/**
	 * 日期
	 */
	@TableField("writedate")
	private String writedate;
	/**
	 * 内容
	 */
	@TableField("content")
	private String content;
	/**
	 * 已读 1-是、2否
	 */
	@TableField("isread")
	private Integer isread;
	/**
	 * 阅读人id
	 */
	@TableField("reader")
	private String reader;
	/**
	 * 阅读时间
	 */
	@TableField("readtime")
	private String readtime;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getSid() {
		return sid;
	}

	public void setSid(String sid) {
		this.sid = sid;
	}

	public String getCid() {
		return cid;
	}

	public void setCid(String cid) {
		this.cid = cid;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getWritedate() {
		return writedate;
	}

	public void setWritedate(String writedate) {
		this.writedate = writedate;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Integer getIsread() {
		return isread;
	}

	public void setIsread(Integer isread) {
		this.isread = isread;
	}

	public String getReader() {
		return reader;
	}

	public void setReader(String reader) {
		this.reader = reader;
	}

	public String getReadtime() {
		return readtime;
	}

	public void setReadtime(String readtime) {
		this.readtime = readtime;
	}

	@Override
	protected Serializable pkVal() {
		return this.id;
	}

	@Override
	public String toString() {
		return "Evaluation{" + ", id=" + id + ", sid=" + sid + ", cid=" + cid + ", title=" + title + ", writedate=" + writedate + ", content=" + content + ", isread=" + isread + ", reader=" + reader + ", readtime=" + readtime + "}";
	}
}
