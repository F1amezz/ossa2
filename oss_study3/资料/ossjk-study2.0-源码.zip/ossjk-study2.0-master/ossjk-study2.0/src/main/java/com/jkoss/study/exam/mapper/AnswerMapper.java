package com.jkoss.study.exam.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.jkoss.study.exam.api.vo.AnswerVo2;
import com.jkoss.study.exam.entity.Answer;
import com.jkoss.study.exam.vo.AnswerVo;

/**
 * 答题表 Mapper 接口
 * 
 * @Author Jason
 * @Version 1.0, 2019-10-21
 * @See
 * @Since com.jkoss.study.exam.mapper
 * @Description: TODO
 */
public interface AnswerMapper extends BaseMapper<Answer> {

	List selectVoPage(Page page, @Param("ew") Wrapper wrapper);

	AnswerVo selectVoByid(String id);

	List selectExpid(@Param("ew") Wrapper wrapper);

	List selectTranscript(@Param("ew") Wrapper wrapper);

	List selectTranscriptVoPage(Page page, @Param("ew") Wrapper wrapper);

	AnswerVo2 selectTranscriptById(String id);

	@Select("select count(id) from answer where eid=#{eid}")
	Long countAnswer(@Param("eid") String eid);

}
