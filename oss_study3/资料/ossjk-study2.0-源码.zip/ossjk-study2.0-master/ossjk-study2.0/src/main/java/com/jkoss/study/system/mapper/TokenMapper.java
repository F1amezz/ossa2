package com.jkoss.study.system.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.jkoss.study.system.entity.Token;

/**
 * Mapper 接口
 * 
 * @Author Jason
 * @Version 1.0, 2019-11-06
 * @See
 * @Since com.jkoss.examination.system.mapper
 * @Description: TODO
 */
public interface TokenMapper extends BaseMapper<Token> {

}
