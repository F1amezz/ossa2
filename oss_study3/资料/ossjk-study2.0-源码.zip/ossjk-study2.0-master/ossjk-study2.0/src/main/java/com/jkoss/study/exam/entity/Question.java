package com.jkoss.study.exam.entity;

import java.io.Serializable;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.jkoss.base.entity.BaseEntity;


/**
 * �����
 * 
 * @Author Jason
 * @Version 1.0, 2019-06-16
 * @See
 * @Since com.jkoss.study.exam.entity
 * @Description: TODO
 */
public class Question extends BaseEntity<Question> {

    private static final long serialVersionUID = 1L;

    /**
     * id
     */
    @TableId("id")
    private String id;
    /**
     * �γ�id
     */
    @TableField("cpid")
    private String cpid;
    /**
     * ģ��id
     */
    @TableField("mpid")
    private String mpid;
    /**
     * ģ��id
     */
    @TableField("zpid")
    private String zpid;
    /**
     * ��������
     */
    @TableField("name")
    private String name;
    /**
     * ���� 1-��ѡ�⡢2��ѡ�⡢3-�ж��⡢4-����⡢5-������⡢6-�����⡢7-������
     */
    @TableField("type")
    private Integer type;
    /**
     * ����
     */
    @TableField("content")
    private String content;
    /**
     * ��
     */
    @TableField("answer")
    private String answer;
    /**
     * ��Ŀ����
     */
    @TableField("analysis")
    private String analysis;
    /**
     * �Ѷ� 1-�ͷ֡�2-һ�㡢3-�״��4-����
     */
    @TableField("difficulty")
    private Integer difficulty;
    /**
     * �Ƿ������� 1-�ǡ�2-��
     */
    @TableField("is_subjective")
    private Integer isSubjective;
    /**
     * �Ƿ���� 1-���ӡ�2-������
     */
    @TableField("is_visible")
    private Integer isVisible;
    /**
     * ���Ƿ�����
     */
    @TableField("is_sort")
    private Integer isSort;
    /**
     * �������
     */
    @TableField("expose_times")
    private Integer exposeTimes;
    /**
     * ��ȷ����
     */
    @TableField("right_times")
    private Integer rightTimes;
    /**
     * �������
     */
    @TableField("wrong_times")
    private Integer wrongTimes;
    /**
     * ��Դ
     */
    @TableField("reference")
    private String reference;
    /**
     * ����
     */
    @TableField("examing_point")
    private String examingPoint;
    /**
     * �ؼ���
     */
    @TableField("keyword")
    private String keyword;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCpid() {
        return cpid;
    }

    public void setCpid(String cpid) {
        this.cpid = cpid;
    }

    public String getMpid() {
        return mpid;
    }

    public void setMpid(String mpid) {
        this.mpid = mpid;
    }

    public String getZpid() {
        return zpid;
    }

    public void setZpid(String zpid) {
        this.zpid = zpid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public String getAnalysis() {
        return analysis;
    }

    public void setAnalysis(String analysis) {
        this.analysis = analysis;
    }

    public Integer getDifficulty() {
        return difficulty;
    }

    public void setDifficulty(Integer difficulty) {
        this.difficulty = difficulty;
    }

    public Integer getIsSubjective() {
        return isSubjective;
    }

    public void setIsSubjective(Integer isSubjective) {
        this.isSubjective = isSubjective;
    }

    public Integer getIsVisible() {
        return isVisible;
    }

    public void setIsVisible(Integer isVisible) {
        this.isVisible = isVisible;
    }

    public Integer getIsSort() {
        return isSort;
    }

    public void setIsSort(Integer isSort) {
        this.isSort = isSort;
    }

    public Integer getExposeTimes() {
        return exposeTimes;
    }

    public void setExposeTimes(Integer exposeTimes) {
        this.exposeTimes = exposeTimes;
    }

    public Integer getRightTimes() {
        return rightTimes;
    }

    public void setRightTimes(Integer rightTimes) {
        this.rightTimes = rightTimes;
    }

    public Integer getWrongTimes() {
        return wrongTimes;
    }

    public void setWrongTimes(Integer wrongTimes) {
        this.wrongTimes = wrongTimes;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public String getExamingPoint() {
        return examingPoint;
    }

    public void setExamingPoint(String examingPoint) {
        this.examingPoint = examingPoint;
    }

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public String getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(String modifyTime) {
        this.modifyTime = modifyTime;
    }

    public String getModifier() {
        return modifier;
    }

    public void setModifier(String modifier) {
        this.modifier = modifier;
    }

    @Override
    protected Serializable pkVal() {
        return this.id;
    }

    @Override
    public String toString() {
        return "Question{" +
        ", id=" + id +
        ", cpid=" + cpid +
        ", mpid=" + mpid +
        ", zpid=" + zpid +
        ", name=" + name +
        ", type=" + type +
        ", content=" + content +
        ", answer=" + answer +
        ", analysis=" + analysis +
        ", difficulty=" + difficulty +
        ", isSubjective=" + isSubjective +
        ", isVisible=" + isVisible +
        ", isSort=" + isSort +
        ", exposeTimes=" + exposeTimes +
        ", rightTimes=" + rightTimes +
        ", wrongTimes=" + wrongTimes +
        ", reference=" + reference +
        ", examingPoint=" + examingPoint +
        ", keyword=" + keyword +
        ", createTime=" + createTime +
        ", creator=" + creator +
        ", modifyTime=" + modifyTime +
        ", modifier=" + modifier +
        "}";
    }
}
