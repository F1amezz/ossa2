package com.jkoss.study.educational.entity;

import java.io.Serializable;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.jkoss.base.entity.BaseEntity;


/**
 * 考评选项
 * 
 * @Author chair
 * @Version 1.0, 2019-06-06
 * @See
 * @Since com.jkoss.study.study.entity
 * @Description: TODO
 */
public class Standarditem extends BaseEntity<Standarditem> {

    private static final long serialVersionUID = 1L;

    /**
     * 老师考核表id
     */
    @TableField("sid")
    private String sid;
    /**
     * 内容
     */
    @TableField("content")
    private String content;
    /**
     * 排序
     */
    @TableField("inde")
    private Integer inde;
    /**
     * 分数
     */
    @TableField("score")
    private Integer score;
    /**
     * 备注
     */
    @TableField("remk")
    private String remk;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSid() {
        return sid;
    }

    public void setSid(String sid) {
        this.sid = sid;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Integer getInde() {
        return inde;
    }

    public void setInde(Integer inde) {
        this.inde = inde;
    }

    public Integer getScore() {
        return score;
    }

    public void setScore(Integer score) {
        this.score = score;
    }

    public String getRemk() {
        return remk;
    }

    public void setRemk(String remk) {
        this.remk = remk;
    }

    @Override
    protected Serializable pkVal() {
        return this.id;
    }

    @Override
    public String toString() {
        return "Standarditem{" +
        ", id=" + id +
        ", sid=" + sid +
        ", content=" + content +
        ", inde=" + inde +
        ", score=" + score +
        ", remk=" + remk +
        "}";
    }
}
