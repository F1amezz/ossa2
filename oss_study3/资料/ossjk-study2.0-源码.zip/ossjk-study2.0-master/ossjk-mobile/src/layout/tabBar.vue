<template>
	<van-tabbar route>
		<van-tabbar-item to="/home" icon="wap-home-o">
			首页
		</van-tabbar-item>

		<van-tabbar-item to="/examList" icon="edit">
			考试
		</van-tabbar-item>

		<van-tabbar-item to="/historyList" icon="orders-o">
			历史
		</van-tabbar-item>
	</van-tabbar>
</template>

<script>
</script>

<style>
</style>
