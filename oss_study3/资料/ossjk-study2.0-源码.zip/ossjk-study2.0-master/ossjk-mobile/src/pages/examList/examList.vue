<template>
	<div class="examList">
		考试列表页
		<global-tab-bar></global-tab-bar>
	</div>
</template>

<script>
</script>

<style>
</style>
