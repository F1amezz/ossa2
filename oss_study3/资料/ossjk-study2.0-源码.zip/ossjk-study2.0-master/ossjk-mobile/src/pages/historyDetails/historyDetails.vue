<template>
	<div>历史详情页</div>
</template>

<script>
</script>

<style>
</style>
