<template>
	<div>考试详情页</div>
</template>

<script>
</script>

<style>
</style>
