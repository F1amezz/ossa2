<template>
	<div class="home">
		首页
		<global-tab-bar></global-tab-bar>
	</div>
</template>

<script>
</script>

<style lang="less">
	
</style>
