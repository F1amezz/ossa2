import Vue from 'vue'
import App from './App.vue'
import router from "@/router/router.js" //路由

import Vant from 'vant';//vant-ui
import 'vant/lib/index.css';//vant-ui样式

import FastClick from 'fastclick' //解决移动端500ms延迟问题
FastClick.attach(document.body);

import "@/style/border.css" //解决移动端1px问题样式
import "@/style/reset.css" //重置样式

import global_tabBar from "@/plugins/global_tabBar.js"//菜单栏插件

Vue
	.use(Vant)
	.use(global_tabBar)

Vue.config.productionTip = false

new Vue({
	router,
	render: h => h(App),
}).$mount('#app')
