let routes = [{
	path:"/login",//登录
	alias:"/",
	component: () => import("@/pages/login/login")
},{
	path:"/home",//首页
	component: () => import("@/pages/home/home")
},{
	path:"/examList",//考试列表
	component: () => import("@/pages/examList/examList")
},{
	path:"/examDetails",//考试详情
	component: () => import("@/pages/examDetails/examDetails")
},{
	path:"/historyList",//历史列表
	component: () => import("@/pages/historyList/historyList")
},{
	path:"/historyDetails",//历史详情
	component: () => import("@/pages/historyDetails/historyDetails")
}]

export default routes