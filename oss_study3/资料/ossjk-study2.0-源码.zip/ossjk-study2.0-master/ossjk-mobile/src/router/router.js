import Vue from "vue"
import VueRouter from "vue-router"
import routes from "./routes/commonRoutes.js"//引入公共路由

Vue.use(VueRouter)

let router = new VueRouter({
	routes
})

export default router