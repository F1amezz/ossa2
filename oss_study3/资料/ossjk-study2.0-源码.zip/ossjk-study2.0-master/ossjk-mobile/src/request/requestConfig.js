import Vue from 'vue';
import axios from "axios"
import { Toast } from 'vant';//轻提示（loading效果）

Vue.use(Toast);

var httpRequest = axios.create({
	baseURL: process.env.VUE_APP_BASEURL
})

// 添加请求拦截器
httpRequest.interceptors.request.use(function(config) {
	Toast.loading({//加载中
	  message: '加载中...',
	  forbidClick: true,
	});
	return config;
}, function(error) {
	// 对请求错误做些什么
	return Promise.reject(error);
});

// 添加响应拦截器
httpRequest.interceptors.response.use(function(response) {
	Toast.clear();//加载完毕
	return response;
}, function(error) {
	// 对响应错误做点什么
	return Promise.reject(error);
});

export default httpRequest