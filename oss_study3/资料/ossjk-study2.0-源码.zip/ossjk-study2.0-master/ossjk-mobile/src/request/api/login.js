import { ajaxPost } from "@/utils/request.js"

// 登录接口
export function login(data){
	let url = "/pc/user/login"
	return ajaxPost(url,data)
}