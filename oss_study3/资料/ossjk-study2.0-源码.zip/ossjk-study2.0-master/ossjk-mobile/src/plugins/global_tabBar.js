import tabBar from "@/layout/tabBar"
let global_tabBar = {}

global_tabBar.install = function(Vue){
	Vue.component("globalTabBar",tabBar)//全局菜单栏
}

export default global_tabBar