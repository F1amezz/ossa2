let userModule = {
	namespaced:true,
	state:{
		token:""//token
	},
	mutations:{
		["GET_TOKEN"](state,token){//获取token或者刷新token
			state.token = token
			localStorage.setItem("TOKEN",token)//存储到localStorage
		},
		["CLEAR_TOKEN"](state){//清空token
			state.token = ""
			localStorage.removeItem("TOKEN")//清空localStorage里面的token
		}
	}
}
export default userModule