import Vue from "vue"
import Vuex from "vuex"
import userModule from "./modules/userModule.js"

export default new Vuex.Store({
	modules:{
		userModule
	}
})
