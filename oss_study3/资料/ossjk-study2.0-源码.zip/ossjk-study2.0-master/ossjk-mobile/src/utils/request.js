import httpRequest from "@/request/requestConfig.js"

// get请求
export function ajaxGet(url, params) {
	return httpRequest.request({
		method: 'get',
		url,
		params
	}).then((res) => {
		return res
	}).catch((error) => {
		return error
	})
}

// post请求
export function ajaxPost(url, data) {
	return httpRequest.request({
		method: 'post',
		url,
		data
	}).then((res) => {
		return res
	}).catch((error) => {
		return error
	})
}