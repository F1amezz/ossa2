---------



以下PC端接口



------

## 登录

**接口地址：** /ossjk-examination2.0-api/pc/user/login 

**返回格式：**json

**请求方式：**http post

**请求示例：**ossjk-examination2.0-api/user/login



**参数说明** 

| 名称  | 必填 | 类型   | 说明   |
| ----- | ---- | ------ | ------ |
| lname | 是   | string | 登录名 |
| pwd   | 是   | string | 密码   |

**返回参数说明：**

| 名称       | 类型   | 说明         |
| ---------- | ------ | ------------ |
| statusCode | int    | 返回码       |
| message    | String | 返回信息     |
| content    | object | 用户详情信息 |

测试参数：

| 参数  | 内容           |
| ----- | -------------- |
| lname | datou2，datou  |
| pwd   | 123456，123456 |



```json
{
    "statusCode": "200",
    "message": "登录成功",
    "navTabId": null,
    "dialogId": null,
    "callbackType": null,
    "forwardUrl": null,
    "rel": null,
    "confirmMsg": null,
    "content": {
        "img": null,
        "specialty": null,
        "modifier": "1000393",
        "cname": "J190715",
        "wxuid": null,
        "cltm": null,
        "egrs": null,
        "rttm": null,
        "lname": "13726320838",
        "modifyTime": "2019-07-24 18:31:52",
        "school": null,
        "id": "1000393",
        "state": "1",
        "addr": "黄村",
        "creator": null,
        "remk": "广东佛山",
        "sex": "0",
        "birth": "1998-01",
        "clzid": "80",
        "token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJqdGkiOiIwNGQyZGMyOThhODQ0ZWQ5OTExNjc0YjkzYmNmNjBmMiIsImlhdCI6MTU3NDU3ODQ2Nywic3ViIjoie1wiYWRkclwiOlwi6buE5p2RXCIsXCJiaXJ0aFwiOlwiMTk5OC0wMVwiLFwiY2x6aWRcIjpcIjgwXCIsXCJjbmFtZVwiOlwiSjE5MDcxNVwiLFwiaWRcIjpcIjEwMDAzOTNcIixcImxuYW1lXCI6XCIxMzcyNjMyMDgzOFwiLFwibW9kaWZpZXJcIjpcIjEwMDAzOTNcIixcIm1vZGlmeVRpbWVcIjpcIjIwMTktMDctMjQgMTg6MzE6NTJcIixcIm5hbWVcIjpcIuWQtOWbvemCplwiLFwicGhvbmVcIjpcIjEzNzI2MzIwODM4XCIsXCJwd2RcIjpcImUxMGFkYzM5NDliYTU5YWJiZTU2ZTA1N2YyMGY4ODNlXCIsXCJyZW1rXCI6XCLlub_kuJzkvZvlsbFcIixcInNleFwiOjAsXCJzdGF0ZVwiOjF9IiwiaWQiOiIxMDAwMzkzIiwiZXhwIjoxNTc0NTg1NjY3fQ.6g1SEEVtbzgqs6QQD8Lj6kqx0A90mxxnhs3Zj4iWvLA",
        "birthplace": null,
        "createTime": null,
        "egph": null,
        "phone": "13726320838",
        "idcard": null,
        "name": "吴国邦",
        "egct": null,
        "pwd": "e10adc3949ba59abbe56e057f20f883e",
        "groupno": null
    }
}
```



## 获取每日考核

**接口地址：** /ossjk-examination2.0-api/pc/api/daily/list

**返回格式：**json

**请求方式：**http get/post

**请求示例：**ossjk-examination2.0-api/api/daily/list?cid=2202ca84258d4f05a95544dae20dadec

 

**请求头设置：**

| 名称 | 必填 | 类型   | 说明   |
| ---- | ---- | ------ | ------ |
| uid  | 是   | string | 用户id |

**参数说明** 

| 名称 | 必填 | 类型   | 说明 |
| ---- | ---- | ------ | ---- |
| cid  | 是   | string | 班级 |

**返回参数说明：**

| 名称       | 类型   | 说明             |
| ---------- | ------ | ---------------- |
| statusCode | int    | 返回码           |
| exam       | object | 测试日程详情信息 |
| record     | object | 试卷详情         |
| subjects   | object | 考试章节、知识点 |

测试参数：

| 参数 | 内容                             |
| ---- | -------------------------------- |
| cid  | 2202ca84258d4f05a95544dae20dadec |
| uid  | 6de647181fe64e0fa9ff74fb3c81bdd8 |



**json详情：**

```json
{
	"statusCode": 200,
	"exam": {
		"id": "1361f3e7c2364763adccc8622c6e47dc",
		"createTime": null,
		"creator": null,
		"modifyTime": null,
		"modifier": null,
		"cid": "2202ca84258d4f05a95544dae20dadec",
		"expid": "aafa0624ecd44c67961f2bf15bdbb9ac",
		"startTime": "2019-07-10 09:59:59",
		"endTime": "2019-07-10 23:29:00"
	},
	"record": {
		"id": "aafa0624ecd44c67961f2bf15bdbb9ac",
		"createTime": "2019-06-22 00:10:14",
		"creator": "1",
		"modifyTime": "2019-06-22 00:10:14",
		"modifier": "1",
		"name": "admin123",
		"duration": 4,
		"score": 34,
		"passScore": 21,
		"type": 1,
		"isVisible": 1,
		"content": "",
		"status": 1,
		"mark": null
	},
	"subjects": [{
		"id": "817383a2e411401ca153eff0912d190f",
		"createTime": "2019-06-10 19:41:02",
		"creator": "1",
		"modifyTime": "2019-06-10 19:41:02",
		"modifier": "1",
		"pid": "2b18257e7e6c43fabc67911f05841464",
		"name": "框架",
		"level": 3,
		"sort": 1,
		"mark": null,
		"pname": "java进阶",
		"gpname": "java开发",
		"gpid": "527861f141dc42569ebf4ed5afc72ddc"
	}, {
		"id": "877c615005874eec88a86c08ac94b835",
		"createTime": "2019-06-10 19:32:50",
		"creator": "1",
		"modifyTime": "2019-06-10 19:32:50",
		"modifier": "1",
		"pid": "372a45eae1044176a2eca74036540c18",
		"name": "8打基本类型",
		"level": 3,
		"sort": 1,
		"mark": null,
		"pname": "java基础知识",
		"gpname": "java开发",
		"gpid": "527861f141dc42569ebf4ed5afc72ddc"
	}, {
		"id": "b7b5b4b3ac194ed9a4a2101199893a0b",
		"createTime": "2019-06-10 19:41:09",
		"creator": "1",
		"modifyTime": "2019-06-10 19:41:09",
		"modifier": "1",
		"pid": "372a45eae1044176a2eca74036540c18",
		"name": "循环",
		"level": 3,
		"sort": 2,
		"mark": null,
		"pname": "java基础知识",
		"gpname": "java开发",
		"gpid": "527861f141dc42569ebf4ed5afc72ddc"
	}]
}
```



## 获取每日考核试题

**接口地址：** /ossjk-examination2.0-api/pc/api/daily/dailyOne

**返回格式：**json

**请求方式：**http get/post

**请求示例：**ossjk-examination2.0-api/api/daily/dailyOne?cid=2202ca84258d4f05a95544dae20dadec

 

**请求头设置：**

| 名称 | 必填 | 类型   | 说明   |
| ---- | ---- | ------ | ------ |
| uid  | 是   | string | 用户id |

**参数说明** 

| 名称 | 必填 | 类型   | 说明 |
| ---- | ---- | ------ | ---- |
| cid  | 是   | string | 班级 |

**返回参数说明：**

| 名称       | 类型   | 说明             |
| ---------- | ------ | ---------------- |
| statusCode | int    | 返回码           |
| exam       | object | 测试日程详情信息 |
| record     | object | 试卷详情         |
| subjects   | object | 考试章节、知识点 |
| paperVo    | object | 试题详情         |

测试参数：

| 参数 | 内容                             |
| ---- | -------------------------------- |
| cid  | 2202ca84258d4f05a95544dae20dadec |
| uid  | 6de647181fe64e0fa9ff74fb3c81bdd8 |



**json详情：**

```json
{
	"statusCode": 200,
	"exam": {
		"id": "1361f3e7c2364763adccc8622c6e47dc",
		"createTime": null,
		"creator": null,
		"modifyTime": null,
		"modifier": null,
		"cid": "2202ca84258d4f05a95544dae20dadec",
		"expid": "aafa0624ecd44c67961f2bf15bdbb9ac",
		"startTime": "2019-07-10 09:59:59",
		"endTime": "2019-07-10 23:29:00"
	},
	"record": {
		"id": "aafa0624ecd44c67961f2bf15bdbb9ac",
		"createTime": "2019-06-22 00:10:14",
		"creator": "1",
		"modifyTime": "2019-06-22 00:10:14",
		"modifier": "1",
		"name": "admin123",
		"duration": 4,
		"score": 34,
		"passScore": 21,
		"type": 1,
		"isVisible": 1,
		"content": "",
		"status": 1,
		"mark": null
	},
	"subjects": [{
		"id": "817383a2e411401ca153eff0912d190f",
		"createTime": "2019-06-10 19:41:02",
		"creator": "1",
		"modifyTime": "2019-06-10 19:41:02",
		"modifier": "1",
		"pid": "2b18257e7e6c43fabc67911f05841464",
		"name": "框架",
		"level": 3,
		"sort": 1,
		"mark": null,
		"pname": "java进阶",
		"gpname": "java开发",
		"gpid": "527861f141dc42569ebf4ed5afc72ddc"
	}, {
		"id": "877c615005874eec88a86c08ac94b835",
		"createTime": "2019-06-10 19:32:50",
		"creator": "1",
		"modifyTime": "2019-06-10 19:32:50",
		"modifier": "1",
		"pid": "372a45eae1044176a2eca74036540c18",
		"name": "8打基本类型",
		"level": 3,
		"sort": 1,
		"mark": null,
		"pname": "java基础知识",
		"gpname": "java开发",
		"gpid": "527861f141dc42569ebf4ed5afc72ddc"
	}, {
		"id": "b7b5b4b3ac194ed9a4a2101199893a0b",
		"createTime": "2019-06-10 19:41:09",
		"creator": "1",
		"modifyTime": "2019-06-10 19:41:09",
		"modifier": "1",
		"pid": "372a45eae1044176a2eca74036540c18",
		"name": "循环",
		"level": 3,
		"sort": 2,
		"mark": null,
		"pname": "java基础知识",
		"gpname": "java开发",
		"gpid": "527861f141dc42569ebf4ed5afc72ddc"
	}],
	"paperVo": {
		"types": ["1", "2", "3", "4", "5", "6", "7"],
		"scores": ["2", "2", "22", "2", "2", "2", "2"],
		"qnums": ["2", "2", "2", "2", "2", "2", "2"],
		"contents": [{
			"qid": ["08ced7f43b634007b3e1488d375d769c", "76b67fc3440d447aa77489bb10716bd5"],
			"qscore": ["1", "1"],
			"qcontent": [{
				"choiceList": {
					"A": "1",
					"B": "2",
					"C": "3",
					"D": "4"
				},
				"title": "题目2"
			}, {
				"choiceList": {
					"A": "23232",
					"B": "323213123",
					"C": "123123123",
					"D": "1231231231"
				},
				"title": "3123"
			}],
			"answer": ["A", "A"]
		}, {
			"qid": ["011e40f0ff7d44b6a09f87031a8dad9a", "9c08de5b1ed14f4d959064f0904cabdf"],
			"qscore": ["1", "1"],
			"qcontent": [{
				"choiceList": {
					"A": "123123",
					"B": "12321312",
					"C": "31231231",
					"D": "23213213"
				},
				"title": "123123"
			}, {
				"choiceList": {
					"A": "123",
					"B": "123",
					"C": "123",
					"D": "123"
				},
				"title": "123"
			}],
			"answer": ["A,B", "A,B"]
		}, {
			"qid": ["3d0f8983a8844776a934fe5ac66d8371", "77832bd88e97496c9eb6367b67a17e3b"],
			"qscore": ["11", "11"],
			"qcontent": [{
				"choiceList": {
					"T": "正确",
					"F": "错误"
				},
				"title": "123111"
			}, {
				"choiceList": {
					"T": "正确",
					"F": "错误"
				},
				"title": "123123123123123"
			}],
			"answer": ["T", "T"]
		}, {
			"qid": ["0f3af0b32e8444a2b41f075165d33830", "2055e03535184a698f47ebb88d5834dc"],
			"qscore": ["1", "1"],
			"qcontent": [{
				"choiceList": {},
				"title": "(__)(__)"
			}, {
				"choiceList": {},
				"title": "11111(__)"
			}],
			"answer": ["1,2", "asdfsfsdfsdf"]
		}, {
			"qid": ["001d721b492d4ed5ac7af267f5821ffe", "3c6147a7534f41e9bd69df7e73eb65ac"],
			"qscore": ["1", "1"],
			"qcontent": [{
				"choiceList": {},
				"title": "11111111111111111111111111111"
			}, {
				"choiceList": {},
				"title": "123123"
			}],
			"answer": ["1111111111111111111111111111", "12312323333"]
		}, {
			"qid": ["9d39d60bc999471ba922778b96b46a07", "c5a87475c2504b828dca505b3c19d9f5"],
			"qscore": ["1", "1"],
			"qcontent": [{
				"choiceList": {},
				"title": "12222222222222222"
			}, {
				"choiceList": {},
				"title": "12333333"
			}],
			"answer": ["1111111111111111111111111111111", "22221111"]
		}, {
			"qid": ["7472f30735a04ac28c8c95323c6a8575", "bee3db670ba44284b4110b2fbd7cff45"],
			"qscore": ["1", "1"],
			"qcontent": [{
				"choiceList": {},
				"title": "1233333"
			}, {
				"choiceList": {},
				"title": "123257865423eteytrytreyerty"
			}],
			"answer": ["1111112222", "123257865423eteytrytreyerty"]
		}]
	}
}
```





## 提交答题内容



**接口地址：** /ossjk-examination2.0-api/pc/api/daily/insert

**返回格式：**json

**请求方式：**http post 

**请求示例：**

```javascript
 var c = {
            "expid": "aafa0624ecd44c67961f2bf15bdbb9ac",
            "cid": "2202ca84258d4f05a95544dae20dadec",
            "answer": JSON.stringify([{
                //试题类型编号
                "type": 1,
                //试题答题内容
                "sanswer": ["C", "A"]
            }, {
                    "type": 2,
                    "sanswer": ["A,B", "B,C"]
                }, {
                    "type": 3,
                    "sanswer": []
                }, {
                    "type": 4,
                    "sanswer": []
                }, {
                    "type": 5,
                    "sanswer": []
                }, {
                    "type": 6,
                    "sanswer": []
                }, {
                    "type": 7,
                    "sanswer": []
                }])
        }
           
        $.ajax({
                url: "http://localhost:8083/ossjk-examination2.0-api/api/daily/insert",
                data: c,
                headers: { "uid": "6de647181fe64e0fa9ff74fb3c81bdd8" },
                dataType: "json",
                success: function () {

                }
            });
```



**请求头设置：**

| 名称 | 必填 | 类型   | 说明   |
| ---- | ---- | ------ | ------ |
| uid  | 是   | string | 用户id |

参数说明** 

| 名称   | 必填 | 类型   | 说明         |
| ------ | ---- | ------ | ------------ |
| expid  | 是   | string | 试卷id       |
| cid    | 是   | string | 班级id       |
| answer | 是   | string | 答案对象字符 |

**返回参数说明：**

| 名称       | 类型   | 说明     |
| ---------- | ------ | -------- |
| statusCode | int    | 返回码   |
| message    | String | 返回信息 |



**json详情：**

```json
{
	"statusCode": "200",
	"message": "提交成功",
	"navTabId": null,
	"dialogId": null,
	"callbackType": null,
	"forwardUrl": null,
	"rel": null,
	"confirmMsg": null,
	"content": null
}
```

------

## 获取所有学生该考的试卷

**接口地址：** /ossjk-examination2.0-api/pc/api/daily/listMark

**返回格式：**json

**请求方式：**http post 

**请求示例：**

**请求头设置：**

| 名称 | 必填 | 类型   | 说明   |
| ---- | ---- | ------ | ------ |
| uid  | 是   | string | 用户id |

参数说明** 

| 名称 | 必填 | 类型   | 说明   |
| ---- | ---- | ------ | ------ |
| cid  | 是   | string | 班级id |

返回参数说明：**

| 名称       | 类型   | 说明               |
| ---------- | ------ | ------------------ |
| statusCode | int    | 返回码             |
| exam       | object | 测试日程详情信息   |
| record     | object | 试卷详情           |
| examlist   | object | 试卷的id和开考日期 |

**json详情：**

```json
{
    "statusCode": 200,
    "exam": {
        "id": "1e1dc1ba945b41f9a06bf635f372a48d",
        "createTime": null,
        "creator": null,
        "modifyTime": null,
        "modifier": null,
        "cid": "223e9da647254f0fb48a4bb736d94143",
        "expid": "aafa0624ecd44c67961f2bf15bdbb9ac",
        "startTime": "2019-07-19 09:09:29",
        "endTime": "2019-07-19 23:29:00"
    },
    "record": {
        "id": "aafa0624ecd44c67961f2bf15bdbb9ac",
        "createTime": "2019-06-22 00:10:14",
        "creator": "1",
        "modifyTime": "2019-06-22 00:10:14",
        "modifier": "1",
        "name": "admin123",
        "duration": 1,
        "score": 34,
        "passScore": 21,
        "type": 1,
        "isVisible": 1,
        "content": "",
        "status": 1,
        "mark": null
    },
    "subjects": null,
    "paperVo": null,
    "examlist": [
        {
            "subexam": 0,
            "expid": "aafa0624ecd44c67961f2bf15bdbb9ac",
            "date": "2019/07/19"
        }
    ]
}
```
------

## 获取成绩单列表

**接口地址：** /ossjk-examination2.0-api/pc/api/transcript/list

**返回格式：**json

**请求方式：**http post 

**请求示例：**

**请求头设置：**

| 名称 | 必填 | 类型   | 说明   |
| ---- | ---- | ------ | ------ |
| uid  | 是   | string | 用户id |

**参数说明** 

| 名称 | 必填 | 类型   | 说明                                                         |
| ---- | ---- | ------ | ------------------------------------------------------------ |
| date | 否   | string | 查询时间：1-参数为空查询所有数据、2-参数（yyyy-MM）查询当月数据、3-参数（yyyy-MM-dd）查询当日数据 |

**返回参数说明：**

| 名称       | 类型   | 说明               |
| ---------- | ------ | ------------------ |
| statusCode | int    | 返回码             |
| content    | object | 返回内容		   |
| id         | object | 答题id 			   |
| cid        | object | 班级id 			   |
| sid        | object | 考试人id 		   |
| type       | object | 类型 1-小考、2-考试 |
| duration   | object | 考试时间 |
| score      | object | 得分 |
| createTime | object | 做题时间 |
| answer     | object | 试卷答案和学生答案 |
| expname    | object | 试卷id |

**json详情：**

```json
{
    "statusCode": "200",
    "message": "操作成功",
    "navTabId": null,
    "dialogId": null,
    "callbackType": null,
    "forwardUrl": null,
    "rel": null,
    "confirmMsg": null,
    "content": [
        {
            "id": "f000a9b831be4af58bc7ba4a6805b2d7",
            "cid": "223e9da647254f0fb48a4bb736d94143",
            "sid": "801d33820136424eb6832e1a0257940d",
            "type": 1,
            "duration": 1,
            "score": 3,
            "expid": "aafa0624ecd44c67961f2bf15bdbb9ac",
            "createTime": "2019-10-19 09:59:59",
            "creator": null,
            "modifyTime": null,
            "modifier": null,
            "answer": "[{\"answer\":[\"A\",\"A\"],\"qcontent\":[{\"choiceList\":{\"A\":\"1\",\"B\":\"2\",\"C\":\"3\",\"D\":\"4\"},\"title\":\"题目2\"},{\"choiceList\":{\"A\":\"23232\",\"B\":\"323213123\",\"C\":\"123123123\",\"D\":\"1231231231\"},\"title\":\"3123\"}],\"qid\":[\"08ced7f43b634007b3e1488d375d769c\",\"76b67fc3440d447aa77489bb10716bd5\"],\"qscore\":[\"1\",\"1\"],\"sanswer\":[\"B\",\"C\"]},{\"answer\":[\"A,B\",\"A,B\"],\"qcontent\":[{\"choiceList\":{\"A\":\"123123\",\"B\":\"12321312\",\"C\":\"31231231\",\"D\":\"23213213\"},\"title\":\"123123\"},{\"choiceList\":{\"A\":\"123\",\"B\":\"123\",\"C\":\"123\",\"D\":\"123\"},\"title\":\"123\"}],\"qid\":[\"011e40f0ff7d44b6a09f87031a8dad9a\",\"9c08de5b1ed14f4d959064f0904cabdf\"],\"qscore\":[\"1\",\"1\"],\"sanswer\":[\"B,D\",\"A,B\"]},{\"answer\":[\"T\",\"T\"],\"qcontent\":[{\"choiceList\":{\"T\":\"正确\",\"F\":\"错误\"},\"title\":\"123111\"},{\"choiceList\":{\"T\":\"正确\",\"F\":\"错误\"},\"title\":\"123123123123123\"}],\"qid\":[\"3d0f8983a8844776a934fe5ac66d8371\",\"77832bd88e97496c9eb6367b67a17e3b\"],\"qscore\":[\"11\",\"11\"],\"sanswer\":[]},{\"answer\":[\"1,2\",\"asdfsfsdfsdf\"],\"qcontent\":[{\"choiceList\":{},\"title\":\"(__)(__)\"},{\"choiceList\":{},\"title\":\"11111(__)\"}],\"qid\":[\"0f3af0b32e8444a2b41f075165d33830\",\"2055e03535184a698f47ebb88d5834dc\"],\"qscore\":[\"1\",\"1\"],\"sanswer\":[]},{\"answer\":[\"1111111111111111111111111111\",\"12312323333\"],\"qcontent\":[{\"choiceList\":{},\"title\":\"11111111111111111111111111111\"},{\"choiceList\":{},\"title\":\"123123\"}],\"qid\":[\"001d721b492d4ed5ac7af267f5821ffe\",\"3c6147a7534f41e9bd69df7e73eb65ac\"],\"qscore\":[\"1\",\"1\"],\"sanswer\":[]},{\"answer\":[\"1111111111111111111111111111111\",\"22221111\"],\"qcontent\":[{\"choiceList\":{},\"title\":\"12222222222222222\"},{\"choiceList\":{},\"title\":\"12333333\"}],\"qid\":[\"9d39d60bc999471ba922778b96b46a07\",\"c5a87475c2504b828dca505b3c19d9f5\"],\"qscore\":[\"1\",\"1\"],\"sanswer\":[]},{\"answer\":[\"1111112222\",\"123257865423eteytrytreyerty\"],\"qcontent\":[{\"choiceList\":{},\"title\":\"1233333\"},{\"choiceList\":{},\"title\":\"123257865423eteytrytreyerty\"}],\"qid\":[\"7472f30735a04ac28c8c95323c6a8575\",\"bee3db670ba44284b4110b2fbd7cff45\"],\"qscore\":[\"1\",\"1\"],\"sanswer\":[]}]",
            "expname": "admin123"
        }
    ]
}
```
------

## 获取成绩单

**接口地址：** /ossjk-examination2.0-api/pc/api/transcript/transcriptById

**返回格式：**json

**请求方式：**http post 

**请求示例：**

**请求头设置：**

| 名称 | 必填 | 类型   | 说明   |
| ---- | ---- | ------ | ------ |
| uid  | 是   | string | 用户id |

**参数说明** 

| 名称 | 必填 | 类型   | 说明   |
| ---- | ---- | ------ | ------ |
| id  | 是   | string | 答题id |

**返回参数说明：**

| 名称       | 类型   | 说明               |
| ---------- | ------ | ------------------ |
| statusCode | int    | 返回码             |
| content    | object | 返回内容,顺序1-单选、2-多选		   |
| id         | object | 答题id 			   |
| cid        | object | 班级id 			   |
| sid        | object | 考试人id 		   |
| type       | object | 类型 1-小考、2-考试 |
| duration   | object | 考试时间 |
| score      | object | 得分 |
| createTime | object | 做题时间 |
| answer     | object | 试卷答案和学生答案 |
| expname    | object | 试卷id |

**answer参数说明：**

| 名称       | 类型   | 说明               |
| ---------- | ------ | ------------------ |
| answer | int    | 学生答案             |
| qcontent    | object | 题目内容		   |
| qid         | object | 题目id 			   |
| qscore        | object | 题目分数			   |
| sanswer       | object | 题目答案 		   |

**json详情：**

```json
{
    "statusCode": "200",
    "message": "操作成功",
    "navTabId": null,
    "dialogId": null,
    "callbackType": null,
    "forwardUrl": null,
    "rel": null,
    "confirmMsg": null,
    "content": {
        "id": "f000a9b831be4af58bc7ba4a6805b2d7",
        "cid": "223e9da647254f0fb48a4bb736d94143",
        "sid": "801d33820136424eb6832e1a0257940d",
        "type": 1,
        "duration": 1,
        "score": 3,
        "expid": "aafa0624ecd44c67961f2bf15bdbb9ac",
        "createTime": "2019-10-19 09:59:59",
        "creator": null,
        "modifyTime": null,
        "modifier": null,
        "answer": "[{\"answer\":[\"A\",\"A\"],\"qcontent\":[{\"choiceList\":{\"A\":\"1\",\"B\":\"2\",\"C\":\"3\",\"D\":\"4\"},\"title\":\"题目2\"},{\"choiceList\":{\"A\":\"23232\",\"B\":\"323213123\",\"C\":\"123123123\",\"D\":\"1231231231\"},\"title\":\"3123\"}],\"qid\":[\"08ced7f43b634007b3e1488d375d769c\",\"76b67fc3440d447aa77489bb10716bd5\"],\"qscore\":[\"1\",\"1\"],\"sanswer\":[\"B\",\"C\"]},{\"answer\":[\"A,B\",\"A,B\"],\"qcontent\":[{\"choiceList\":{\"A\":\"123123\",\"B\":\"12321312\",\"C\":\"31231231\",\"D\":\"23213213\"},\"title\":\"123123\"},{\"choiceList\":{\"A\":\"123\",\"B\":\"123\",\"C\":\"123\",\"D\":\"123\"},\"title\":\"123\"}],\"qid\":[\"011e40f0ff7d44b6a09f87031a8dad9a\",\"9c08de5b1ed14f4d959064f0904cabdf\"],\"qscore\":[\"1\",\"1\"],\"sanswer\":[\"B,D\",\"A,B\"]},{\"answer\":[\"T\",\"T\"],\"qcontent\":[{\"choiceList\":{\"T\":\"正确\",\"F\":\"错误\"},\"title\":\"123111\"},{\"choiceList\":{\"T\":\"正确\",\"F\":\"错误\"},\"title\":\"123123123123123\"}],\"qid\":[\"3d0f8983a8844776a934fe5ac66d8371\",\"77832bd88e97496c9eb6367b67a17e3b\"],\"qscore\":[\"11\",\"11\"],\"sanswer\":[]},{\"answer\":[\"1,2\",\"asdfsfsdfsdf\"],\"qcontent\":[{\"choiceList\":{},\"title\":\"(__)(__)\"},{\"choiceList\":{},\"title\":\"11111(__)\"}],\"qid\":[\"0f3af0b32e8444a2b41f075165d33830\",\"2055e03535184a698f47ebb88d5834dc\"],\"qscore\":[\"1\",\"1\"],\"sanswer\":[]},{\"answer\":[\"1111111111111111111111111111\",\"12312323333\"],\"qcontent\":[{\"choiceList\":{},\"title\":\"11111111111111111111111111111\"},{\"choiceList\":{},\"title\":\"123123\"}],\"qid\":[\"001d721b492d4ed5ac7af267f5821ffe\",\"3c6147a7534f41e9bd69df7e73eb65ac\"],\"qscore\":[\"1\",\"1\"],\"sanswer\":[]},{\"answer\":[\"1111111111111111111111111111111\",\"22221111\"],\"qcontent\":[{\"choiceList\":{},\"title\":\"12222222222222222\"},{\"choiceList\":{},\"title\":\"12333333\"}],\"qid\":[\"9d39d60bc999471ba922778b96b46a07\",\"c5a87475c2504b828dca505b3c19d9f5\"],\"qscore\":[\"1\",\"1\"],\"sanswer\":[]},{\"answer\":[\"1111112222\",\"123257865423eteytrytreyerty\"],\"qcontent\":[{\"choiceList\":{},\"title\":\"1233333\"},{\"choiceList\":{},\"title\":\"123257865423eteytrytreyerty\"}],\"qid\":[\"7472f30735a04ac28c8c95323c6a8575\",\"bee3db670ba44284b4110b2fbd7cff45\"],\"qscore\":[\"1\",\"1\"],\"sanswer\":[]}]",
        "expname": "admin123"
    }
}
```

